package com.teacherhomework.manager.domain.usecase

import com.teacherhomework.manager.domain.model.GradeType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Guards the DATA VALIDATION RULES. These bounds are duplicated in the Firestore
 * security rules as the server-side backstop, so if a bound changes here it must
 * change there too — these tests are the reminder.
 */
class ValidateGradeUseCaseTest {

    private val validate = ValidateGradeUseCase()

    @Test
    fun `percent accepts the full inclusive range`() {
        assertTrue(validate.isValid(0.0, GradeType.PERCENT))
        assertTrue(validate.isValid(55.5, GradeType.PERCENT))
        assertTrue(validate.isValid(100.0, GradeType.PERCENT))
    }

    @Test
    fun `percent rejects values outside 0 to 100`() {
        assertFalse(validate.isValid(-0.1, GradeType.PERCENT))
        assertFalse(validate.isValid(100.1, GradeType.PERCENT))
    }

    @Test
    fun `point10 accepts 1 through 10 inclusive`() {
        assertTrue(validate.isValid(1.0, GradeType.POINT_10))
        assertTrue(validate.isValid(10.0, GradeType.POINT_10))
    }

    @Test
    fun `point10 rejects zero because the scale starts at 1`() {
        // This is the boundary most likely to be got wrong: 0 is valid for
        // PERCENT but NOT for POINT_10.
        assertFalse(validate.isValid(0.0, GradeType.POINT_10))
        assertFalse(validate.isValid(10.5, GradeType.POINT_10))
    }

    @Test
    fun `null grade is valid because a result can be recorded without a grade`() {
        // A student marked MISSING legitimately has no grade.
        assertTrue(validate.isValid(null, GradeType.PERCENT))
        assertTrue(validate.isValid(null, GradeType.POINT_10))
    }

    @Test
    fun `out of range result reports the bounds for the given type`() {
        val result = validate(200.0, GradeType.PERCENT)
        assertTrue(result is ValidateGradeUseCase.Result.OutOfRange)
        result as ValidateGradeUseCase.Result.OutOfRange
        assertEquals(0.0, result.min, 0.0)
        assertEquals(100.0, result.max, 0.0)
    }
}
