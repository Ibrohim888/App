package com.teacherhomework.manager.domain.usecase

import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.GradeType
import com.teacherhomework.manager.domain.model.Result
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Tests for the statistics computation.
 *
 * The IDEMPOTENCE test is the important one: the whole multi-device write-safety
 * argument rests on the summary being a pure function of the results snapshot.
 * If that ever stops holding, two devices racing could produce divergent
 * documents, and no amount of transaction retrying would fix it.
 */
class StatisticsCalculatorTest {

    private fun result(
        id: String,
        status: CompletionStatus,
        grade: Double? = null,
        gradeType: GradeType = GradeType.PERCENT,
        checkedDate: Long = FIXED_NOW,
    ) = Result(
        id = id,
        studentId = "s-$id",
        homeworkId = "hw-1",
        completionStatus = status,
        grade = grade,
        gradeType = gradeType,
        checkedDate = checkedDate,
        checkedBy = "teacher",
    )

    @Test
    fun `empty results produce a zeroed summary rather than NaN`() {
        val summary = StatisticsCalculator.compute(emptyList(), activeStudentCount = 12, nowMillis = FIXED_NOW)
        // averages over an empty list are NaN in Kotlin — the guard matters.
        assertEquals(0.0, summary.averageGrade, 0.0)
        assertEquals(0.0, summary.completionRate, 0.0)
        assertEquals(0, summary.missingHomeworkCount)
        assertEquals(12, summary.totalStudents)
    }

    @Test
    fun `completion rate counts partial as half credit`() {
        val results = listOf(
            result("1", CompletionStatus.COMPLETED),
            result("2", CompletionStatus.PARTIAL),
            result("3", CompletionStatus.MISSING),
            result("4", CompletionStatus.MISSING),
        )
        // (1.0 + 0.5 + 0 + 0) / 4 = 37.5%
        val summary = StatisticsCalculator.compute(results, 4, FIXED_NOW)
        assertEquals(37.5, summary.completionRate, 0.001)
    }

    @Test
    fun `all completed gives one hundred percent`() {
        val results = (1..5).map { result("$it", CompletionStatus.COMPLETED) }
        assertEquals(100.0, StatisticsCalculator.compute(results, 5, FIXED_NOW).completionRate, 0.001)
    }

    @Test
    fun `point10 grades are normalized before averaging with percent grades`() {
        val results = listOf(
            result("1", CompletionStatus.COMPLETED, grade = 90.0, gradeType = GradeType.PERCENT),
            result("2", CompletionStatus.COMPLETED, grade = 9.0, gradeType = GradeType.POINT_10),
        )
        // Both are effectively 90 — the average must be 90, not (90+9)/2 = 49.5.
        assertEquals(90.0, StatisticsCalculator.compute(results, 2, FIXED_NOW).averageGrade, 0.001)
    }

    @Test
    fun `ungraded results are excluded from the average but counted in completion`() {
        val results = listOf(
            result("1", CompletionStatus.COMPLETED, grade = 80.0),
            result("2", CompletionStatus.MISSING, grade = null),
        )
        val summary = StatisticsCalculator.compute(results, 2, FIXED_NOW)
        // The missing student has no grade, so it must not drag the average to 40.
        assertEquals(80.0, summary.averageGrade, 0.001)
        assertEquals(50.0, summary.completionRate, 0.001)
    }

    @Test
    fun `missing count reflects only MISSING status`() {
        val results = listOf(
            result("1", CompletionStatus.MISSING),
            result("2", CompletionStatus.MISSING),
            result("3", CompletionStatus.PARTIAL),
            result("4", CompletionStatus.COMPLETED),
        )
        assertEquals(2, StatisticsCalculator.compute(results, 4, FIXED_NOW).missingHomeworkCount)
    }

    @Test
    fun `computation is idempotent - same input yields identical output`() {
        val results = listOf(
            result("1", CompletionStatus.COMPLETED, grade = 95.0),
            result("2", CompletionStatus.PARTIAL, grade = 6.0, gradeType = GradeType.POINT_10),
            result("3", CompletionStatus.MISSING),
        )
        val a = StatisticsCalculator.compute(results, 3, FIXED_NOW)
        val b = StatisticsCalculator.compute(results, 3, FIXED_NOW)
        // Full equality, including the progress maps — this is the property the
        // multi-device transactional commit depends on.
        assertEquals(a, b)
    }

    @Test
    fun `order of results does not change the outcome`() {
        val results = listOf(
            result("1", CompletionStatus.COMPLETED, grade = 70.0),
            result("2", CompletionStatus.PARTIAL, grade = 50.0),
            result("3", CompletionStatus.MISSING),
        )
        val forward = StatisticsCalculator.compute(results, 3, FIXED_NOW)
        val reversed = StatisticsCalculator.compute(results.reversed(), 3, FIXED_NOW)
        assertEquals(forward.averageGrade, reversed.averageGrade, 0.0)
        assertEquals(forward.completionRate, reversed.completionRate, 0.0)
        assertEquals(forward.monthlyProgress, reversed.monthlyProgress)
    }

    @Test
    fun `monthly buckets group by calendar month and sort chronologically`() {
        val jan = 1767225600000L // 2026-01-01T00:00:00Z
        val feb = 1769904000000L // 2026-02-01T00:00:00Z
        val results = listOf(
            result("1", CompletionStatus.COMPLETED, grade = 60.0, checkedDate = feb),
            result("2", CompletionStatus.COMPLETED, grade = 80.0, checkedDate = jan),
            result("3", CompletionStatus.COMPLETED, grade = 100.0, checkedDate = jan),
        )
        val summary = StatisticsCalculator.compute(results, 3, FIXED_NOW)
        assertEquals(listOf("2026-01", "2026-02"), summary.monthlyProgress.keys.toList())
        assertEquals(90.0, summary.monthlyProgress["2026-01"]!!, 0.001)
        assertEquals(60.0, summary.monthlyProgress["2026-02"]!!, 0.001)
    }

    @Test
    fun `bucket keys are zero padded so they sort lexicographically`() {
        // "2026-09" must sort before "2026-10"; unpadded "2026-9" would not.
        val key = StatisticsCalculator.monthKey(1767225600000L)
        assertEquals("2026-01", key)
        assertTrue(StatisticsCalculator.weekKey(1767225600000L).matches(Regex("""\d{4}-W\d{2}""")))
    }

    @Test
    fun `averages are rounded to two decimals to keep the document stable`() {
        val results = listOf(
            result("1", CompletionStatus.COMPLETED, grade = 1.0),
            result("2", CompletionStatus.COMPLETED, grade = 2.0),
            result("3", CompletionStatus.COMPLETED, grade = 2.0),
        )
        // 5/3 = 1.6666… — rounding keeps repeated recalcs from producing a
        // different float each time and churning Firestore writes.
        assertEquals(1.67, StatisticsCalculator.compute(results, 3, FIXED_NOW).averageGrade, 0.0001)
    }

    private companion object {
        /** 2026-03-15T12:00:00Z — fixed so tests never depend on the clock. */
        const val FIXED_NOW = 1773576000000L
    }
}
