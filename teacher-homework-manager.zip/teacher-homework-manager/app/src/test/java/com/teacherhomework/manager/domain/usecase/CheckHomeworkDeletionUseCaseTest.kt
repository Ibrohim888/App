package com.teacherhomework.manager.domain.usecase

import com.teacherhomework.manager.domain.model.Result
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Locks in the POLICY OVERRIDE: deleting a graded homework is NEVER blocked.
 *
 * The use case only decides WHICH confirmation the UI shows. If a future change
 * ever reintroduces a "cannot delete" outcome, these tests fail — which is the
 * point, since that behavior was deliberately removed at the teacher's request.
 */
class CheckHomeworkDeletionUseCaseTest {

    @Test
    fun `no results yields DirectDelete`() = runTest {
        val useCase = CheckHomeworkDeletionUseCase(FakeResultRepository(count = 0))
        val decision = useCase("hw-1")
        assertTrue(decision is CheckHomeworkDeletionUseCase.Decision.DirectDelete)
    }

    @Test
    fun `existing results yield NeedsConfirmation carrying the count`() = runTest {
        val useCase = CheckHomeworkDeletionUseCase(FakeResultRepository(count = 17))
        val decision = useCase("hw-1")
        assertTrue(decision is CheckHomeworkDeletionUseCase.Decision.NeedsConfirmation)
        decision as CheckHomeworkDeletionUseCase.Decision.NeedsConfirmation
        // The count drives the warning copy, so it must be exact — not just
        // "some results exist".
        assertEquals(17, decision.resultCount)
    }

    @Test
    fun `a single result still only asks for confirmation, never refuses`() = runTest {
        val useCase = CheckHomeworkDeletionUseCase(FakeResultRepository(count = 1))
        val decision = useCase("hw-1")
        assertTrue(decision is CheckHomeworkDeletionUseCase.Decision.NeedsConfirmation)
    }

    /** Minimal stand-in; only the count path is exercised by this use case. */
    private class FakeResultRepository(private val count: Int) : ResultRepository {
        override suspend fun countResultsForHomework(homeworkId: String): Int = count
        override suspend fun hasResultsForHomework(homeworkId: String): Boolean = count > 0

        override fun observeResultsForHomework(homeworkId: String): Flow<List<Result>> = flowOf(emptyList())
        override fun observeResultsForStudent(studentId: String): Flow<List<Result>> = flowOf(emptyList())
        override fun observeAllResults(): Flow<List<Result>> = flowOf(emptyList())
        override fun observeHasResults(homeworkId: String): Flow<Boolean> = flowOf(count > 0)
        override suspend fun getResultFor(homeworkId: String, studentId: String): Result? = null
        override suspend fun upsertResult(result: Result): AppResult<Unit> = AppResult.Success(Unit)
        override suspend fun deleteResultsForStudent(studentId: String): AppResult<Unit> = AppResult.Success(Unit)
        override suspend fun allResults(): List<Result> = emptyList()
        override suspend fun refresh(): AppResult<Unit> = AppResult.Success(Unit)
    }
}
