package com.teacherhomework.manager.domain.model

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Unit tests for the resilient parsing of persisted/remote preference tokens.
 * These guard the FALLBACK RULE: an unknown or null stored value must resolve to
 * a safe default rather than throwing (which would otherwise crash the app if a
 * newer device wrote a value this build doesn't recognize).
 */
class PreferenceModelTest {

    @Test
    fun `language falls back to default on null or unknown`() {
        assertEquals(AppLanguage.DEFAULT, AppLanguage.fromTag(null))
        assertEquals(AppLanguage.DEFAULT, AppLanguage.fromTag("fr"))
    }

    @Test
    fun `language resolves known tags including region-qualified`() {
        assertEquals(AppLanguage.UZBEK, AppLanguage.fromTag("uz"))
        assertEquals(AppLanguage.RUSSIAN, AppLanguage.fromTag("ru"))
        assertEquals(AppLanguage.ENGLISH, AppLanguage.fromTag("en"))
        // Region-qualified tag still resolves on the primary subtag.
        assertEquals(AppLanguage.UZBEK, AppLanguage.fromTag("uz-Latn-UZ"))
    }

    @Test
    fun `theme color falls back to default on null or unknown`() {
        assertEquals(AppThemeColor.DEFAULT, AppThemeColor.fromId(null))
        assertEquals(AppThemeColor.DEFAULT, AppThemeColor.fromId("neon_pink"))
    }

    @Test
    fun `theme color resolves all five known ids`() {
        assertEquals(AppThemeColor.FOREST_GREEN, AppThemeColor.fromId("forest_green"))
        assertEquals(AppThemeColor.TRUST_BLUE, AppThemeColor.fromId("trust_blue"))
        assertEquals(AppThemeColor.VIOLET, AppThemeColor.fromId("violet"))
        assertEquals(AppThemeColor.WARM_ROSE, AppThemeColor.fromId("warm_rose"))
        assertEquals(AppThemeColor.TEAL, AppThemeColor.fromId("teal"))
    }

    @Test
    fun `dark mode preference maps to correct dark flag`() {
        assertEquals(null, DarkModePreference.SYSTEM.toDarkFlag())
        assertEquals(false, DarkModePreference.LIGHT.toDarkFlag())
        assertEquals(true, DarkModePreference.DARK.toDarkFlag())
    }
}
