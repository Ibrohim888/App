package com.teacherhomework.manager.data.report

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/**
 * Verifies the hand-rolled XLSX writer produces a structurally valid package.
 *
 * These tests are the safety net for NOT using Apache POI: without a library
 * guaranteeing the OOXML shape, the required parts and the XML escaping have to
 * be checked explicitly, or a malformed file would only surface when a teacher
 * tries to open an export.
 */
class XlsxWriterTest {

    private val writer = XlsxWriter()

    private fun writeToBytes(sheets: List<XlsxWriter.Sheet>): Map<String, String> {
        val out = ByteArrayOutputStream()
        writer.write(out, sheets)
        val entries = mutableMapOf<String, String>()
        ZipInputStream(ByteArrayInputStream(out.toByteArray())).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                entries[entry.name] = zip.readBytes().toString(Charsets.UTF_8)
                entry = zip.nextEntry
            }
        }
        return entries
    }

    @Test
    fun `writes all required OOXML parts`() {
        val parts = writeToBytes(
            listOf(XlsxWriter.Sheet(name = "Summary", header = listOf("A"), rows = emptyList()))
        )
        // Excel refuses to open the file if any of these are missing.
        assertNotNull(parts["[Content_Types].xml"])
        assertNotNull(parts["_rels/.rels"])
        assertNotNull(parts["xl/workbook.xml"])
        assertNotNull(parts["xl/_rels/workbook.xml.rels"])
        assertNotNull(parts["xl/styles.xml"])
        assertNotNull(parts["xl/worksheets/sheet1.xml"])
    }

    @Test
    fun `numbers are written as numeric cells not text`() {
        val parts = writeToBytes(
            listOf(
                XlsxWriter.Sheet(
                    name = "Data",
                    header = listOf("Grade"),
                    rows = listOf(listOf(XlsxWriter.Cell.Number(92.5))),
                )
            )
        )
        val sheet = parts["xl/worksheets/sheet1.xml"]!!
        // A <v> value with no t attribute is what makes Excel treat it as a
        // number the teacher can sort and chart.
        assertTrue(sheet.contains("<v>92.5</v>"))
    }

    @Test
    fun `xml special characters in teacher text are escaped`() {
        val parts = writeToBytes(
            listOf(
                XlsxWriter.Sheet(
                    name = "Data",
                    header = listOf("Comment"),
                    rows = listOf(listOf(XlsxWriter.Cell.Text("Ali & Vali <best> \"work\""))),
                )
            )
        )
        val sheet = parts["xl/worksheets/sheet1.xml"]!!
        assertTrue(sheet.contains("Ali &amp; Vali &lt;best&gt;"))
        // The raw, unescaped form must not survive — it would corrupt the XML.
        assertTrue(!sheet.contains("<best>"))
    }

    @Test
    fun `cyrillic and uzbek text survive the round trip`() {
        val parts = writeToBytes(
            listOf(
                XlsxWriter.Sheet(
                    name = "Данные",
                    header = listOf("O‘quvchi", "Оценка"),
                    rows = listOf(listOf(XlsxWriter.Cell.Text("Иванов"), XlsxWriter.Cell.Number(5.0))),
                )
            )
        )
        val sheet = parts["xl/worksheets/sheet1.xml"]!!
        assertTrue(sheet.contains("Иванов"))
        assertTrue(sheet.contains("O‘quvchi"))
    }

    @Test
    fun `multiple sheets each get their own part`() {
        val parts = writeToBytes(
            listOf(
                XlsxWriter.Sheet(name = "One"),
                XlsxWriter.Sheet(name = "Two"),
                XlsxWriter.Sheet(name = "Three"),
            )
        )
        assertNotNull(parts["xl/worksheets/sheet1.xml"])
        assertNotNull(parts["xl/worksheets/sheet2.xml"])
        assertNotNull(parts["xl/worksheets/sheet3.xml"])
    }

    @Test
    fun `sheet names with illegal characters are sanitized`() {
        val parts = writeToBytes(listOf(XlsxWriter.Sheet(name = "Class 5/A [2026]")))
        val workbook = parts["xl/workbook.xml"]!!
        // Excel rejects : \ / ? * [ ] in sheet names outright.
        assertTrue(!workbook.contains("5/A"))
        assertTrue(!workbook.contains("["))
    }

    @Test
    fun `header row uses the bold style index`() {
        val parts = writeToBytes(
            listOf(XlsxWriter.Sheet(name = "S", header = listOf("Name"), rows = listOf(listOf(XlsxWriter.Cell.Text("x")))))
        )
        val sheet = parts["xl/worksheets/sheet1.xml"]!!
        assertTrue(sheet.contains("""s="1""""))
    }

    @Test
    fun `column names follow spreadsheet base26 naming`() {
        // 27 columns exercises the A..Z -> AA rollover, which is the easy
        // off-by-one in base-26 column naming.
        val header = (1..27).map { "C$it" }
        val parts = writeToBytes(listOf(XlsxWriter.Sheet(name = "S", header = header)))
        val sheet = parts["xl/worksheets/sheet1.xml"]!!
        assertTrue(sheet.contains("""r="Z1""""))
        assertTrue(sheet.contains("""r="AA1""""))
    }

    @Test
    fun `empty cells are still emitted so columns stay aligned`() {
        val parts = writeToBytes(
            listOf(
                XlsxWriter.Sheet(
                    name = "S",
                    rows = listOf(
                        listOf(XlsxWriter.Cell.Text("a"), XlsxWriter.Cell.Empty, XlsxWriter.Cell.Text("c"))
                    ),
                )
            )
        )
        val sheet = parts["xl/worksheets/sheet1.xml"]!!
        assertTrue(sheet.contains("""<c r="B1"/>"""))
        assertEquals(3, Regex("""<c r="[A-Z]+1"""").findAll(sheet).count())
    }
}
