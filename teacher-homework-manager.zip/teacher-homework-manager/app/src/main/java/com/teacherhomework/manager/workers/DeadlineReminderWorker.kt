package com.teacherhomework.manager.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.teacherhomework.manager.data.local.dao.NotificationDao
import com.teacherhomework.manager.data.local.entity.NotificationEntity
import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.notifications.NotificationHelper
import com.teacherhomework.manager.presentation.util.DateFormat
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Posts a LOCAL reminder about homework due soon.
 *
 * BEST-EFFORT BY DESIGN: WorkManager runs this inside an OS-chosen window, so it
 * can fire hours after the nominal time (or not at all while the device dozes).
 * That limitation is disclosed in Settings and mitigated by the Dashboard's live
 * "needs attention" list — the teacher never has to rely on this firing.
 *
 * Reads come from Room, so a reminder costs zero Firestore reads.
 */
@HiltWorker
class DeadlineReminderWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val homeworkRepository: HomeworkRepository,
    private val appPreferences: AppPreferences,
    private val notificationHelper: NotificationHelper,
    private val notificationDao: NotificationDao,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val settings = appPreferences.notificationSettings.first()
        if (!settings.localRemindersEnabled || !settings.deadlineReminders) {
            return Result.success()
        }

        val now = System.currentTimeMillis()
        val cutoff = now + TimeUnit.DAYS.toMillis(LOOKAHEAD_DAYS)
        val dueSoon = homeworkRepository
            .observeHomework(status = HomeworkStatus.ACTIVE)
            .first()
            .filter { it.deadline in now..cutoff }

        if (dueSoon.isEmpty()) return Result.success()

        // Notification copy uses the TEACHER's chosen language, not the device
        // language — see WorkerLocale.
        val ctx = WorkerLocale.localizedContext(applicationContext, appPreferences)
        val title = ctx.getString(com.teacherhomework.manager.R.string.notif_deadline_title)
        val body = if (dueSoon.size == 1) {
            val hw = dueSoon.first()
            ctx.getString(
                com.teacherhomework.manager.R.string.notif_deadline_body_single,
                hw.title,
                DateFormat.relativeDeadline(ctx, hw.deadline, now),
            )
        } else {
            ctx.resources.getQuantityString(
                com.teacherhomework.manager.R.plurals.notif_deadline_body_multi,
                dueSoon.size,
                dueSoon.size,
            )
        }

        notificationHelper.post(
            channelId = NotificationHelper.CHANNEL_DEADLINES,
            notificationId = NotificationHelper.ID_DEADLINE,
            title = title,
            body = body,
            deepLink = DEEP_LINK_HOMEWORK,
        )

        // Mirrored into the in-app Notification Center, stored STRUCTURED (type +
        // params) so it re-renders correctly if the teacher changes language.
        notificationDao.insert(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                type = TYPE_DEADLINE,
                paramsJson = """{"count":"${dueSoon.size}","title":"${dueSoon.first().title.jsonEscape()}"}""",
                postedAt = now,
                read = false,
                deepLink = DEEP_LINK_HOMEWORK,
            )
        )
        return Result.success()
    }

    companion object {
        const val WORK_NAME = "deadline_reminder"
        const val TYPE_DEADLINE = "DEADLINE"
        const val DEEP_LINK_HOMEWORK = "homework"

        /** How far ahead a deadline triggers a reminder. */
        const val LOOKAHEAD_DAYS = 2L
    }
}

/** Minimal escaping for the small JSON param blobs stored in Room. */
internal fun String.jsonEscape(): String =
    replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ")
