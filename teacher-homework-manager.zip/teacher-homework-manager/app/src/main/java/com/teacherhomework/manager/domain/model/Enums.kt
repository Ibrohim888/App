package com.teacherhomework.manager.domain.model

/**
 * HOMEWORK STATUS — the lifecycle of an assignment itself. Lives on the
 * `homework` document, field name `status`. Deliberately a different enum (and a
 * different field name) from [CompletionStatus] so the two can never be confused
 * in code or AI-generated edits (NAMING DISAMBIGUATION).
 */
enum class HomeworkStatus(val token: String) {
    DRAFT("DRAFT"),
    ACTIVE("ACTIVE"),
    COMPLETED("COMPLETED"),
    ARCHIVED("ARCHIVED");

    companion object {
        fun fromToken(token: String?): HomeworkStatus =
            entries.firstOrNull { it.token == token } ?: DRAFT
    }
}

/**
 * RESULT STATUS — a single student's completion of one homework. Lives on the
 * `results` document, field name `completionStatus` (NOT `status`).
 * PARTIAL counts as 50% toward completion rate; MISSING as 0% (see Phase 4).
 */
enum class CompletionStatus(val token: String) {
    COMPLETED("COMPLETED"),
    PARTIAL("PARTIAL"),
    MISSING("MISSING");

    /** Weight toward completion rate: completed=1.0, partial=0.5, missing=0.0. */
    fun completionWeight(): Double = when (this) {
        COMPLETED -> 1.0
        PARTIAL -> 0.5
        MISSING -> 0.0
    }

    companion object {
        fun fromToken(token: String?): CompletionStatus =
            entries.firstOrNull { it.token == token } ?: MISSING
    }
}

/**
 * Grade scale. Enforced by [com.teacherhomework.manager.domain.usecase.ValidateGradeUseCase]
 * and mirrored in security rules (DATA VALIDATION RULES):
 *  - PERCENT  → 0..100 inclusive
 *  - POINT_10 → 1..10 inclusive
 */
enum class GradeType(val token: String, val min: Double, val max: Double) {
    PERCENT("PERCENT", 0.0, 100.0),
    POINT_10("POINT_10", 1.0, 10.0);

    /**
     * Normalizes a grade of this type onto a common 0..100 scale so grades from
     * different scales can be averaged together (Phase 4). POINT_10 maps ×10.
     */
    fun normalizeToPercent(grade: Double): Double = when (this) {
        PERCENT -> grade
        POINT_10 -> grade * 10.0
    }

    companion object {
        fun fromToken(token: String?): GradeType =
            entries.firstOrNull { it.token == token } ?: PERCENT
    }
}

/** Per-entity sync state for the offline-first Room mirror. */
enum class SyncState { SYNCED, PENDING, FAILED }
