package com.teacherhomework.manager.data.repository

import com.teacherhomework.manager.data.local.dao.HomeworkDao
import com.teacherhomework.manager.data.local.dao.ResultDao
import com.teacherhomework.manager.data.local.dao.StudentDao
import com.teacherhomework.manager.data.mapper.toDomain
import com.teacherhomework.manager.data.mapper.toEntity
import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.data.remote.HomeworkRemoteDataSource
import com.teacherhomework.manager.data.remote.ResultRemoteDataSource
import com.teacherhomework.manager.data.remote.StudentRemoteDataSource
import com.teacherhomework.manager.domain.model.SyncState
import com.teacherhomework.manager.domain.repository.StatisticsRepository
import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Flushes locally-written records that never made it to Firestore.
 *
 * WHY THIS EXISTS: every write in this app goes to Room first and is marked
 * PENDING; the Firestore push follows. If the teacher was offline (or the app
 * was killed mid-write), the row stays PENDING. This manager finds those rows
 * and retries them — without it, an offline grading session could sit unsynced
 * indefinitely.
 *
 * CONFLICT POLICY: last-write-wins, which is correct here because a teacher's
 * account is effectively single-writer (one person, possibly two devices). A
 * pending local row is the teacher's most recent intent on THIS device, so it is
 * pushed as-is rather than merged field-by-field.
 */
@Singleton
class SyncManager @Inject constructor(
    private val studentDao: StudentDao,
    private val homeworkDao: HomeworkDao,
    private val resultDao: ResultDao,
    private val studentRemote: StudentRemoteDataSource,
    private val homeworkRemote: HomeworkRemoteDataSource,
    private val resultRemote: ResultRemoteDataSource,
    private val statisticsRepository: StatisticsRepository,
    private val session: SessionProvider,
    private val appPreferences: AppPreferences,
) {
    /** Coarse progress for the sync indicator in the UI. */
    enum class Status { IDLE, SYNCING, SUCCESS, FAILED }

    private val _status = MutableStateFlow(Status.IDLE)
    val status: StateFlow<Status> = _status.asStateFlow()

    /**
     * Pushes every PENDING row, then pulls fresh remote state and recalculates
     * statistics.
     *
     * Each record is retried independently: one row that keeps failing (e.g. it
     * violates a security rule) must not block the other 119 from syncing.
     */
    suspend fun syncNow(): AppResult<Unit> {
        _status.value = Status.SYNCING
        val result = runCatchingRepo {
            val teacherId = session.requireTeacherId()

            pushPendingStudents(teacherId)
            pushPendingHomework(teacherId)
            pushPendingResults(teacherId)

            // Pull after pushing, so remote data doesn't overwrite local edits
            // that hadn't been uploaded yet.
            studentDao.upsertAll(studentRemote.fetchAll(teacherId).map { it.toEntity() })
            homeworkDao.upsertAll(homeworkRemote.fetchAll(teacherId).map { it.toEntity() })
            resultDao.upsertAll(resultRemote.fetchAll(teacherId).map { it.toEntity() })

            statisticsRepository.recalculateAndCommit()
            appPreferences.setLastSyncAt(System.currentTimeMillis())
        }
        _status.value = if (result is AppResult.Success) Status.SUCCESS else Status.FAILED
        return result
    }

    private suspend fun pushPendingStudents(teacherId: String) {
        studentDao.getPending(SyncState.SYNCED.name).forEach { entity ->
            runCatching {
                studentRemote.upsert(teacherId, entity.toDomain())
                studentDao.upsert(entity.copy(syncState = SyncState.SYNCED.name))
            }.onFailure {
                studentDao.upsert(entity.copy(syncState = SyncState.FAILED.name))
            }
        }
    }

    private suspend fun pushPendingHomework(teacherId: String) {
        homeworkDao.getPending(SyncState.SYNCED.name).forEach { entity ->
            runCatching {
                homeworkRemote.upsert(teacherId, entity.toDomain())
                homeworkDao.upsert(entity.copy(syncState = SyncState.SYNCED.name))
            }.onFailure {
                homeworkDao.upsert(entity.copy(syncState = SyncState.FAILED.name))
            }
        }
    }

    private suspend fun pushPendingResults(teacherId: String) {
        resultDao.getPending(SyncState.SYNCED.name).forEach { entity ->
            runCatching {
                resultRemote.upsert(teacherId, entity.toDomain())
                resultDao.upsert(entity.copy(syncState = SyncState.SYNCED.name))
            }.onFailure {
                resultDao.upsert(entity.copy(syncState = SyncState.FAILED.name))
            }
        }
    }
}
