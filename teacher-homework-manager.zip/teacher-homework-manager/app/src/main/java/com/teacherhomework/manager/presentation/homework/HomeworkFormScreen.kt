package com.teacherhomework.manager.presentation.homework

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.presentation.components.AppTextField
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.DatePickerField
import com.teacherhomework.manager.presentation.components.PrimaryButton
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.util.toStringRes

/**
 * Create/edit a homework assignment.
 *
 * Nothing is locked when editing — per the editing policy, every field stays
 * changeable even after grading has started. The only added behavior is the
 * inline notice that appears when the deadline is changed on an assignment that
 * already has grades, stating that entered grades are not re-evaluated.
 */
@Composable
fun HomeworkFormScreen(
    onNavigateBack: () -> Unit,
    onSaved: () -> Unit,
    viewModel: HomeworkFormViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val classNames by viewModel.classNames.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(state.saved) { if (state.saved) onSaved() }

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHostState.showSnackbar(context.getString(it.toStringRes()))
            viewModel.consumeError()
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(
                    if (viewModel.isNew) R.string.title_add_homework
                    else R.string.title_edit_homework
                ),
                onNavigateBack = onNavigateBack,
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
        ) {
            AppTextField(
                value = state.title,
                onValueChange = viewModel::onTitleChange,
                label = stringResource(R.string.field_title),
                errorText = state.titleError?.let { stringResource(it.toStringRes()) },
            )
            Spacer(Modifier.height(14.dp))
            AppTextField(
                value = state.subject,
                onValueChange = viewModel::onSubjectChange,
                label = stringResource(R.string.field_subject),
                errorText = state.subjectError?.let { stringResource(it.toStringRes()) },
            )
            Spacer(Modifier.height(14.dp))

            // Class is chosen from real student classes, not typed freely, so the
            // checking screen can always resolve the assignment to students.
            Text(
                text = stringResource(R.string.field_class_name),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            if (classNames.isEmpty()) {
                Text(
                    text = stringResource(R.string.hint_no_classes_yet),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    classNames.forEach { name ->
                        FilterChip(
                            selected = state.className == name,
                            onClick = { viewModel.onClassNameChange(name) },
                            label = { Text(name) },
                            shape = AppCorner.Chip,
                        )
                    }
                }
            }
            state.classNameError?.let {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = stringResource(it.toStringRes()),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            Spacer(Modifier.height(14.dp))
            AppTextField(
                value = state.description,
                onValueChange = viewModel::onDescriptionChange,
                label = stringResource(R.string.field_description),
                singleLine = false,
            )
            Spacer(Modifier.height(14.dp))
            DatePickerField(
                label = stringResource(R.string.field_assigned_date),
                value = state.assignedDate,
                onValueChange = viewModel::onAssignedDateChange,
            )
            Spacer(Modifier.height(14.dp))
            DatePickerField(
                label = stringResource(R.string.field_deadline),
                value = state.deadline,
                onValueChange = viewModel::onDeadlineChange,
                errorText = state.deadlineError?.let { stringResource(it.toStringRes()) },
            )

            if (state.showDeadlineChangeNotice) {
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(AppCorner.Card)
                        .background(MaterialTheme.colorScheme.secondaryContainer)
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.size(10.dp))
                    Text(
                        text = stringResource(R.string.notice_deadline_change),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                text = stringResource(R.string.field_status),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                HomeworkStatus.entries.forEach { status ->
                    FilterChip(
                        selected = state.status == status,
                        onClick = { viewModel.onStatusChange(status) },
                        label = { Text(stringResource(status.labelRes())) },
                        shape = AppCorner.Chip,
                    )
                }
            }

            Spacer(Modifier.height(28.dp))
            PrimaryButton(
                text = stringResource(R.string.action_save),
                onClick = viewModel::save,
                loading = state.isSaving,
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

@androidx.annotation.StringRes
private fun HomeworkStatus.labelRes(): Int = when (this) {
    HomeworkStatus.DRAFT -> R.string.homework_status_draft
    HomeworkStatus.ACTIVE -> R.string.homework_status_active
    HomeworkStatus.COMPLETED -> R.string.homework_status_completed
    HomeworkStatus.ARCHIVED -> R.string.homework_status_archived
}
