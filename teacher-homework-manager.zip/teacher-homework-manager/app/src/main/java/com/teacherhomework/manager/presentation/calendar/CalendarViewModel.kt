package com.teacherhomework.manager.presentation.calendar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.presentation.util.DateFormat
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import java.util.Calendar
import javax.inject.Inject

/** One cell of the month grid. */
data class CalendarDay(
    val epochMillis: Long,
    val dayOfMonth: Int,
    /** False for the leading/trailing days that pad the grid to whole weeks. */
    val inCurrentMonth: Boolean,
    val isToday: Boolean,
    val homeworkCount: Int,
)

data class CalendarUiState(
    /** First-of-month anchor for the month being displayed. */
    val monthAnchor: Long = firstOfMonth(System.currentTimeMillis()),
    val selectedDate: Long = DateFormat.atStartOfDay(System.currentTimeMillis()),
)

/**
 * Month calendar of homework deadlines.
 *
 * The grid is generated locally from the cached homework list — the calendar
 * never queries Firestore, so paging between months is instant and free.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class CalendarViewModel @Inject constructor(
    private val homeworkRepository: HomeworkRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(CalendarUiState())
    val uiState: StateFlow<CalendarUiState> = _uiState.asStateFlow()

    private val allHomework: StateFlow<List<Homework>> = homeworkRepository.observeHomework()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** The 6×7 day grid for the displayed month, with per-day deadline counts. */
    val days: StateFlow<List<CalendarDay>> = combine(_uiState, allHomework) { state, homework ->
        buildMonthGrid(state.monthAnchor, homework)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Assignments whose deadline falls on the currently selected day. */
    val selectedDayHomework: StateFlow<List<Homework>> =
        combine(_uiState, allHomework) { state, homework ->
            homework.filter { DateFormat.isSameDay(it.deadline, state.selectedDate) }
                .sortedBy { it.deadline }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun selectDate(epochMillis: Long) =
        _uiState.update { it.copy(selectedDate = DateFormat.atStartOfDay(epochMillis)) }

    fun previousMonth() = _uiState.update { it.copy(monthAnchor = shiftMonth(it.monthAnchor, -1)) }

    fun nextMonth() = _uiState.update { it.copy(monthAnchor = shiftMonth(it.monthAnchor, +1)) }

    fun goToToday() {
        val now = System.currentTimeMillis()
        _uiState.update {
            it.copy(monthAnchor = firstOfMonth(now), selectedDate = DateFormat.atStartOfDay(now))
        }
    }

    /**
     * Builds a whole-week-aligned grid: the month's days plus enough leading and
     * trailing days to fill complete Monday-start weeks, so the grid never has
     * ragged edges. Deadline counts are pre-joined per day here rather than
     * looked up per cell during composition.
     */
    private fun buildMonthGrid(monthAnchor: Long, homework: List<Homework>): List<CalendarDay> {
        val countsByDay = homework.groupingBy { DateFormat.atStartOfDay(it.deadline) }.eachCount()
        val todayStart = DateFormat.atStartOfDay(System.currentTimeMillis())

        val cal = Calendar.getInstance().apply {
            timeInMillis = monthAnchor
            firstDayOfWeek = Calendar.MONDAY
        }
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        // Monday = 0 … Sunday = 6, regardless of the device's week-start setting.
        val leadingBlanks = (cal.get(Calendar.DAY_OF_WEEK) - Calendar.MONDAY + 7) % 7

        val days = mutableListOf<CalendarDay>()

        // Trailing days of the previous month.
        if (leadingBlanks > 0) {
            val prev = Calendar.getInstance().apply {
                timeInMillis = monthAnchor
                add(Calendar.MONTH, -1)
            }
            val prevMax = prev.getActualMaximum(Calendar.DAY_OF_MONTH)
            for (i in leadingBlanks downTo 1) {
                prev.set(Calendar.DAY_OF_MONTH, prevMax - i + 1)
                val start = DateFormat.atStartOfDay(prev.timeInMillis)
                days += CalendarDay(
                    epochMillis = start,
                    dayOfMonth = prevMax - i + 1,
                    inCurrentMonth = false,
                    isToday = start == todayStart,
                    homeworkCount = countsByDay[start] ?: 0,
                )
            }
        }

        // The month itself.
        for (day in 1..daysInMonth) {
            cal.set(Calendar.DAY_OF_MONTH, day)
            val start = DateFormat.atStartOfDay(cal.timeInMillis)
            days += CalendarDay(
                epochMillis = start,
                dayOfMonth = day,
                inCurrentMonth = true,
                isToday = start == todayStart,
                homeworkCount = countsByDay[start] ?: 0,
            )
        }

        // Leading days of the next month, to complete the final week.
        val next = Calendar.getInstance().apply {
            timeInMillis = monthAnchor
            add(Calendar.MONTH, 1)
        }
        var extra = 1
        while (days.size % 7 != 0) {
            next.set(Calendar.DAY_OF_MONTH, extra)
            val start = DateFormat.atStartOfDay(next.timeInMillis)
            days += CalendarDay(
                epochMillis = start,
                dayOfMonth = extra,
                inCurrentMonth = false,
                isToday = start == todayStart,
                homeworkCount = countsByDay[start] ?: 0,
            )
            extra++
        }
        return days
    }
}

/** Local midnight on the 1st of the month containing [epochMillis]. */
private fun firstOfMonth(epochMillis: Long): Long = Calendar.getInstance().apply {
    timeInMillis = epochMillis
    set(Calendar.DAY_OF_MONTH, 1)
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

private fun shiftMonth(anchor: Long, delta: Int): Long = Calendar.getInstance().apply {
    timeInMillis = anchor
    add(Calendar.MONTH, delta)
}.timeInMillis
