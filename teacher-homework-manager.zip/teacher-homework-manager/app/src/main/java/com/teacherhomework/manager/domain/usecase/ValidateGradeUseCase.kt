package com.teacherhomework.manager.domain.usecase

import com.teacherhomework.manager.domain.model.GradeType
import javax.inject.Inject

/**
 * The SINGLE source of truth for grade validity (DATA VALIDATION RULES). Every
 * screen and repository that writes a grade must call this — never re-implement
 * the range check inline, because UI-only validation can be bypassed by a direct
 * Firestore write, and this same rule is mirrored server-side in the security
 * rules as the real backstop.
 *
 *  - PERCENT  → 0..100 inclusive
 *  - POINT_10 → 1..10 inclusive
 *
 * A null grade is considered valid (grade is optional on a result — a student
 * can be marked MISSING with no grade).
 */
class ValidateGradeUseCase @Inject constructor() {

    sealed interface Result {
        data object Valid : Result
        /** Out of range; [min]/[max] are the allowed bounds for the given type. */
        data class OutOfRange(val min: Double, val max: Double) : Result
    }

    operator fun invoke(grade: Double?, gradeType: GradeType): Result {
        if (grade == null) return Result.Valid
        return if (grade in gradeType.min..gradeType.max) Result.Valid
        else Result.OutOfRange(gradeType.min, gradeType.max)
    }

    /** Convenience boolean form. */
    fun isValid(grade: Double?, gradeType: GradeType): Boolean =
        invoke(grade, gradeType) is Result.Valid
}
