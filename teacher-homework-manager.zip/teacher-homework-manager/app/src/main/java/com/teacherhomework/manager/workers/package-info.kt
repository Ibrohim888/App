/**
 * WorkManager workers for on-device, local-only automation.
 *
 * Intentionally empty in Phase 1 — this package exists now so the Clean
 * Architecture layout (/data, /domain, /presentation, /di, /workers) is in place
 * from the start. Phase 6 adds the local workers here:
 *   - HomeworkCreatedNotificationWorker
 *   - DeadlineReminderWorker
 *   - StatisticsRecalculationWorker
 *   - ReportGenerationWorker
 *   - MissingHomeworkAlertWorker
 *   - WeeklyReportSummaryWorker
 *
 * All scheduling is on-device (WorkManager) and delivery is via local
 * NotificationCompat only. NO Firebase Cloud Messaging / push — permanently out
 * of scope per the FREE-TIER POLICY.
 */
package com.teacherhomework.manager.workers
