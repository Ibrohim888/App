package com.teacherhomework.manager.presentation.reports

import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.data.report.ReportFormat
import com.teacherhomework.manager.data.report.ReportType
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.PrimaryButton
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.util.DateFormat
import com.teacherhomework.manager.presentation.util.toStringRes
import java.io.File

/**
 * Report export: pick a type, a format, and an optional class, then generate.
 *
 * Files are written to app-private storage (no permission needed) and shared
 * through a FileProvider — the teacher explicitly taps Share, so nothing leaves
 * the device without their action.
 */
@Composable
fun ReportsScreen(
    onNavigateBack: () -> Unit,
    viewModel: ReportsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val classNames by viewModel.classNames.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val locale = LocalConfiguration.current.locales[0]
    val accentColor = MaterialTheme.colorScheme.primary.toArgb()

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHostState.showSnackbar(context.getString(it.toStringRes()))
            viewModel.consumeError()
        }
    }

    LaunchedEffect(state.generatedFile) {
        state.generatedFile?.let { file ->
            snackbarHostState.showSnackbar(context.getString(R.string.report_generated, file.name))
            viewModel.consumeGeneratedFile()
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.nav_reports),
                onNavigateBack = onNavigateBack,
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            SectionLabel(stringResource(R.string.report_label_type))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ReportType.entries.forEach { type ->
                    FilterChip(
                        selected = state.type == type,
                        onClick = { viewModel.setType(type) },
                        label = { Text(stringResource(type.labelRes())) },
                        shape = AppCorner.Chip,
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionLabel(stringResource(R.string.report_label_format))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportFormat.entries.forEach { format ->
                    FilterChip(
                        selected = state.format == format,
                        onClick = { viewModel.setFormat(format) },
                        label = { Text(if (format == ReportFormat.PDF) "PDF" else "Excel") },
                        leadingIcon = {
                            Icon(
                                imageVector = if (format == ReportFormat.PDF) Icons.Filled.Description
                                else Icons.Filled.TableChart,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                        },
                        shape = AppCorner.Chip,
                    )
                }
            }

            if (classNames.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                SectionLabel(stringResource(R.string.report_label_class))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = state.selectedClass == null,
                        onClick = { viewModel.setClass(null) },
                        label = { Text(stringResource(R.string.filter_all_classes)) },
                        shape = AppCorner.Chip,
                    )
                    classNames.forEach { name ->
                        FilterChip(
                            selected = state.selectedClass == name,
                            onClick = { viewModel.setClass(name) },
                            label = { Text(name) },
                            shape = AppCorner.Chip,
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            PrimaryButton(
                text = stringResource(R.string.action_generate_report),
                onClick = { viewModel.generate(accentColor) },
                loading = state.isGenerating,
            )

            if (state.existingFiles.isNotEmpty()) {
                Spacer(Modifier.height(24.dp))
                SectionLabel(stringResource(R.string.report_label_saved))
                Spacer(Modifier.height(6.dp))
                state.existingFiles.forEach { file ->
                    ReportFileRow(
                        file = file,
                        dateText = DateFormat.dateTime(file.lastModified(), locale),
                        onShare = { shareFile(context, file) },
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = 6.dp),
    )
}

@Composable
private fun ReportFileRow(file: File, dateText: String, onShare: () -> Unit) {
    Card(
        shape = AppCorner.Card,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = if (file.extension == "pdf") Icons.Filled.Description
                else Icons.Filled.TableChart,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = file.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                )
                Text(
                    text = dateText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onShare) {
                Icon(
                    Icons.Filled.Share,
                    contentDescription = stringResource(R.string.action_share),
                )
            }
        }
    }
}

/**
 * Shares via FileProvider — a raw `file://` Uri would throw FileUriExposedException
 * on API 24+, so the content:// grant is mandatory, not optional polish.
 */
private fun shareFile(context: android.content.Context, file: File) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val mime = if (file.extension == "pdf") {
        "application/pdf"
    } else {
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(
        Intent.createChooser(intent, context.getString(R.string.action_share))
    )
}

@androidx.annotation.StringRes
private fun ReportType.labelRes(): Int = when (this) {
    ReportType.CLASS_SUMMARY -> R.string.report_type_class_summary
    ReportType.STUDENT_DETAIL -> R.string.report_type_student_detail
    ReportType.HOMEWORK_DETAIL -> R.string.report_type_homework_detail
}
