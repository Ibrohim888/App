package com.teacherhomework.manager.data.report

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * On-device PDF generation using Android's built-in [PdfDocument].
 *
 * No third-party PDF dependency and no Cloud Function — both are ruled out by
 * the free-tier policy, and `PdfDocument` is part of the platform, so it adds
 * nothing to the APK.
 *
 * LAYOUT: A4 at 72dpi (595×842pt), with automatic pagination — when the cursor
 * passes the bottom margin a new page starts and the table header is REPEATED,
 * so a 120-student table stays readable rather than orphaning its columns.
 *
 * All labels are passed in already localized by the caller; this class never
 * contains user-facing English (LOCALIZATION POLICY — report scaffolding renders
 * in the teacher's chosen app language).
 */
@Singleton
class PdfReportWriter @Inject constructor() {

    /** A table to render: column titles plus rows of already-formatted strings. */
    data class Table(
        val columns: List<String>,
        val rows: List<List<String>>,
        /** Relative column widths; must have the same size as [columns]. */
        val weights: List<Float> = List(columns.size) { 1f },
    )

    /** One summary figure rendered in the header band. */
    data class SummaryStat(val label: String, val value: String)

    /**
     * Renders a report and returns the written file.
     *
     * @param title main heading, localized by the caller
     * @param subtitle context line (class, date range), localized
     * @param generatedOnLabel e.g. the localized "Generated on" prefix
     * @param generatedOnValue formatted timestamp in the teacher's locale
     */
    fun write(
        file: File,
        title: String,
        subtitle: String,
        generatedOnLabel: String,
        generatedOnValue: String,
        stats: List<SummaryStat>,
        table: Table,
        accentColor: Int,
    ): File {
        val document = PdfDocument()
        val state = RenderState(document, accentColor)

        state.startPage()
        state.drawTitleBlock(title, subtitle, "$generatedOnLabel: $generatedOnValue")
        if (stats.isNotEmpty()) state.drawStats(stats)
        state.drawTable(table)
        state.finishPage()

        file.parentFile?.mkdirs()
        file.outputStream().use { document.writeTo(it) }
        document.close()
        return file
    }

    /**
     * Holds the pagination cursor and paints. Kept private to this file because
     * it is meaningless outside one render pass.
     */
    private class RenderState(
        private val document: PdfDocument,
        private val accentColor: Int,
    ) {
        private var pageNumber = 1
        private var page: PdfDocument.Page? = null
        private var canvas: Canvas? = null
        private var y = MARGIN

        /** Repeated at the top of every continuation page. */
        private var currentTable: Table? = null

        private val titlePaint = Paint().apply {
            isAntiAlias = true
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            color = Color.BLACK
        }
        private val subtitlePaint = Paint().apply {
            isAntiAlias = true
            textSize = 11f
            color = Color.DKGRAY
        }
        private val metaPaint = Paint().apply {
            isAntiAlias = true
            textSize = 9f
            color = Color.GRAY
        }
        private val headerPaint = Paint().apply {
            isAntiAlias = true
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            color = Color.WHITE
        }
        private val cellPaint = Paint().apply {
            isAntiAlias = true
            textSize = 10f
            color = Color.BLACK
        }
        private val accentFill = Paint().apply {
            isAntiAlias = true
            color = accentColor
        }
        private val rowStripe = Paint().apply {
            isAntiAlias = true
            color = Color.parseColor("#F5F5F5")
        }
        private val statBoxPaint = Paint().apply {
            isAntiAlias = true
            color = Color.parseColor("#EFEFEF")
        }

        fun startPage() {
            val info = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            page = document.startPage(info)
            canvas = page?.canvas
            y = MARGIN
        }

        fun finishPage() {
            val p = page ?: return
            // Page number footer, drawn last so it isn't affected by the cursor.
            canvas?.drawText(
                pageNumber.toString(),
                (PAGE_WIDTH / 2).toFloat(),
                (PAGE_HEIGHT - 24).toFloat(),
                metaPaint,
            )
            document.finishPage(p)
            page = null
            canvas = null
        }

        /** Closes the current page and opens the next, repeating the table header. */
        private fun newPage() {
            finishPage()
            pageNumber++
            startPage()
            currentTable?.let { drawTableHeader(it) }
        }

        /** Starts a new page if [needed] points wouldn't fit below the cursor. */
        private fun ensureSpace(needed: Float) {
            if (y + needed > PAGE_HEIGHT - MARGIN) newPage()
        }

        fun drawTitleBlock(title: String, subtitle: String, meta: String) {
            val c = canvas ?: return
            c.drawText(title, MARGIN, y + 18f, titlePaint)
            y += 30f
            if (subtitle.isNotBlank()) {
                c.drawText(subtitle, MARGIN, y, subtitlePaint)
                y += 16f
            }
            c.drawText(meta, MARGIN, y, metaPaint)
            y += 22f
        }

        fun drawStats(stats: List<SummaryStat>) {
            val c = canvas ?: return
            ensureSpace(STAT_BOX_HEIGHT + 16f)
            val usable = PAGE_WIDTH - 2 * MARGIN
            val boxWidth = (usable - (stats.size - 1) * STAT_GAP) / stats.size

            stats.forEachIndexed { index, stat ->
                val left = MARGIN + index * (boxWidth + STAT_GAP)
                c.drawRoundRect(
                    left, y, left + boxWidth, y + STAT_BOX_HEIGHT, 8f, 8f, statBoxPaint,
                )
                val valuePaint = Paint(titlePaint).apply { textSize = 15f; color = accentColor }
                c.drawText(stat.value, left + 10f, y + 24f, valuePaint)
                c.drawText(stat.label, left + 10f, y + 40f, metaPaint)
            }
            y += STAT_BOX_HEIGHT + 20f
        }

        fun drawTable(table: Table) {
            currentTable = table
            ensureSpace(ROW_HEIGHT * 2)
            drawTableHeader(table)

            table.rows.forEachIndexed { index, row ->
                ensureSpace(ROW_HEIGHT)
                val c = canvas ?: return
                // Zebra striping makes long rosters easier to read across.
                if (index % 2 == 1) {
                    c.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT, rowStripe)
                }
                var x = MARGIN
                columnWidths(table).forEachIndexed { colIndex, width ->
                    val text = row.getOrNull(colIndex).orEmpty()
                    c.drawText(truncate(text, width, cellPaint), x + CELL_PAD, y + 13f, cellPaint)
                    x += width
                }
                y += ROW_HEIGHT
            }
        }

        private fun drawTableHeader(table: Table) {
            val c = canvas ?: return
            c.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT, accentFill)
            var x = MARGIN
            columnWidths(table).forEachIndexed { index, width ->
                val text = table.columns.getOrNull(index).orEmpty()
                c.drawText(truncate(text, width, headerPaint), x + CELL_PAD, y + 13f, headerPaint)
                x += width
            }
            y += ROW_HEIGHT
        }

        private fun columnWidths(table: Table): List<Float> {
            val usable = PAGE_WIDTH - 2 * MARGIN
            val total = table.weights.sum().takeIf { it > 0f } ?: 1f
            return table.weights.map { usable * (it / total) }
        }

        /**
         * Clips text to its column with an ellipsis. PdfDocument has no text
         * layout engine, so an over-long cell would otherwise draw straight
         * across its neighbours.
         */
        private fun truncate(text: String, columnWidth: Float, paint: Paint): String {
            val available = columnWidth - 2 * CELL_PAD
            if (paint.measureText(text) <= available) return text
            var end = text.length
            while (end > 1 && paint.measureText(text.substring(0, end) + "…") > available) {
                end--
            }
            return text.substring(0, end) + "…"
        }

        companion object {
            // A4 at 72dpi.
            const val PAGE_WIDTH = 595
            const val PAGE_HEIGHT = 842
            const val MARGIN = 36f
            const val ROW_HEIGHT = 18f
            const val CELL_PAD = 4f
            const val STAT_BOX_HEIGHT = 48f
            const val STAT_GAP = 8f
        }
    }
}
