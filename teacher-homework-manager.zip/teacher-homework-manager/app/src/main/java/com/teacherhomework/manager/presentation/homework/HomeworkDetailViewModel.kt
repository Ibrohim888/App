package com.teacherhomework.manager.presentation.homework

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.usecase.CheckHomeworkDeletionUseCase
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import com.teacherhomework.manager.presentation.navigation.NavRoutes
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Progress rollup for one assignment, shown above the per-student breakdown. */
data class HomeworkProgress(
    val checked: Int = 0,
    val completed: Int = 0,
    val partial: Int = 0,
    val missing: Int = 0,
)

/**
 * The delete confirmation the UI is currently showing, if any.
 *
 * POLICY OVERRIDE (teacher decision): a graded homework is NOT protected from
 * deletion. [WithResults] carries the count so the dialog can spell out exactly
 * how many recorded grades will be destroyed, but confirming it goes through.
 */
sealed interface DeletePrompt {
    data object None : DeletePrompt
    data object Simple : DeletePrompt
    data class WithResults(val resultCount: Int) : DeletePrompt
}

data class HomeworkDetailUiState(
    val deletePrompt: DeletePrompt = DeletePrompt.None,
    val isWorking: Boolean = false,
    val finished: Boolean = false,
    val error: AppError? = null,
)

/**
 * One assignment: its fields, its grading progress, and its lifecycle actions
 * (edit, archive, delete).
 */
@HiltViewModel
class HomeworkDetailViewModel @Inject constructor(
    private val homeworkRepository: HomeworkRepository,
    private val checkHomeworkDeletion: CheckHomeworkDeletionUseCase,
    resultRepository: ResultRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val homeworkId: String = savedStateHandle[NavRoutes.ARG_HOMEWORK_ID] ?: ""

    private val _uiState = MutableStateFlow(HomeworkDetailUiState())
    val uiState: StateFlow<HomeworkDetailUiState> = _uiState.asStateFlow()

    val homework: StateFlow<Homework?> = homeworkRepository.observeHomeworkById(homeworkId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val progress: StateFlow<HomeworkProgress> = resultRepository
        .observeResultsForHomework(homeworkId)
        .map { results ->
            HomeworkProgress(
                checked = results.size,
                completed = results.count { it.completionStatus == CompletionStatus.COMPLETED },
                partial = results.count { it.completionStatus == CompletionStatus.PARTIAL },
                missing = results.count { it.completionStatus == CompletionStatus.MISSING },
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeworkProgress())

    /**
     * Called when the teacher taps Delete. Decides WHICH confirmation to show —
     * never whether deletion is allowed, because it always is. If grades exist,
     * the prompt names the count so the consequence is explicit.
     */
    fun requestDelete() = viewModelScope.launch {
        val prompt = when (val decision = checkHomeworkDeletion(homeworkId)) {
            is CheckHomeworkDeletionUseCase.Decision.DirectDelete -> DeletePrompt.Simple
            is CheckHomeworkDeletionUseCase.Decision.NeedsConfirmation ->
                DeletePrompt.WithResults(decision.resultCount)
        }
        _uiState.update { it.copy(deletePrompt = prompt) }
    }

    fun dismissDeletePrompt() = _uiState.update { it.copy(deletePrompt = DeletePrompt.None) }

    /**
     * Performs the delete the teacher just confirmed. Cascades to every result
     * for this homework and recalculates statistics (handled in the repository).
     */
    fun confirmDelete() = viewModelScope.launch {
        _uiState.update { it.copy(deletePrompt = DeletePrompt.None, isWorking = true) }
        val result = homeworkRepository.deleteHomework(homeworkId)
        _uiState.update {
            it.copy(
                isWorking = false,
                // The local delete already succeeded even if the remote leg
                // failed, so leaving the screen is correct either way.
                finished = true,
                error = (result as? AppResult.Error)?.error,
            )
        }
    }

    fun archive() = viewModelScope.launch {
        _uiState.update { it.copy(isWorking = true) }
        val result = homeworkRepository.archiveHomework(homeworkId)
        _uiState.update {
            it.copy(
                isWorking = false,
                finished = result is AppResult.Success,
                error = (result as? AppResult.Error)?.error,
            )
        }
    }

    fun consumeError() = _uiState.update { it.copy(error = null) }
}
