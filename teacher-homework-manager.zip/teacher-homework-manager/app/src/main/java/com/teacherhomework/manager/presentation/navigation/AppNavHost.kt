package com.teacherhomework.manager.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.teacherhomework.manager.domain.model.AppLanguage
import com.teacherhomework.manager.domain.model.AppThemeColor
import com.teacherhomework.manager.presentation.AppUiState
import com.teacherhomework.manager.presentation.about.AboutScreen
import com.teacherhomework.manager.presentation.auth.ForgotPasswordScreen
import com.teacherhomework.manager.presentation.auth.LoginScreen
import com.teacherhomework.manager.presentation.auth.RegisterScreen
import com.teacherhomework.manager.presentation.checking.CheckingScreen
import com.teacherhomework.manager.presentation.homework.HomeworkDetailScreen
import com.teacherhomework.manager.presentation.homework.HomeworkFormScreen
import com.teacherhomework.manager.presentation.main.MainScreen
import com.teacherhomework.manager.presentation.notifications.NotificationCenterScreen
import com.teacherhomework.manager.presentation.onboarding.LanguageSelectionScreen
import com.teacherhomework.manager.presentation.onboarding.ThemeColorSelectionScreen
import com.teacherhomework.manager.presentation.reports.ReportsScreen
import com.teacherhomework.manager.presentation.settings.SettingsScreen
import com.teacherhomework.manager.presentation.splash.SplashScreen
import com.teacherhomework.manager.presentation.students.StudentDetailScreen
import com.teacherhomework.manager.presentation.students.StudentFormScreen

/**
 * Top-level navigation graph enforcing the MANDATORY launch sequence:
 *
 *   splash → (first launch only) languageSelection → themeSelection
 *          → auth (login/register/forgot) → main
 *
 * The splash destination reads [uiState] plus the Firebase session and routes:
 *  - language not chosen → Language Selection (then Theme Selection)
 *  - language chosen, theme not → Theme Selection
 *  - both chosen + signed in → straight to Main (auto-login on relaunch)
 *  - both chosen + signed out → Login
 *
 * BACK BEHAVIOUR: every forward transition that shouldn't be re-enterable pops
 * its origin (`popUpTo(..., inclusive = true)`), so Back from the Dashboard exits
 * the app rather than walking backwards into Login or the onboarding screens.
 */
@Composable
fun AppNavHost(
    uiState: AppUiState,
    onLanguageSelected: (AppLanguage) -> Unit,
    onThemeSelected: (AppThemeColor) -> Unit,
    navController: NavHostController = rememberNavController(),
) {
    NavHost(
        navController = navController,
        startDestination = NavRoutes.SPLASH,
    ) {
        composable(NavRoutes.SPLASH) {
            SplashScreen(
                uiState = uiState,
                onRouteToLanguage = {
                    navController.navigate(NavRoutes.LANGUAGE_SELECTION) {
                        popUpTo(NavRoutes.SPLASH) { inclusive = true }
                    }
                },
                onRouteToTheme = {
                    navController.navigate(NavRoutes.THEME_SELECTION) {
                        popUpTo(NavRoutes.SPLASH) { inclusive = true }
                    }
                },
                onRouteToAuth = {
                    navController.navigate(NavRoutes.LOGIN) {
                        popUpTo(NavRoutes.SPLASH) { inclusive = true }
                    }
                },
                onRouteToMain = {
                    navController.navigate(NavRoutes.MAIN) {
                        popUpTo(NavRoutes.SPLASH) { inclusive = true }
                    }
                },
            )
        }

        composable(NavRoutes.LANGUAGE_SELECTION) {
            LanguageSelectionScreen(
                onContinue = { language ->
                    onLanguageSelected(language)
                    val next = if (uiState.needsThemeSelection) NavRoutes.THEME_SELECTION
                    else NavRoutes.LOGIN
                    navController.navigate(next) {
                        popUpTo(NavRoutes.LANGUAGE_SELECTION) { inclusive = true }
                    }
                },
            )
        }

        composable(NavRoutes.THEME_SELECTION) {
            ThemeColorSelectionScreen(
                onContinue = { theme ->
                    onThemeSelected(theme)
                    navController.navigate(NavRoutes.LOGIN) {
                        popUpTo(NavRoutes.THEME_SELECTION) { inclusive = true }
                    }
                },
            )
        }

        // ---- Auth ----

        composable(NavRoutes.LOGIN) {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(NavRoutes.MAIN) {
                        popUpTo(NavRoutes.LOGIN) { inclusive = true }
                    }
                },
                onNavigateToRegister = { navController.navigate(NavRoutes.REGISTER) },
                onNavigateToForgotPassword = { navController.navigate(NavRoutes.FORGOT_PASSWORD) },
            )
        }

        composable(NavRoutes.REGISTER) {
            RegisterScreen(
                onRegisterSuccess = {
                    navController.navigate(NavRoutes.MAIN) {
                        popUpTo(NavRoutes.LOGIN) { inclusive = true }
                    }
                },
                onNavigateToLogin = { navController.popBackStack() },
                onNavigateBack = { navController.popBackStack() },
            )
        }

        composable(NavRoutes.FORGOT_PASSWORD) {
            ForgotPasswordScreen(onNavigateBack = { navController.popBackStack() })
        }

        // ---- Main shell (bottom nav) ----

        composable(NavRoutes.MAIN) {
            MainScreen(
                onOpenStudent = { navController.navigate(NavRoutes.studentDetail(it)) },
                onAddStudent = { navController.navigate(NavRoutes.studentEdit()) },
                onOpenHomework = { navController.navigate(NavRoutes.homeworkDetail(it)) },
                onAddHomework = { navController.navigate(NavRoutes.homeworkEdit()) },
                onStartChecking = { navController.navigate(NavRoutes.checking(it)) },
                onOpenSettings = { navController.navigate(NavRoutes.SETTINGS) },
                onOpenNotifications = { navController.navigate(NavRoutes.NOTIFICATIONS) },
                onOpenReports = { navController.navigate(NavRoutes.REPORTS) },
            )
        }

        // ---- Students ----

        composable(
            route = NavRoutes.STUDENT_DETAIL,
            arguments = listOf(navArgument(NavRoutes.ARG_STUDENT_ID) { type = NavType.StringType }),
        ) {
            StudentDetailScreen(
                onNavigateBack = { navController.popBackStack() },
                onEdit = { navController.navigate(NavRoutes.studentEdit(it)) },
                onOpenHomework = { navController.navigate(NavRoutes.homeworkDetail(it)) },
            )
        }

        composable(
            route = NavRoutes.STUDENT_EDIT,
            arguments = listOf(navArgument(NavRoutes.ARG_STUDENT_ID) { type = NavType.StringType }),
        ) {
            StudentFormScreen(
                onNavigateBack = { navController.popBackStack() },
                onSaved = { navController.popBackStack() },
            )
        }

        // ---- Homework ----

        composable(
            route = NavRoutes.HOMEWORK_DETAIL,
            arguments = listOf(navArgument(NavRoutes.ARG_HOMEWORK_ID) { type = NavType.StringType }),
        ) {
            HomeworkDetailScreen(
                onNavigateBack = { navController.popBackStack() },
                onEdit = { navController.navigate(NavRoutes.homeworkEdit(it)) },
                onStartChecking = { navController.navigate(NavRoutes.checking(it)) },
            )
        }

        composable(
            route = NavRoutes.HOMEWORK_EDIT,
            arguments = listOf(navArgument(NavRoutes.ARG_HOMEWORK_ID) { type = NavType.StringType }),
        ) {
            HomeworkFormScreen(
                onNavigateBack = { navController.popBackStack() },
                onSaved = { navController.popBackStack() },
            )
        }

        composable(
            route = NavRoutes.CHECKING,
            arguments = listOf(navArgument(NavRoutes.ARG_HOMEWORK_ID) { type = NavType.StringType }),
        ) {
            CheckingScreen(onNavigateBack = { navController.popBackStack() })
        }

        // ---- Settings & extras ----

        composable(NavRoutes.SETTINGS) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() },
                onSignedOut = {
                    // Clear the whole back stack: after signing out, Back must
                    // never return to a screen showing the previous account's data.
                    navController.navigate(NavRoutes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                },
                onOpenReports = { navController.navigate(NavRoutes.REPORTS) },
                onOpenAbout = { navController.navigate(NavRoutes.ABOUT) },
            )
        }

        composable(NavRoutes.NOTIFICATIONS) {
            NotificationCenterScreen(
                onNavigateBack = { navController.popBackStack() },
                onOpenDeepLink = { /* Deep links resolve inside MainScreen's tabs. */ },
            )
        }

        composable(NavRoutes.REPORTS) {
            ReportsScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(NavRoutes.ABOUT) {
            AboutScreen(onNavigateBack = { navController.popBackStack() })
        }
    }
}
