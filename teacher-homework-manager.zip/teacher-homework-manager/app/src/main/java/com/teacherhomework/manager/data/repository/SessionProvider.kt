package com.teacherhomework.manager.data.repository

import com.google.firebase.auth.FirebaseAuth
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Answers "which teacher is signed in right now?" for the repository layer.
 *
 * Every Firestore path in this app is scoped under `teachers/{teacherId}`, so
 * repositories need the uid on nearly every call. Centralizing it here (instead
 * of injecting FirebaseAuth into six repositories) keeps the "not signed in"
 * branch in one place and makes it swappable in tests.
 */
@Singleton
class SessionProvider @Inject constructor(
    private val auth: FirebaseAuth,
) {
    /** Current teacher uid, or null when signed out. */
    val teacherId: String?
        get() = auth.currentUser?.uid

    /**
     * Current teacher uid, or throws. Use inside repository methods that are only
     * reachable from authenticated screens — the throw is caught by the calling
     * repository's runCatching wrapper and surfaces as AppError.PERMISSION_DENIED
     * rather than crashing the app.
     */
    fun requireTeacherId(): String =
        teacherId ?: throw IllegalStateException("No authenticated teacher")
}
