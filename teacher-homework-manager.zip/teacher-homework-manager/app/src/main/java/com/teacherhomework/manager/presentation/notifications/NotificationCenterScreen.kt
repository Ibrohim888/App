package com.teacherhomework.manager.presentation.notifications

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.EmptyStatePlaceholder
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.util.DateFormat
import com.teacherhomework.manager.workers.DeadlineReminderWorker
import com.teacherhomework.manager.workers.MissingHomeworkWorker
import com.teacherhomework.manager.workers.WeeklySummaryWorker

/**
 * In-app history of every local notification that was posted.
 *
 * Each entry is RE-RENDERED from its stored type + params at display time, so
 * this list is always entirely in the teacher's current language — even for
 * notifications posted before they switched languages.
 */
@Composable
fun NotificationCenterScreen(
    onNavigateBack: () -> Unit,
    onOpenDeepLink: (String) -> Unit,
    viewModel: NotificationCenterViewModel = hiltViewModel(),
) {
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val locale = LocalConfiguration.current.locales[0]

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.nav_notifications),
                onNavigateBack = onNavigateBack,
            )
        },
    ) { padding ->
        if (notifications.isEmpty()) {
            EmptyStatePlaceholder(
                icon = Icons.Outlined.NotificationsNone,
                title = stringResource(R.string.empty_notifications_title),
                message = stringResource(R.string.empty_notifications_message),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
            )
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(notifications, key = { it.id }) { item ->
                NotificationRow(
                    item = item,
                    dateText = DateFormat.dateTime(item.postedAt, locale),
                    onClick = {
                        viewModel.markRead(item.id)
                        item.deepLink?.let(onOpenDeepLink)
                    },
                )
            }
        }
    }
}

@Composable
private fun NotificationRow(
    item: NotificationItem,
    dateText: String,
    onClick: () -> Unit,
) {
    val icon: ImageVector = when (item.type) {
        DeadlineReminderWorker.TYPE_DEADLINE -> Icons.Filled.Schedule
        MissingHomeworkWorker.TYPE_MISSING -> Icons.Filled.Warning
        WeeklySummaryWorker.TYPE_WEEKLY -> Icons.Filled.BarChart
        else -> Icons.Filled.Assignment
    }

    Card(
        onClick = onClick,
        shape = AppCorner.Card,
        colors = CardDefaults.cardColors(
            // Unread entries sit on the tinted container so they stand out from
            // already-seen ones without needing a separate badge.
            containerColor = if (item.read) MaterialTheme.colorScheme.surface
            else MaterialTheme.colorScheme.secondaryContainer
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = notificationTitle(item),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = if (item.read) FontWeight.Medium else FontWeight.Bold,
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = notificationBody(item),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    text = dateText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** Renders the stored type into a localized title. */
@Composable
private fun notificationTitle(item: NotificationItem): String = when (item.type) {
    DeadlineReminderWorker.TYPE_DEADLINE -> stringResource(R.string.notif_deadline_title)
    MissingHomeworkWorker.TYPE_MISSING -> stringResource(R.string.notif_missing_title)
    WeeklySummaryWorker.TYPE_WEEKLY -> stringResource(R.string.notif_weekly_title)
    else -> stringResource(R.string.app_name)
}

/**
 * Renders the stored params into a localized body. Missing/garbled params fall
 * back to 0 rather than throwing — a corrupt history row must not break the list.
 */
@Composable
private fun notificationBody(item: NotificationItem): String = when (item.type) {
    DeadlineReminderWorker.TYPE_DEADLINE -> {
        val count = item.params["count"]?.toIntOrNull() ?: 1
        if (count == 1 && !item.params["title"].isNullOrBlank()) {
            stringResource(R.string.notif_deadline_history_single, item.params["title"]!!)
        } else {
            pluralStringResource(R.plurals.notif_deadline_body_multi, count, count)
        }
    }
    MissingHomeworkWorker.TYPE_MISSING -> {
        val ungraded = item.params["ungraded"]?.toIntOrNull() ?: 0
        val assignments = item.params["assignments"]?.toIntOrNull() ?: 0
        pluralStringResource(R.plurals.notif_missing_body, ungraded, ungraded, assignments)
    }
    WeeklySummaryWorker.TYPE_WEEKLY -> stringResource(
        R.string.notif_weekly_body,
        item.params["checked"]?.toIntOrNull() ?: 0,
        item.params["rate"]?.toIntOrNull() ?: 0,
    )
    else -> ""
}
