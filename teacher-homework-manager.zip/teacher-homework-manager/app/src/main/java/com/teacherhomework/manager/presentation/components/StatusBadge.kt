package com.teacherhomework.manager.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.teacherhomework.manager.R
import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.theme.LocalStatusColors

/**
 * Pill-shaped status badge — UI STYLE DIRECTION: soft tinted background with
 * saturated same-hue text, never a solid saturated fill with white text.
 */
@Composable
fun StatusBadge(
    text: String,
    backgroundColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .clip(AppCorner.Badge)
            .background(backgroundColor)
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
        Text(
            text = text,
            color = textColor,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/**
 * Badge for a RESULT STATUS (one student's completion of one homework).
 *
 * ACCESSIBILITY: the status is carried by the localized LABEL, not only by the
 * color — a teacher with color-vision deficiency reads the same information.
 */
@Composable
fun CompletionStatusBadge(status: CompletionStatus, modifier: Modifier = Modifier) {
    val colors = LocalStatusColors.current
    val (bg, fg, labelRes) = when (status) {
        CompletionStatus.COMPLETED ->
            Triple(colors.completedBg, colors.completedText, R.string.status_completed)
        CompletionStatus.PARTIAL ->
            Triple(colors.partialBg, colors.partialText, R.string.status_partial)
        CompletionStatus.MISSING ->
            Triple(colors.missingBg, colors.missingText, R.string.status_missing)
    }
    StatusBadge(stringResource(labelRes), bg, fg, modifier)
}

/**
 * Badge for a HOMEWORK STATUS (the assignment's own lifecycle). Deliberately a
 * separate composable from [CompletionStatusBadge] so the two enums can never be
 * rendered through the same code path — see NAMING DISAMBIGUATION.
 */
@Composable
fun HomeworkStatusBadge(status: HomeworkStatus, modifier: Modifier = Modifier) {
    val colors = LocalStatusColors.current
    val (bg, fg, labelRes) = when (status) {
        HomeworkStatus.DRAFT ->
            Triple(colors.inactiveBg, colors.inactiveText, R.string.homework_status_draft)
        HomeworkStatus.ACTIVE ->
            Triple(colors.partialBg, colors.partialText, R.string.homework_status_active)
        HomeworkStatus.COMPLETED ->
            Triple(colors.completedBg, colors.completedText, R.string.homework_status_completed)
        HomeworkStatus.ARCHIVED ->
            Triple(colors.inactiveBg, colors.inactiveText, R.string.homework_status_archived)
    }
    StatusBadge(stringResource(labelRes), bg, fg, modifier)
}
