package com.teacherhomework.manager.presentation.util

import androidx.annotation.StringRes
import com.teacherhomework.manager.R
import com.teacherhomework.manager.domain.util.AppError

/**
 * Maps a UI-agnostic [AppError] to a localized string resource.
 *
 * This is the ONLY place where an error kind becomes user-facing text, which is
 * what keeps every error message translatable in all three languages — the data
 * layer never carries English strings (LOCALIZATION POLICY).
 */
@StringRes
fun AppError.toStringRes(): Int = when (this) {
    AppError.NETWORK -> R.string.error_network
    AppError.INVALID_EMAIL -> R.string.error_invalid_email
    AppError.WEAK_PASSWORD -> R.string.error_weak_password
    AppError.WRONG_CREDENTIALS -> R.string.error_wrong_credentials
    AppError.EMAIL_ALREADY_IN_USE -> R.string.error_email_in_use
    AppError.USER_NOT_FOUND -> R.string.error_user_not_found
    AppError.PASSWORDS_DO_NOT_MATCH -> R.string.error_passwords_mismatch
    AppError.EMPTY_FIELD -> R.string.error_empty_field
    AppError.GRADE_OUT_OF_RANGE -> R.string.error_grade_out_of_range
    AppError.DEADLINE_BEFORE_ASSIGNED -> R.string.error_deadline_before_assigned
    AppError.HOMEWORK_HAS_RESULTS -> R.string.error_homework_has_results
    AppError.FILE_TOO_LARGE -> R.string.error_file_too_large
    AppError.UNSUPPORTED_FILE_TYPE -> R.string.error_unsupported_file_type
    AppError.PERMISSION_DENIED -> R.string.error_permission_denied
    AppError.UNKNOWN -> R.string.error_unknown
}
