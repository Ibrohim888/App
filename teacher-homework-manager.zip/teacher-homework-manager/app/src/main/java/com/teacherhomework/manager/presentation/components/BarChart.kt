package com.teacherhomework.manager.presentation.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/** One bar: a label for the x-axis and a value on the shared y-scale. */
data class BarEntry(val label: String, val value: Double)

/**
 * A small dependency-free bar chart drawn on a Compose [Canvas].
 *
 * WHY NOT A CHART LIBRARY: the app needs exactly one chart shape (a value per
 * time bucket), and every Android charting library would add size and another
 * R8 surface for something ~80 lines of Canvas code covers. This also keeps the
 * chart theme-aware for free, since it reads MaterialTheme colors directly.
 *
 * ACCESSIBILITY: charts are invisible to screen readers by default, so the whole
 * chart carries a content description listing each label/value pair — the same
 * information the bars convey visually, and the value is printed above each bar
 * rather than being encoded only in bar height.
 */
@Composable
fun BarChart(
    entries: List<BarEntry>,
    modifier: Modifier = Modifier,
    barColor: Color = MaterialTheme.colorScheme.primary,
    maxValue: Double? = null,
    valueFormatter: (Double) -> String = { it.toInt().toString() },
    chartDescription: String = "",
) {
    if (entries.isEmpty()) return

    // A fixed ceiling (e.g. 100 for percentages) keeps successive charts
    // comparable; otherwise the tallest bar defines the scale.
    val ceiling = maxValue ?: entries.maxOf { it.value }.coerceAtLeast(1.0)
    val description = chartDescription.ifBlank {
        entries.joinToString(", ") { "${it.label}: ${valueFormatter(it.value)}" }
    }

    Column(modifier = modifier.semantics { contentDescription = description }) {
        Row(Modifier.fillMaxWidth()) {
            entries.forEach { entry ->
                Text(
                    text = valueFormatter(entry.value),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(4.dp))

        val trackColor = MaterialTheme.colorScheme.surfaceVariant
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            val slot = size.width / entries.size
            // 55% bar / 45% gap reads as distinct columns without looking sparse.
            val barWidth = slot * 0.55f
            val radius = CornerRadius(6f, 6f)

            entries.forEachIndexed { index, entry ->
                val left = index * slot + (slot - barWidth) / 2f
                val fraction = (entry.value / ceiling).coerceIn(0.0, 1.0).toFloat()
                val barHeight = size.height * fraction

                // Faint full-height track so short bars still read as "a bar".
                drawRoundRect(
                    color = trackColor,
                    topLeft = Offset(left, 0f),
                    size = Size(barWidth, size.height),
                    cornerRadius = radius,
                )
                if (barHeight > 0f) {
                    drawRoundRect(
                        color = barColor,
                        topLeft = Offset(left, size.height - barHeight),
                        size = Size(barWidth, barHeight),
                        cornerRadius = radius,
                    )
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth()) {
            entries.forEach { entry ->
                Text(
                    text = entry.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 1.dp),
                )
            }
        }
    }
}
