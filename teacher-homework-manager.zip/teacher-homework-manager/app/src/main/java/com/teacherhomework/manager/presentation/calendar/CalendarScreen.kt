package com.teacherhomework.manager.presentation.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.HomeworkStatusBadge
import com.teacherhomework.manager.presentation.components.OverflowAction
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.util.DateFormat
import java.util.Locale

/**
 * Month calendar of homework deadlines, with the selected day's assignments
 * listed underneath.
 *
 * Each day cell shows a dot when it has deadlines; the count is also exposed in
 * the cell's content description, so the information isn't dot-only for a
 * screen-reader user.
 */
@Composable
fun CalendarScreen(
    onOpenHomework: (String) -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: CalendarViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val days by viewModel.days.collectAsStateWithLifecycle()
    val dayHomework by viewModel.selectedDayHomework.collectAsStateWithLifecycle()
    val locale = LocalConfiguration.current.locales[0]
    val context = LocalContext.current

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.nav_calendar),
                overflowActions = listOf(
                    OverflowAction(
                        label = stringResource(R.string.action_today),
                        onClick = { viewModel.goToToday() },
                    ),
                    OverflowAction(
                        label = stringResource(R.string.nav_settings),
                        onClick = onOpenSettings,
                    ),
                ),
            )
        },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Month header with prev/next controls.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = viewModel::previousMonth) {
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        contentDescription = stringResource(R.string.cd_previous_month),
                    )
                }
                Text(
                    text = DateFormat.monthYear(state.monthAnchor, locale)
                        .replaceFirstChar { it.titlecase(locale) },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = viewModel::nextMonth) {
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = stringResource(R.string.cd_next_month),
                    )
                }
            }

            WeekdayHeader(locale)

            // The month grid: 7 fixed columns, rows of whole weeks.
            Column(Modifier.padding(horizontal = 8.dp)) {
                days.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth()) {
                        week.forEach { day ->
                            DayCell(
                                day = day,
                                isSelected = day.epochMillis == state.selectedDate,
                                onClick = { viewModel.selectDate(day.epochMillis) },
                                contentDescription = if (day.homeworkCount > 0) {
                                    context.resources.getQuantityString(
                                        R.plurals.cd_day_with_homework,
                                        day.homeworkCount,
                                        day.dayOfMonth,
                                        day.homeworkCount,
                                    )
                                } else {
                                    day.dayOfMonth.toString()
                                },
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = DateFormat.date(state.selectedDate, locale),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Spacer(Modifier.height(6.dp))

            if (dayHomework.isEmpty()) {
                Text(
                    text = stringResource(R.string.calendar_no_homework),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(dayHomework, key = { it.id }) { hw ->
                        Card(
                            onClick = { onOpenHomework(hw.id) },
                            shape = AppCorner.Card,
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        text = hw.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                    )
                                    Text(
                                        text = "${hw.subject} · ${hw.className}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                HomeworkStatusBadge(hw.status)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Localized Mon-first weekday initials. */
@Composable
private fun WeekdayHeader(locale: Locale) {
    val symbols = java.text.DateFormatSymbols(locale).shortWeekdays
    // Calendar.MONDAY == 2, so the Mon-first order is indices 2..7 then 1.
    val order = listOf(2, 3, 4, 5, 6, 7, 1)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        order.forEach { index ->
            Text(
                text = symbols[index].take(2),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun DayCell(
    day: CalendarDay,
    isSelected: Boolean,
    onClick: () -> Unit,
    contentDescription: String,
    modifier: Modifier = Modifier,
) {
    val selectedBg = MaterialTheme.colorScheme.primary
    val todayRing = MaterialTheme.colorScheme.primary

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .padding(2.dp)
            .clip(AppCorner.Chip)
            .background(if (isSelected) selectedBg else Color.Transparent)
            .border(
                width = if (day.isToday && !isSelected) 1.5.dp else 0.dp,
                color = if (day.isToday && !isSelected) todayRing else Color.Transparent,
                shape = AppCorner.Chip,
            )
            .clickable(onClick = onClick)
            .semanticsDescription(contentDescription),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = day.dayOfMonth.toString(),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (day.isToday) FontWeight.Bold else FontWeight.Normal,
                color = when {
                    isSelected -> MaterialTheme.colorScheme.onPrimary
                    // Padding days are dimmed so the current month reads clearly.
                    !day.inCurrentMonth -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    else -> MaterialTheme.colorScheme.onSurface
                },
            )
            if (day.homeworkCount > 0) {
                Spacer(Modifier.height(2.dp))
                Box(
                    Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.primary
                        )
                )
            }
        }
    }
}

/** Small helper so the cell's semantics stay readable at the call site. */
private fun Modifier.semanticsDescription(description: String): Modifier =
    this.semantics { contentDescription = description }
