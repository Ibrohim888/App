package com.teacherhomework.manager.presentation.navigation

/**
 * Central list of navigation route constants. Kept as plain strings (rather than
 * scattered literals) so the launch sequence and screens can't drift out of
 * sync. The launch order enforced by [AppNavHost] is:
 *
 *   splash → (first launch) languageSelection → themeSelection → auth → main
 *
 * On a returning launch, splash routes straight past the selection screens, and
 * straight past auth too if a Firebase session is still valid.
 *
 * Parameterized routes expose both the pattern (for `composable(...)`) and a
 * builder function (for `navigate(...)`), so an argument name can never be
 * mistyped at one of the two ends.
 */
object NavRoutes {
    const val SPLASH = "splash"
    const val LANGUAGE_SELECTION = "language_selection"
    const val THEME_SELECTION = "theme_selection"

    const val LOGIN = "login"
    const val REGISTER = "register"
    const val FORGOT_PASSWORD = "forgot_password"

    const val MAIN = "main"

    // Bottom-nav destinations inside MAIN's own nested nav graph.
    const val DASHBOARD = "dashboard"
    const val STUDENTS = "students"
    const val HOMEWORK = "homework"
    const val CALENDAR = "calendar"
    const val STATISTICS = "statistics"

    // ---- Detail / full-screen destinations (pushed above MAIN) ----

    const val ARG_STUDENT_ID = "studentId"
    const val ARG_HOMEWORK_ID = "homeworkId"

    const val STUDENT_DETAIL = "student_detail/{$ARG_STUDENT_ID}"
    fun studentDetail(studentId: String) = "student_detail/$studentId"

    /** `new` (a sentinel, not a real id) opens the form in create mode. */
    const val STUDENT_EDIT = "student_edit/{$ARG_STUDENT_ID}"
    fun studentEdit(studentId: String = NEW) = "student_edit/$studentId"

    const val HOMEWORK_DETAIL = "homework_detail/{$ARG_HOMEWORK_ID}"
    fun homeworkDetail(homeworkId: String) = "homework_detail/$homeworkId"

    const val HOMEWORK_EDIT = "homework_edit/{$ARG_HOMEWORK_ID}"
    fun homeworkEdit(homeworkId: String = NEW) = "homework_edit/$homeworkId"

    /** The grading screen for one homework (Fast Checking Mode lives here). */
    const val CHECKING = "checking/{$ARG_HOMEWORK_ID}"
    fun checking(homeworkId: String) = "checking/$homeworkId"

    const val SETTINGS = "settings"
    const val PROFILE = "profile"
    const val NOTIFICATIONS = "notifications"
    const val REPORTS = "reports"
    const val ABOUT = "about"

    /** Sentinel id meaning "creating a new record" in the edit routes. */
    const val NEW = "new"
}
