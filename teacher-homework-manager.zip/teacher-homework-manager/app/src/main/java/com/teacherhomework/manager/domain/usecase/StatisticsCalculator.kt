package com.teacherhomework.manager.domain.usecase

import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.GradeType
import com.teacherhomework.manager.domain.model.Result
import com.teacherhomework.manager.domain.model.StatisticsSummary
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * The statistics computation, as a PURE function of the results snapshot.
 *
 * Deliberately free of Firebase, Room, and Android so it can be unit-tested
 * directly — this is the single most correctness-sensitive calculation in the
 * app (it feeds every number the teacher sees and every exported report), and
 * burying it inside a repository that needs a live Firestore instance would make
 * it effectively untestable.
 *
 * IDEMPOTENCE is the key property: the output depends only on the input list,
 * never on a previous value or a running total. That is what makes the
 * transactional multi-device commit safe — two devices computing from the same
 * results converge on the same document regardless of write order.
 */
object StatisticsCalculator {

    fun compute(results: List<Result>, activeStudentCount: Int, nowMillis: Long): StatisticsSummary {
        val graded = results.mapNotNull { r -> r.grade?.let { normalize(it, r.gradeType) } }
        val averageGrade = if (graded.isEmpty()) 0.0 else graded.average()

        val completionRate = if (results.isEmpty()) {
            0.0
        } else {
            // PARTIAL counts as half credit: a class that half-finished
            // everything should read as ~50%, not 0% or 100%.
            val score = results.sumOf { weight(it.completionStatus) }
            (score / results.size) * 100.0
        }

        return StatisticsSummary(
            totalStudents = activeStudentCount,
            averageGrade = averageGrade.round2(),
            completionRate = completionRate.round2(),
            missingHomeworkCount = results.count { it.completionStatus == CompletionStatus.MISSING },
            monthlyProgress = bucketAverages(results, ::monthKey),
            weeklyProgress = bucketAverages(results, ::weekKey),
            lastRecalculatedAt = nowMillis,
        )
    }

    fun weight(status: CompletionStatus): Double = when (status) {
        CompletionStatus.COMPLETED -> 1.0
        CompletionStatus.PARTIAL -> 0.5
        CompletionStatus.MISSING -> 0.0
    }

    /**
     * POINT_10 grades are scaled to the 0-100 scale before averaging, so a 9/10
     * and a 90% contribute equally. Averaging the raw values would make the
     * result meaningless as soon as a teacher used both grade types.
     */
    fun normalize(grade: Double, type: GradeType): Double = when (type) {
        GradeType.PERCENT -> grade
        GradeType.POINT_10 -> grade * 10.0
    }

    /** Average normalized grade per time bucket, for the progress charts. */
    private fun bucketAverages(results: List<Result>, keyOf: (Long) -> String): Map<String, Double> =
        results
            .filter { it.grade != null }
            .groupBy { keyOf(it.checkedDate) }
            .mapValues { (_, group) ->
                group.mapNotNull { r -> r.grade?.let { normalize(it, r.gradeType) } }
                    .average()
                    .round2()
            }
            .toSortedMap()

    /**
     * Bucket keys are computed in UTC and zero-padded (`2026-03`, `2026-W07`) so
     * they sort lexicographically and don't shift if the teacher changes time
     * zone — a month's data staying in the same bucket matters more here than
     * matching local midnight exactly.
     */
    private fun utcCalendar(epochMillis: Long): Calendar =
        Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US).apply {
            timeInMillis = epochMillis
            firstDayOfWeek = Calendar.MONDAY
            minimalDaysInFirstWeek = 4 // ISO-8601 week numbering
        }

    fun monthKey(epochMillis: Long): String {
        val c = utcCalendar(epochMillis)
        return String.format(Locale.US, "%04d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1)
    }

    fun weekKey(epochMillis: Long): String {
        val c = utcCalendar(epochMillis)
        return String.format(
            Locale.US,
            "%04d-W%02d",
            c.get(Calendar.YEAR),
            c.get(Calendar.WEEK_OF_YEAR),
        )
    }

    private fun Double.round2(): Double = Math.round(this * 100.0) / 100.0
}
