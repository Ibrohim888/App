package com.teacherhomework.manager.presentation.students

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.GradeType
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.Result
import com.teacherhomework.manager.domain.model.Student
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import com.teacherhomework.manager.presentation.navigation.NavRoutes
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** One row of the student's homework history: the result plus its assignment. */
data class ResultWithHomework(
    val result: Result,
    val homework: Homework?,
)

/** Per-student rollup shown in the header stat row. */
data class StudentStats(
    val total: Int = 0,
    val completed: Int = 0,
    val partial: Int = 0,
    val missing: Int = 0,
    val averageGrade: Double = 0.0,
) {
    /** COMPLETED counts 1.0, PARTIAL 0.5 — matches the global statistics formula. */
    val completionRate: Double
        get() = if (total == 0) 0.0 else ((completed + partial * 0.5) / total) * 100.0
}

data class StudentDetailUiState(
    val isDeleting: Boolean = false,
    val deleted: Boolean = false,
    val error: AppError? = null,
)

/**
 * Student profile: identity, per-student stats, and full homework history.
 *
 * The history joins each result to its homework locally rather than with a
 * Firestore query per row — both collections are already cached in Room, so the
 * join costs zero additional reads (COST AWARENESS).
 */
@HiltViewModel
class StudentDetailViewModel @Inject constructor(
    private val studentRepository: StudentRepository,
    private val resultRepository: ResultRepository,
    homeworkRepository: HomeworkRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val studentId: String = savedStateHandle[NavRoutes.ARG_STUDENT_ID] ?: ""

    private val _uiState = MutableStateFlow(StudentDetailUiState())
    val uiState: StateFlow<StudentDetailUiState> = _uiState.asStateFlow()

    val student: StateFlow<Student?> = studentRepository.observeStudent(studentId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val history: StateFlow<List<ResultWithHomework>> = combine(
        resultRepository.observeResultsForStudent(studentId),
        homeworkRepository.observeHomework(),
    ) { results, homework ->
        val byId = homework.associateBy { it.id }
        results.map { ResultWithHomework(it, byId[it.homeworkId]) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val stats: StateFlow<StudentStats> = resultRepository.observeResultsForStudent(studentId)
        .map { results ->
            val graded = results.mapNotNull { r ->
                r.grade?.let { if (r.gradeType == GradeType.POINT_10) it * 10.0 else it }
            }
            StudentStats(
                total = results.size,
                completed = results.count { it.completionStatus == CompletionStatus.COMPLETED },
                partial = results.count { it.completionStatus == CompletionStatus.PARTIAL },
                missing = results.count { it.completionStatus == CompletionStatus.MISSING },
                averageGrade = if (graded.isEmpty()) 0.0 else graded.average(),
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StudentStats())

    /** Keeps every grade; just hides the student from the active roster. */
    fun archive() = viewModelScope.launch {
        _uiState.update { it.copy(isDeleting = true) }
        val result = studentRepository.softDeleteStudent(studentId)
        _uiState.update {
            it.copy(
                isDeleting = false,
                deleted = result is AppResult.Success,
                error = (result as? AppResult.Error)?.error,
            )
        }
    }

    /** Irreversible: removes the student and every result they have. */
    fun deletePermanently() = viewModelScope.launch {
        _uiState.update { it.copy(isDeleting = true) }
        val result = studentRepository.hardDeleteStudent(studentId)
        _uiState.update {
            it.copy(
                isDeleting = false,
                deleted = result is AppResult.Success,
                error = (result as? AppResult.Error)?.error,
            )
        }
    }

    fun consumeError() = _uiState.update { it.copy(error = null) }
}
