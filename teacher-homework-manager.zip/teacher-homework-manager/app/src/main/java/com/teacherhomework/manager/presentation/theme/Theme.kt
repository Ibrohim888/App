package com.teacherhomework.manager.presentation.theme

import android.content.res.Configuration
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.teacherhomework.manager.domain.model.AppLanguage
import com.teacherhomework.manager.domain.model.AppThemeColor
import java.util.Locale

/**
 * Root theme wrapper for the whole app.
 *
 * Applies three things together so every screen stays consistent:
 *  1. The chosen accent [themeColor] + light/dark [darkTheme] → Material 3
 *     ColorScheme, shapes, typography, plus [LocalStatusColors] /
 *     [LocalAccentGradient] for semantic status and header gradients.
 *  2. The chosen [language] → an in-session locale override (see
 *     [ProvideAppLocale]) so `stringResource` resolves to the teacher's chosen
 *     language immediately, without an app restart and independent of the
 *     device's system locale (LOCALIZATION POLICY).
 *
 * Changing [themeColor], [darkTheme], or [language] recomposes the whole tree,
 * which is exactly how "takes effect immediately, no restart" is achieved.
 *
 * @param darkTheme null means "follow the system setting"; a non-null value is
 *        the teacher's explicit light/dark choice (wired to Settings in Phase 2).
 */
@Composable
fun TeacherAppTheme(
    themeColor: AppThemeColor = AppThemeColor.DEFAULT,
    darkTheme: Boolean? = null,
    language: AppLanguage = AppLanguage.DEFAULT,
    content: @Composable () -> Unit,
) {
    val isDark = darkTheme ?: isSystemInDarkTheme()
    val resolved = remember(themeColor, isDark) { resolveTheme(themeColor, isDark) }

    ProvideAppLocale(language) {
        CompositionLocalProvider(
            LocalStatusColors provides resolved.statusColors,
            LocalAccentGradient provides resolved.gradient,
        ) {
            MaterialTheme(
                colorScheme = resolved.colorScheme,
                typography = AppTypography,
                shapes = AppShapes,
                content = content,
            )
        }
    }
}

/**
 * Overrides the composition's locale so `stringResource`/`painterResource` pick
 * the teacher's chosen [language] rather than the device system language.
 *
 * We rebuild a configuration-scoped Context and provide both it and the updated
 * [Configuration] down the tree — this is the standard Compose pattern for
 * per-app locale that works on plain ComponentActivity (no AppCompatActivity
 * requirement) and updates instantly on language change.
 */
@Composable
fun ProvideAppLocale(language: AppLanguage, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current

    val localizedContext = remember(language, configuration) {
        val locale = Locale(language.tag)
        Locale.setDefault(locale)
        val newConfig = Configuration(configuration).apply { setLocale(locale) }
        context.createConfigurationContext(newConfig)
    }
    val localizedConfiguration = remember(language, configuration) {
        Configuration(configuration).apply { setLocale(Locale(language.tag)) }
    }

    CompositionLocalProvider(
        LocalContext provides localizedContext,
        LocalConfiguration provides localizedConfiguration,
        content = content,
    )
}
