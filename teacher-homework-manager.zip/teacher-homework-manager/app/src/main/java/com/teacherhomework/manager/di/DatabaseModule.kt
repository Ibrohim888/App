package com.teacherhomework.manager.di

import android.content.Context
import androidx.room.Room
import com.teacherhomework.manager.data.local.TeacherDatabase
import com.teacherhomework.manager.data.local.dao.HomeworkDao
import com.teacherhomework.manager.data.local.dao.NotificationDao
import com.teacherhomework.manager.data.local.dao.ResultDao
import com.teacherhomework.manager.data.local.dao.StatisticsDao
import com.teacherhomework.manager.data.local.dao.StudentDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Provides the Room database and its DAOs.
 *
 * `fallbackToDestructiveMigration` is deliberately NOT used: this cache holds
 * the teacher's pending offline writes, and silently wiping it on a schema
 * change could discard grades recorded while offline. Any schema change must
 * ship a real Migration.
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): TeacherDatabase =
        Room.databaseBuilder(context, TeacherDatabase::class.java, TeacherDatabase.NAME)
            .build()

    @Provides
    fun provideStudentDao(db: TeacherDatabase): StudentDao = db.studentDao()

    @Provides
    fun provideHomeworkDao(db: TeacherDatabase): HomeworkDao = db.homeworkDao()

    @Provides
    fun provideResultDao(db: TeacherDatabase): ResultDao = db.resultDao()

    @Provides
    fun provideStatisticsDao(db: TeacherDatabase): StatisticsDao = db.statisticsDao()

    @Provides
    fun provideNotificationDao(db: TeacherDatabase): NotificationDao = db.notificationDao()
}
