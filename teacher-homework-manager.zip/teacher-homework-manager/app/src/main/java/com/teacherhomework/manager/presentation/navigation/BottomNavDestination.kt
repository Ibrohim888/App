package com.teacherhomework.manager.presentation.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.People
import androidx.compose.ui.graphics.vector.ImageVector
import com.teacherhomework.manager.R

/**
 * The 5 bottom-navigation destinations. Labels come from string resources (all
 * three languages) — never hardcoded — per the Phase 1 requirement. Icons use
 * Material's outline set (home, people, book, calendar, bar-chart).
 *
 * Bottom nav is capped at 5 items, matching the navigation guideline.
 */
enum class BottomNavDestination(
    val route: String,
    @StringRes val labelRes: Int,
    val icon: ImageVector,
) {
    DASHBOARD(NavRoutes.DASHBOARD, R.string.nav_dashboard, Icons.Outlined.Home),
    STUDENTS(NavRoutes.STUDENTS, R.string.nav_students, Icons.Outlined.People),
    HOMEWORK(NavRoutes.HOMEWORK, R.string.nav_homework, Icons.Outlined.MenuBook),
    CALENDAR(NavRoutes.CALENDAR, R.string.nav_calendar, Icons.Outlined.CalendarMonth),
    STATISTICS(NavRoutes.STATISTICS, R.string.nav_statistics, Icons.Outlined.BarChart);

    companion object {
        val START = DASHBOARD
    }
}
