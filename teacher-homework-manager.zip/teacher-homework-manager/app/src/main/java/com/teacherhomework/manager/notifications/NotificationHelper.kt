package com.teacherhomework.manager.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.teacherhomework.manager.MainActivity
import com.teacherhomework.manager.R
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * LOCAL notification delivery. There is no FCM, no server push, and no
 * cross-device messaging anywhere in this class or the app — every notification
 * is generated and posted by this same device (FREE-TIER POLICY, permanent).
 *
 * Three channels let the teacher silence one category in Android's own settings
 * without losing the others.
 */
@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    companion object {
        const val CHANNEL_DEADLINES = "deadlines"
        const val CHANNEL_MISSING = "missing_homework"
        const val CHANNEL_SUMMARY = "weekly_summary"

        /**
         * Stable per-category notification ids so a repeated reminder REPLACES
         * the previous one instead of stacking a new card every time the worker
         * runs.
         */
        const val ID_DEADLINE = 1001
        const val ID_MISSING = 1002
        const val ID_SUMMARY = 1003

        /** Intent extra carrying an in-app route for deep linking. */
        const val EXTRA_DEEP_LINK = "extra_deep_link"
    }

    /**
     * Creates the channels. Safe to call repeatedly — re-creating an existing
     * channel is a no-op, so this runs on every app start.
     *
     * Channel NAMES are read from string resources, so they appear in the
     * device's language in Android Settings (the OS caches them, which is why
     * they are the one place we accept the system locale rather than the app's).
     */
    fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_DEADLINES,
                context.getString(R.string.channel_deadlines),
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply { description = context.getString(R.string.channel_deadlines_desc) }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_MISSING,
                context.getString(R.string.channel_missing),
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply { description = context.getString(R.string.channel_missing_desc) }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_SUMMARY,
                context.getString(R.string.channel_summary),
                // Low: a weekly digest should never interrupt a lesson.
                NotificationManager.IMPORTANCE_LOW,
            ).apply { description = context.getString(R.string.channel_summary_desc) }
        )
    }

    /**
     * Posts a notification, silently doing nothing if the POST_NOTIFICATIONS
     * runtime permission (API 33+) hasn't been granted — posting without it
     * throws, and a reminder is never worth crashing the app for.
     *
     * @param title already localized to the TEACHER's chosen app language
     * @param body already localized
     * @param deepLink optional in-app route to open on tap
     */
    fun post(
        channelId: String,
        notificationId: Int,
        title: String,
        body: String,
        deepLink: String? = null,
    ) {
        if (!canPost()) return

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (deepLink != null) putExtra(EXTRA_DEEP_LINK, deepLink)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            // BigTextStyle so a long "5 students haven't submitted…" body isn't
            // truncated in the shade.
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context).notify(notificationId, notification)
    }

    /** True when notifications are permitted (always true below API 33). */
    fun canPost(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
}
