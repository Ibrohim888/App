package com.teacherhomework.manager.presentation.theme

import androidx.compose.ui.graphics.Color

/*
 * Raw color tokens for the app.
 *
 * Two independent axes, per THEME COLOR POLICY:
 *   1. Accent family — one of 5 themes (primary + gradient end).
 *   2. Light / dark mode — orthogonal to the accent.
 *
 * Semantic STATUS colors (completed / partial / missing / inactive) are NOT
 * part of the accent and stay constant across all 5 themes, because they carry
 * meaning (a student's completion status) that must read the same regardless of
 * the teacher's chosen accent.
 */

// ---- Shared warm neutrals (UI STYLE DIRECTION) ----
val WarmBackgroundLight = Color(0xFFFFFBF7) // warm off-white, not stark white
val SurfaceLight = Color(0xFFFFFFFF)        // pure-white cards on the warm bg
val SurfaceVariantLight = Color(0xFFF3ECE4) // subtle tinted surface
val OnBackgroundLight = Color(0xFF241F1A)   // warm near-black text
val OnSurfaceVariantLight = Color(0xFF6F655C)
val OutlineLight = Color(0xFFE3D9CE)

val WarmBackgroundDark = Color(0xFF141210)
val SurfaceDark = Color(0xFF211E1A)
val SurfaceVariantDark = Color(0xFF2C2823)
val OnBackgroundDark = Color(0xFFF3EDE6)
val OnSurfaceVariantDark = Color(0xFFC9BFB4)
val OutlineDark = Color(0xFF453F38)

val White = Color(0xFFFFFFFF)

// ---- Semantic status colors (pill-badge soft-tint treatment) ----
// Light-mode background / text pairs.
val StatusCompletedBg = Color(0xFFE3F6E9)
val StatusCompletedText = Color(0xFF2E9E56)
val StatusPartialBg = Color(0xFFFFF3D6)
val StatusPartialText = Color(0xFFB9791A)
val StatusMissingBg = Color(0xFFFCE4E4)
val StatusMissingText = Color(0xFFD0463B)
val StatusInactiveBg = Color(0xFFECE7E1)
val StatusInactiveText = Color(0xFF8A8078)

// Dark-mode status pairs (same hues, tuned for contrast on dark surfaces).
val StatusCompletedBgDark = Color(0xFF1E3A2A)
val StatusCompletedTextDark = Color(0xFF7BD99E)
val StatusPartialBgDark = Color(0xFF3A2F16)
val StatusPartialTextDark = Color(0xFFE6BE6B)
val StatusMissingBgDark = Color(0xFF3A2020)
val StatusMissingTextDark = Color(0xFFEE8C82)
val StatusInactiveBgDark = Color(0xFF302B25)
val StatusInactiveTextDark = Color(0xFFA79E94)

// ---- Accent families (primary, gradientEnd) per THEME COLOR POLICY ----
// Forest Green
val ForestPrimary = Color(0xFF2E8B7A)
val ForestGradientEnd = Color(0xFF4CAF9E)
val ForestPrimaryDark = Color(0xFF5FC4B2)
// Trust Blue
val BluePrimary = Color(0xFF3D6BC7)
val BlueGradientEnd = Color(0xFF5B87E0)
val BluePrimaryDark = Color(0xFF7EA2EE)
// Violet
val VioletPrimary = Color(0xFF6B5CD9)
val VioletGradientEnd = Color(0xFF8B7BE8)
val VioletPrimaryDark = Color(0xFFA99CF0)
// Warm Rose
val RosePrimary = Color(0xFFD6577A)
val RoseGradientEnd = Color(0xFFE87A98)
val RosePrimaryDark = Color(0xFFF090AB)
// Teal
val TealPrimary = Color(0xFF1E9B8A)
val TealGradientEnd = Color(0xFF17B8A6)
val TealPrimaryDark = Color(0xFF4FD0BF)
