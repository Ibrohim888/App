package com.teacherhomework.manager.presentation.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import com.teacherhomework.manager.R
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.util.DateFormat

/**
 * A read-only text field that opens a Material 3 date picker when tapped.
 *
 * The field itself is `readOnly` rather than disabled: a disabled field is
 * skipped by TalkBack and loses its label contrast, whereas a read-only one
 * stays focusable and announces its value. The whole field is the tap target,
 * comfortably exceeding the 48dp minimum.
 *
 * The picker returns UTC midnight for the chosen day; that is normalized to
 * LOCAL midnight before being handed back, so a date chosen in UTC+5 doesn't
 * land on the previous day locally.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerField(
    label: String,
    value: Long,
    onValueChange: (Long) -> Unit,
    modifier: Modifier = Modifier,
    errorText: String? = null,
) {
    var showPicker by remember { mutableStateOf(false) }
    val locale = LocalConfiguration.current.locales[0]

    OutlinedTextField(
        value = DateFormat.date(value, locale),
        onValueChange = {},
        label = { Text(label) },
        readOnly = true,
        isError = errorText != null,
        shape = AppCorner.Button,
        trailingIcon = { Icon(Icons.Filled.CalendarMonth, contentDescription = null) },
        supportingText = errorText?.let {
            {
                Text(
                    text = it,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error,
                )
            }
        },
        modifier = modifier
            .fillMaxWidth()
            .clickable { showPicker = true },
    )

    if (showPicker) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = value)
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { utcMidnight ->
                        onValueChange(DateFormat.atStartOfDay(utcMidnight))
                    }
                    showPicker = false
                }) { Text(stringResource(R.string.action_ok)) }
            },
            dismissButton = {
                TextButton(onClick = { showPicker = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        ) {
            DatePicker(state = pickerState)
        }
    }
}
