package com.teacherhomework.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.presentation.AppViewModel
import com.teacherhomework.manager.presentation.navigation.AppNavHost
import com.teacherhomework.manager.presentation.theme.TeacherAppTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single-activity host. Applies the teacher's persisted appearance (accent +
 * dark mode) and language to the whole Compose tree via [TeacherAppTheme], so a
 * change to any of them recomposes the entire app instantly (no restart).
 *
 * The system splash is kept on screen until the stored prefs have loaded, so the
 * first real frame is already rendered in the correct theme + language rather
 * than flashing the default first.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val appViewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)

        // Hold the OS splash until the first prefs emission arrives.
        splash.setKeepOnScreenCondition { appViewModel.uiState.value.isLoading }

        enableEdgeToEdge()
        setContent {
            val uiState by appViewModel.uiState.collectAsStateWithLifecycle()

            TeacherAppTheme(
                themeColor = uiState.effectiveThemeColor,
                darkTheme = uiState.darkModePreference.toDarkFlag(),
                language = uiState.effectiveLanguage,
            ) {
                AppNavHost(
                    uiState = uiState,
                    onLanguageSelected = appViewModel::selectLanguage,
                    onThemeSelected = appViewModel::selectThemeColor,
                )
            }
        }
    }
}
