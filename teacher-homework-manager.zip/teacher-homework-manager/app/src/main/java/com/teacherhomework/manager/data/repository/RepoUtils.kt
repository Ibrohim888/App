package com.teacherhomework.manager.data.repository

import com.google.firebase.firestore.FirebaseFirestoreException
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import java.io.IOException

/**
 * Wraps a repository operation, translating thrown exceptions into [AppError]
 * kinds so no raw SDK English text ever reaches the UI (LOCALIZATION POLICY).
 *
 * OFFLINE BEHAVIOUR: a network failure here is not necessarily a user-visible
 * error — writes are applied to Room first and Firestore's own offline queue
 * retries the remote half. Callers decide whether to surface NETWORK or stay
 * silent; see SyncRepository for the reconciliation path.
 */
suspend inline fun <T> runCatchingRepo(block: () -> T): AppResult<T> = try {
    AppResult.Success(block())
} catch (e: FirebaseFirestoreException) {
    val kind = when (e.code) {
        FirebaseFirestoreException.Code.PERMISSION_DENIED -> AppError.PERMISSION_DENIED
        FirebaseFirestoreException.Code.UNAVAILABLE,
        FirebaseFirestoreException.Code.DEADLINE_EXCEEDED,
        -> AppError.NETWORK
        else -> AppError.UNKNOWN
    }
    AppResult.Error(kind, e)
} catch (e: IOException) {
    AppResult.Error(AppError.NETWORK, e)
} catch (e: IllegalStateException) {
    // Thrown by SessionProvider.requireTeacherId() when signed out.
    AppResult.Error(AppError.PERMISSION_DENIED, e)
} catch (e: Exception) {
    AppResult.Error(AppError.UNKNOWN, e)
}
