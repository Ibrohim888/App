package com.teacherhomework.manager.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.domain.model.AppLanguage
import com.teacherhomework.manager.domain.model.AppThemeColor
import com.teacherhomework.manager.domain.model.DarkModePreference
import com.teacherhomework.manager.domain.model.NotificationSettings
import com.teacherhomework.manager.domain.model.Teacher
import com.teacherhomework.manager.domain.model.TeacherSettings
import com.teacherhomework.manager.domain.repository.AuthRepository
import com.teacherhomework.manager.domain.repository.NotificationSettingsRepository
import com.teacherhomework.manager.domain.repository.TeacherRepository
import com.teacherhomework.manager.workers.ReminderScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val signedOut: Boolean = false,
    /** Bytes uploaded so far, for the Storage quota warning. */
    val storageBytesUsed: Long = 0L,
) {
    /**
     * A per-teacher share of the 5 GB free Storage quota. The app warns at 80% of
     * this, well before the account-wide limit is anywhere near reached (FILE
     * UPLOAD CONSTRAINTS).
     */
    val storageQuotaBytes: Long get() = PER_TEACHER_QUOTA_BYTES
    val storageFraction: Float
        get() = (storageBytesUsed.toFloat() / storageQuotaBytes).coerceIn(0f, 1f)
    val showStorageWarning: Boolean get() = storageFraction >= 0.8f

    companion object {
        /** 500 MB — a generous solo-teacher share of the 5 GB free bucket. */
        const val PER_TEACHER_QUOTA_BYTES = 500L * 1024 * 1024
    }
}

/**
 * Settings: appearance, language, local reminders, storage usage, sign out.
 *
 * Changing language or theme writes to DataStore first (instant, offline-safe)
 * and mirrors to Firestore after, which is what makes both changes take effect
 * immediately with no restart.
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val appPreferences: AppPreferences,
    private val teacherRepository: TeacherRepository,
    private val notificationSettingsRepository: NotificationSettingsRepository,
    private val authRepository: AuthRepository,
    private val reminderScheduler: ReminderScheduler,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    // Both are nullable in DataStore (null = "not chosen yet"), but by the time
    // Settings is reachable the first-launch screens have run, so a default is
    // the correct fallback rather than a null the UI would have to handle.
    val language: StateFlow<AppLanguage> = appPreferences.language
        .map { it ?: AppLanguage.DEFAULT }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppLanguage.DEFAULT)

    val themeColor: StateFlow<AppThemeColor> = appPreferences.themeColor
        .map { it ?: AppThemeColor.DEFAULT }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppThemeColor.DEFAULT)

    val darkMode: StateFlow<DarkModePreference> = appPreferences.darkModePreference
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DarkModePreference.DEFAULT)

    val notificationSettings: StateFlow<NotificationSettings> =
        notificationSettingsRepository.observe()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), NotificationSettings())

    val teacher: StateFlow<Teacher?> = teacherRepository.observeTeacher()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    init {
        viewModelScope.launch {
            appPreferences.storageBytesUsed.collect { bytes ->
                _uiState.update { it.copy(storageBytesUsed = bytes) }
            }
        }
    }

    fun setLanguage(value: AppLanguage) = viewModelScope.launch {
        appPreferences.setLanguage(value)
        mirrorSettings()
    }

    fun setThemeColor(value: AppThemeColor) = viewModelScope.launch {
        appPreferences.setThemeColor(value)
        mirrorSettings()
    }

    fun setDarkMode(value: DarkModePreference) = viewModelScope.launch {
        appPreferences.setDarkModePreference(value)
        mirrorSettings()
    }

    /**
     * Persists reminder preferences and immediately re-syncs the WorkManager
     * schedule, so turning something off stops the OS waking us for it rather
     * than merely short-circuiting inside the worker.
     */
    fun setNotificationSettings(settings: NotificationSettings) = viewModelScope.launch {
        notificationSettingsRepository.update(settings)
        reminderScheduler.sync(settings)
    }

    fun signOut() = viewModelScope.launch {
        // Reminders are per-account, so stop them before dropping the session.
        reminderScheduler.cancelAll()
        authRepository.logout()
        _uiState.update { it.copy(signedOut = true) }
    }

    /** Pushes the current local settings up to `teachers/{id}.settings`. */
    private suspend fun mirrorSettings() {
        val snapshot: TeacherSettings = appPreferences.settingsSnapshot.first()
        teacherRepository.updateSettings(snapshot)
    }
}
