package com.teacherhomework.manager.presentation.checking

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.People
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.GradeType
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.EmptyStatePlaceholder
import com.teacherhomework.manager.presentation.components.InitialsAvatar
import com.teacherhomework.manager.presentation.components.OverflowAction
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.util.toStringRes

/**
 * Fast Checking Mode — grade a whole class in one pass.
 *
 * There is deliberately NO Save button: every tap writes immediately (locally
 * first, so it is instant and works offline). A progress bar at the top shows
 * how much of the class is done, which is the feedback that replaces a Save
 * confirmation.
 *
 * In fast mode each row shows only the big 3-way status toggle. Turning fast
 * mode off reveals the grade and comment inputs per row — progressive
 * disclosure, so the common case stays one tap per student.
 */
@Composable
fun CheckingScreen(
    onNavigateBack: () -> Unit,
    viewModel: CheckingViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val rows by viewModel.rows.collectAsStateWithLifecycle()
    val homework by viewModel.homework.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHostState.showSnackbar(context.getString(it.toStringRes()))
            viewModel.consumeError()
        }
    }

    val checkedCount = rows.count { it.isChecked }
    val progress = if (rows.isEmpty()) 0f else checkedCount.toFloat() / rows.size

    Scaffold(
        topBar = {
            AppTopBar(
                title = homework?.title ?: stringResource(R.string.title_checking),
                onNavigateBack = onNavigateBack,
                overflowActions = listOf(
                    OverflowAction(
                        label = stringResource(
                            if (state.fastMode) R.string.action_detailed_mode
                            else R.string.action_fast_mode
                        ),
                        onClick = { viewModel.setFastMode(!state.fastMode) },
                    ),
                    OverflowAction(
                        label = stringResource(R.string.action_mark_rest_completed),
                        onClick = { viewModel.markAllUnchecked(CompletionStatus.COMPLETED) },
                    ),
                    OverflowAction(
                        label = stringResource(R.string.action_mark_rest_missing),
                        onClick = { viewModel.markAllUnchecked(CompletionStatus.MISSING) },
                    ),
                ),
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    text = stringResource(R.string.checking_progress, checkedCount, rows.size),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GradeType.entries.forEach { type ->
                        FilterChip(
                            selected = state.gradeType == type,
                            onClick = { viewModel.setGradeType(type) },
                            label = { Text(stringResource(type.labelRes())) },
                            shape = AppCorner.Chip,
                        )
                    }
                }
            }

            if (rows.isEmpty()) {
                EmptyStatePlaceholder(
                    icon = Icons.Outlined.People,
                    title = stringResource(R.string.empty_class_students_title),
                    message = stringResource(
                        R.string.empty_class_students_message,
                        homework?.className.orEmpty(),
                    ),
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp, 4.dp, 12.dp, 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(rows, key = { it.student.id }) { row ->
                        CheckingRowCard(
                            row = row,
                            fastMode = state.fastMode,
                            isSaving = row.student.id in state.savingStudentIds,
                            onStatusSelect = { viewModel.setStatus(row.student.id, it) },
                            onGradeChange = { viewModel.setGrade(row.student.id, it) },
                            onCommentChange = { viewModel.setComment(row.student.id, it) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CheckingRowCard(
    row: CheckingRow,
    fastMode: Boolean,
    isSaving: Boolean,
    onStatusSelect: (CompletionStatus) -> Unit,
    onGradeChange: (String) -> Unit,
    onCommentChange: (String) -> Unit,
) {
    Card(
        shape = AppCorner.Card,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                InitialsAvatar(name = row.student.fullName, size = 40.dp)
                Spacer(Modifier.width(10.dp))
                Text(
                    text = row.student.fullName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            StatusToggle(
                selected = row.status,
                onSelect = onStatusSelect,
            )

            if (!fastMode) {
                Spacer(Modifier.height(10.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedTextField(
                        value = row.grade?.let { g ->
                            if (g % 1.0 == 0.0) g.toInt().toString() else g.toString()
                        }.orEmpty(),
                        onValueChange = onGradeChange,
                        label = { Text(stringResource(R.string.field_grade)) },
                        singleLine = true,
                        shape = AppCorner.Button,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.width(120.dp),
                    )
                    OutlinedTextField(
                        value = row.result?.comment.orEmpty(),
                        onValueChange = onCommentChange,
                        label = { Text(stringResource(R.string.field_comment)) },
                        singleLine = true,
                        shape = AppCorner.Button,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@androidx.annotation.StringRes
private fun GradeType.labelRes(): Int = when (this) {
    GradeType.PERCENT -> R.string.grade_type_percent
    GradeType.POINT_10 -> R.string.grade_type_point10
}
