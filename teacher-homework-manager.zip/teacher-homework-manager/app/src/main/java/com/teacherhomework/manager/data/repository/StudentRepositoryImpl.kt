package com.teacherhomework.manager.data.repository

import com.teacherhomework.manager.data.local.dao.ResultDao
import com.teacherhomework.manager.data.local.dao.StudentDao
import com.teacherhomework.manager.data.mapper.toDomain
import com.teacherhomework.manager.data.mapper.toEntity
import com.teacherhomework.manager.data.remote.ResultRemoteDataSource
import com.teacherhomework.manager.data.remote.StudentRemoteDataSource
import com.teacherhomework.manager.domain.model.Student
import com.teacherhomework.manager.domain.model.SyncState
import com.teacherhomework.manager.domain.repository.StatisticsRepository
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton

/**
 * Offline-first student repository.
 *
 * READ PATH: the UI always observes Room. Firestore is only touched by
 * [refresh], so scrolling, rotating, or re-entering a screen costs zero reads
 * (COST AWARENESS — the dominant read saving at 120 students).
 *
 * WRITE PATH: write to Room immediately marked PENDING, then push to Firestore
 * and mark SYNCED. If the push throws (offline), the row stays PENDING and
 * SyncRepository retries later — the teacher's edit is never lost and the UI
 * updates instantly either way.
 *
 * [StatisticsRepository] is injected as a [Provider] to break the dependency
 * cycle (statistics reads students; students trigger a recalc after delete).
 */
@Singleton
class StudentRepositoryImpl @Inject constructor(
    private val studentDao: StudentDao,
    private val resultDao: ResultDao,
    private val remote: StudentRemoteDataSource,
    private val resultRemote: ResultRemoteDataSource,
    private val session: SessionProvider,
    private val statistics: Provider<StatisticsRepository>,
) : StudentRepository {

    override fun observeStudents(
        search: String,
        className: String?,
        activeOnly: Boolean,
    ): Flow<List<Student>> =
        studentDao.observe(search, className, activeOnly, PAGE_LIMIT)
            .map { list -> list.map { it.toDomain() } }

    override fun observeStudent(studentId: String): Flow<Student?> =
        studentDao.observeById(studentId).map { it?.toDomain() }

    override fun observeClassNames(): Flow<List<String>> = studentDao.observeClassNames()

    override suspend fun getStudent(studentId: String): Student? =
        studentDao.getById(studentId)?.toDomain()

    override suspend fun upsertStudent(student: Student): AppResult<Unit> {
        // Local first — the list updates before the network call even starts.
        studentDao.upsert(student.copy(syncState = SyncState.PENDING).toEntity())
        return runCatchingRepo {
            remote.upsert(session.requireTeacherId(), student)
            studentDao.upsert(student.copy(syncState = SyncState.SYNCED).toEntity())
        }
    }

    /**
     * Soft delete keeps every recorded result and the student's contribution to
     * historical statistics intact — the roster just stops showing them.
     */
    override suspend fun softDeleteStudent(studentId: String): AppResult<Unit> {
        studentDao.softDelete(studentId, SyncState.PENDING.name)
        return runCatchingRepo {
            remote.setActive(session.requireTeacherId(), studentId, isActive = false)
            studentDao.getById(studentId)?.let {
                studentDao.upsert(it.copy(syncState = SyncState.SYNCED.name))
            }
            statistics.get().recalculateAndCommit()
            Unit
        }
    }

    /**
     * Hard delete removes the student AND cascades to their results, then
     * recalculates statistics so averages/completion rate no longer count the
     * removed work. Irreversible — the UI confirms before calling this.
     */
    override suspend fun hardDeleteStudent(studentId: String): AppResult<Unit> {
        resultDao.deleteForStudent(studentId)
        studentDao.hardDelete(studentId)
        return runCatchingRepo {
            val teacherId = session.requireTeacherId()
            resultRemote.deleteForStudent(teacherId, studentId)
            remote.delete(teacherId, studentId)
            statistics.get().recalculateAndCommit()
            Unit
        }
    }

    override suspend fun refresh(): AppResult<Unit> = runCatchingRepo {
        val students = remote.fetchAll(session.requireTeacherId())
        studentDao.upsertAll(students.map { it.toEntity() })
    }

    private companion object {
        /**
         * Page cap for the roster query. 500 comfortably covers this project's
         * ~120-student target with margin, while still bounding memory and the
         * initial Firestore pull.
         */
        const val PAGE_LIMIT = 500
    }
}
