package com.teacherhomework.manager.data.repository

import com.teacherhomework.manager.data.local.dao.HomeworkDao
import com.teacherhomework.manager.data.local.dao.ResultDao
import com.teacherhomework.manager.data.mapper.toDomain
import com.teacherhomework.manager.data.mapper.toEntity
import com.teacherhomework.manager.data.remote.HomeworkRemoteDataSource
import com.teacherhomework.manager.data.remote.ResultRemoteDataSource
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.domain.model.SyncState
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.domain.repository.StatisticsRepository
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton

/**
 * Offline-first homework repository. Same Room-first read/write strategy as
 * [StudentRepositoryImpl].
 *
 * EDITING POLICY: every field (title, subject, description, dates, attachment)
 * stays editable at any status and at any age, even once results exist — there
 * is no field-level lock. Changing the deadline deliberately does NOT rewrite
 * any already-recorded result's completionStatus; the UI states this in words
 * before saving.
 */
@Singleton
class HomeworkRepositoryImpl @Inject constructor(
    private val homeworkDao: HomeworkDao,
    private val resultDao: ResultDao,
    private val remote: HomeworkRemoteDataSource,
    private val resultRemote: ResultRemoteDataSource,
    private val session: SessionProvider,
    private val statistics: Provider<StatisticsRepository>,
) : HomeworkRepository {

    override fun observeHomework(
        status: HomeworkStatus?,
        subject: String?,
        search: String,
    ): Flow<List<Homework>> =
        homeworkDao.observe(status?.token, subject, search)
            .map { list -> list.map { it.toDomain() } }

    override fun observeHomeworkById(homeworkId: String): Flow<Homework?> =
        homeworkDao.observeById(homeworkId).map { it?.toDomain() }

    override suspend fun getHomework(homeworkId: String): Homework? =
        homeworkDao.getById(homeworkId)?.toDomain()

    override suspend fun upsertHomework(homework: Homework): AppResult<Unit> {
        val stamped = homework.copy(updatedAt = System.currentTimeMillis())
        homeworkDao.upsert(stamped.copy(syncState = SyncState.PENDING).toEntity())
        return runCatchingRepo {
            remote.upsert(session.requireTeacherId(), stamped)
            homeworkDao.upsert(stamped.copy(syncState = SyncState.SYNCED).toEntity())
        }
    }

    /**
     * Permanently deletes the homework and CASCADES to every result recorded
     * against it, then recalculates statistics so the removed grades stop
     * affecting averages and completion rate.
     *
     * POLICY OVERRIDE (teacher decision): deletion is never blocked by the
     * presence of results. When results exist the UI must first show the
     * warning dialog driven by CheckHomeworkDeletionUseCase — but once the
     * teacher confirms, the delete goes through in full. Archive remains
     * available as the non-destructive option.
     */
    override suspend fun deleteHomework(homeworkId: String): AppResult<Unit> {
        // Local cascade first so the UI reflects the deletion immediately.
        resultDao.deleteForHomework(homeworkId)
        homeworkDao.delete(homeworkId)
        return runCatchingRepo {
            val teacherId = session.requireTeacherId()
            resultRemote.deleteForHomework(teacherId, homeworkId)
            remote.delete(teacherId, homeworkId)
            statistics.get().recalculateAndCommit()
            Unit
        }
    }

    /** Non-destructive alternative to delete — hides it from active lists. */
    override suspend fun archiveHomework(homeworkId: String): AppResult<Unit> {
        val current = homeworkDao.getById(homeworkId)?.toDomain()
            ?: return AppResult.Error(AppError.UNKNOWN)
        return upsertHomework(current.copy(status = HomeworkStatus.ARCHIVED))
    }

    override suspend fun refresh(): AppResult<Unit> = runCatchingRepo {
        val homework = remote.fetchAll(session.requireTeacherId())
        homeworkDao.upsertAll(homework.map { it.toEntity() })
    }
}
