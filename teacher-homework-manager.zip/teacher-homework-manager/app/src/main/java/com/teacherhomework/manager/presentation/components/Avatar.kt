package com.teacherhomework.manager.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.teacherhomework.manager.presentation.theme.AppCorner

/**
 * Rounded-square initials avatar — UI STYLE DIRECTION: list-row avatars are
 * rounded-square (not circular), with a soft tinted background in the theme's
 * accent family and a darker-shade initial on top.
 *
 * Falls back to "?" when a name is blank so the row never renders an empty box.
 */
@Composable
fun InitialsAvatar(
    name: String,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    contentColor: Color = MaterialTheme.colorScheme.onPrimaryContainer,
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(AppCorner.Avatar)
            .background(containerColor),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = name.toInitials(),
            color = contentColor,
            fontWeight = FontWeight.Bold,
            // Scaled from the box size so the initials stay optically centered
            // whether the avatar is a 40dp list row or a 96dp profile header.
            fontSize = (size.value * 0.36f).sp,
            style = MaterialTheme.typography.titleMedium,
        )
    }
}

/**
 * First letters of the first two words, uppercased. Handles Cyrillic and Latin
 * alike since it operates on characters, not ASCII ranges.
 */
private fun String.toInitials(): String {
    val parts = trim().split(" ", "\t").filter { it.isNotBlank() }
    return when {
        parts.isEmpty() -> "?"
        parts.size == 1 -> parts[0].take(1).uppercase()
        else -> (parts[0].take(1) + parts[1].take(1)).uppercase()
    }
}
