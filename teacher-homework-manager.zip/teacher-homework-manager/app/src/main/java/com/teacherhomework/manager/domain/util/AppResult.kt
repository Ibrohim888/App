package com.teacherhomework.manager.domain.util

/**
 * Lightweight result wrapper for repository/use-case operations. [Error] carries
 * a UI-agnostic [AppError] kind (mapped to a localized string in the
 * presentation layer) rather than a raw exception message, so error copy stays
 * localizable and consistent (LOCALIZATION POLICY).
 */
sealed interface AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>
    data class Error(val error: AppError, val cause: Throwable? = null) : AppResult<Nothing>
}

inline fun <T> AppResult<T>.onSuccess(block: (T) -> Unit): AppResult<T> {
    if (this is AppResult.Success) block(data)
    return this
}

inline fun <T> AppResult<T>.onError(block: (AppError) -> Unit): AppResult<T> {
    if (this is AppResult.Error) block(error)
    return this
}

/**
 * UI-agnostic error kinds. The presentation layer maps each to a localized
 * string resource; no user-facing English lives here.
 */
enum class AppError {
    NETWORK,
    INVALID_EMAIL,
    WEAK_PASSWORD,
    WRONG_CREDENTIALS,
    EMAIL_ALREADY_IN_USE,
    USER_NOT_FOUND,
    PASSWORDS_DO_NOT_MATCH,
    EMPTY_FIELD,
    GRADE_OUT_OF_RANGE,
    /** Deadline earlier than the assigned date — always a data-entry mistake. */
    DEADLINE_BEFORE_ASSIGNED,
    /**
     * Retained for the domain vocabulary, but no longer used to BLOCK anything:
     * per the teacher's policy override, a graded homework can be deleted after
     * an explicit confirmation. See CheckHomeworkDeletionUseCase.
     */
    HOMEWORK_HAS_RESULTS,
    FILE_TOO_LARGE,
    UNSUPPORTED_FILE_TYPE,
    PERMISSION_DENIED,
    UNKNOWN,
}
