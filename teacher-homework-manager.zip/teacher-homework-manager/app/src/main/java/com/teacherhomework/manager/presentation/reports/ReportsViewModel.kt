package com.teacherhomework.manager.presentation.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.data.report.ReportFormat
import com.teacherhomework.manager.data.report.ReportGenerator
import com.teacherhomework.manager.data.report.ReportType
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.domain.util.AppError
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

data class ReportsUiState(
    val type: ReportType = ReportType.CLASS_SUMMARY,
    val format: ReportFormat = ReportFormat.PDF,
    val selectedClass: String? = null,
    val isGenerating: Boolean = false,
    /** The file just produced, so the UI can offer Open/Share. */
    val generatedFile: File? = null,
    val existingFiles: List<File> = emptyList(),
    val error: AppError? = null,
)

/**
 * Report export screen.
 *
 * Generation runs on [Dispatchers.IO] — building a PDF for 120 students is
 * hundreds of Canvas draw calls plus a file write, which would drop frames if it
 * ran on the main thread.
 */
@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val reportGenerator: ReportGenerator,
    private val studentRepository: StudentRepository,
    private val homeworkRepository: HomeworkRepository,
    private val resultRepository: ResultRepository,
    private val appPreferences: AppPreferences,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReportsUiState())
    val uiState: StateFlow<ReportsUiState> = _uiState.asStateFlow()

    val classNames: StateFlow<List<String>> = studentRepository.observeClassNames()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        refreshFileList()
    }

    fun setType(type: ReportType) = _uiState.update { it.copy(type = type) }
    fun setFormat(format: ReportFormat) = _uiState.update { it.copy(format = format) }
    fun setClass(className: String?) = _uiState.update { it.copy(selectedClass = className) }
    fun consumeGeneratedFile() = _uiState.update { it.copy(generatedFile = null) }
    fun consumeError() = _uiState.update { it.copy(error = null) }

    private fun refreshFileList() = _uiState.update {
        it.copy(existingFiles = reportGenerator.listReports())
    }

    /**
     * @param accentColor the active theme's primary color, so the exported PDF
     *   matches the app the teacher is looking at.
     */
    fun generate(accentColor: Int) {
        _uiState.update { it.copy(isGenerating = true) }
        viewModelScope.launch {
            val state = _uiState.value
            val language = appPreferences.settingsSnapshot.first().language

            // Read once from the cache, then filter in memory — no extra queries.
            val allStudents = studentRepository.observeStudents(activeOnly = true).first()
            val allHomework = homeworkRepository.observeHomework().first()
            val allResults = resultRepository.allResults()

            val students = state.selectedClass
                ?.let { cls -> allStudents.filter { it.className == cls } }
                ?: allStudents
            val homework = state.selectedClass
                ?.let { cls -> allHomework.filter { it.className == cls } }
                ?: allHomework
            val studentIds = students.map { it.id }.toSet()
            val homeworkIds = homework.map { it.id }.toSet()
            val results = allResults.filter {
                it.studentId in studentIds && it.homeworkId in homeworkIds
            }

            val result = runCatching {
                withContext(Dispatchers.IO) {
                    reportGenerator.generate(
                        type = state.type,
                        format = state.format,
                        data = ReportGenerator.ReportData(
                            students = students,
                            homework = homework,
                            results = results,
                            className = state.selectedClass,
                        ),
                        languageTag = language,
                        accentColor = accentColor,
                    )
                }
            }

            _uiState.update {
                it.copy(
                    isGenerating = false,
                    generatedFile = result.getOrNull(),
                    error = if (result.isFailure) AppError.UNKNOWN else null,
                    existingFiles = reportGenerator.listReports(),
                )
            }
        }
    }
}
