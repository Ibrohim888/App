package com.teacherhomework.manager.presentation.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.GradientHeader
import com.teacherhomework.manager.presentation.components.OverflowAction
import com.teacherhomework.manager.presentation.components.StatTile
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.theme.LocalStatusColors
import com.teacherhomework.manager.presentation.util.DateFormat

/**
 * Dashboard — gradient header with stat cards overlapping into it (UI STYLE
 * DIRECTION), followed by the live "needs attention" list.
 *
 * The attention list is the app's safety net: because local reminders are
 * best-effort, this always-correct in-app view is what guarantees the teacher
 * can see overdue and unchecked work without depending on a notification firing.
 */
@Composable
fun DashboardScreen(
    onOpenHomework: (String) -> Unit,
    onStartChecking: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenNotifications: () -> Unit,
    viewModel: DashboardViewModel = hiltViewModel(),
) {
    val summary by viewModel.summary.collectAsStateWithLifecycle()
    val studentCount by viewModel.activeStudentCount.collectAsStateWithLifecycle()
    val attention by viewModel.attentionItems.collectAsStateWithLifecycle()
    val dueToday by viewModel.dueToday.collectAsStateWithLifecycle()
    val locale = LocalConfiguration.current.locales[0]

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.nav_dashboard),
                overflowActions = listOf(
                    OverflowAction(
                        label = stringResource(R.string.action_refresh),
                        onClick = { viewModel.refresh() },
                    ),
                    OverflowAction(
                        label = stringResource(R.string.nav_notifications),
                        onClick = onOpenNotifications,
                    ),
                    OverflowAction(
                        label = stringResource(R.string.nav_settings),
                        onClick = onOpenSettings,
                    ),
                ),
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            item {
                GradientHeader {
                    Text(
                        text = stringResource(R.string.dashboard_greeting),
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = DateFormat.date(System.currentTimeMillis(), locale),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                    // Bottom space that the overlapping stat row sits over.
                    Spacer(Modifier.height(36.dp))
                }
            }

            item {
                // Negative offset pulls the stat row up into the header — the
                // signature overlap from the style direction.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .offset(y = (-30).dp)
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    StatTile(
                        label = stringResource(R.string.stat_students),
                        value = studentCount.toString(),
                        modifier = Modifier.weight(1f),
                    )
                    StatTile(
                        label = stringResource(R.string.stat_completion),
                        value = "${summary.completionRate.toInt()}%",
                        modifier = Modifier.weight(1f),
                    )
                    StatTile(
                        label = stringResource(R.string.stat_average),
                        value = if (summary.averageGrade == 0.0) "—"
                        else String.format(locale, "%.1f", summary.averageGrade),
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            if (dueToday.isNotEmpty()) {
                item { SectionHeader(stringResource(R.string.section_due_today)) }
                items(dueToday, key = { "today_${it.id}" }) { hw ->
                    Card(
                        onClick = { onOpenHomework(hw.id) },
                        shape = AppCorner.Card,
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Schedule,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp),
                            )
                            Spacer(Modifier.size(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    text = hw.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    text = "${hw.subject} · ${hw.className}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }

            item { SectionHeader(stringResource(R.string.section_needs_attention)) }

            if (attention.isEmpty()) {
                item {
                    Card(
                        shape = AppCorner.Card,
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = LocalStatusColors.current.completedText,
                            )
                            Spacer(Modifier.size(10.dp))
                            Text(
                                text = stringResource(R.string.dashboard_all_caught_up),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                }
            } else {
                items(attention, key = { "att_${it.homework.id}" }) { item ->
                    AttentionCard(item = item, onClick = { onStartChecking(item.homework.id) })
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 6.dp),
    )
}

@Composable
private fun AttentionCard(item: AttentionItem, onClick: () -> Unit) {
    val statusColors = LocalStatusColors.current
    val context = LocalContext.current

    // Icon + tint encode urgency; the text below states it in words too, so the
    // meaning never depends on color alone.
    val icon: ImageVector
    val tint: androidx.compose.ui.graphics.Color
    when (item.kind) {
        AttentionItem.Kind.OVERDUE -> {
            icon = Icons.Filled.Warning
            tint = statusColors.missingText
        }
        AttentionItem.Kind.UNCHECKED -> {
            icon = Icons.Filled.ErrorOutline
            tint = statusColors.missingText
        }
        AttentionItem.Kind.DUE_SOON -> {
            icon = Icons.Filled.Schedule
            tint = statusColors.partialText
        }
    }

    val reason = when (item.kind) {
        AttentionItem.Kind.OVERDUE ->
            stringResource(R.string.attention_overdue, item.ungradedCount)
        AttentionItem.Kind.UNCHECKED -> stringResource(R.string.attention_unchecked)
        AttentionItem.Kind.DUE_SOON ->
            DateFormat.relativeDeadline(context, item.homework.deadline)
    }

    Card(
        onClick = onClick,
        shape = AppCorner.Card,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = tint)
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = item.homework.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = reason,
                    style = MaterialTheme.typography.bodySmall,
                    color = tint,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
    }
}
