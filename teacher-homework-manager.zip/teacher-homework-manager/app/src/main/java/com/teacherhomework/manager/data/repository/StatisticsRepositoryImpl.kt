package com.teacherhomework.manager.data.repository

import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import com.teacherhomework.manager.data.local.dao.StatisticsDao
import com.teacherhomework.manager.data.local.dao.StudentDao
import com.teacherhomework.manager.data.local.entity.StatisticsEntity
import com.teacherhomework.manager.data.mapper.asEpochMillis
import com.teacherhomework.manager.data.mapper.resultFromFirestore
import com.teacherhomework.manager.data.remote.FirestorePaths
import com.teacherhomework.manager.domain.model.StatisticsSummary
import com.teacherhomework.manager.domain.repository.StatisticsRepository
import com.teacherhomework.manager.domain.usecase.StatisticsCalculator
import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

/**
 * On-device statistics — the free-tier replacement for a Cloud Function.
 *
 * MULTI-DEVICE WRITE SAFETY. Every commit follows the mandated shape:
 *  1. Query the authoritative `results` collection fresh (never an in-memory
 *     running total, never an incremental delta).
 *  2. Derive the whole summary from that snapshot, so the computation is
 *     IDEMPOTENT — running it twice yields the same document.
 *  3. Commit inside `runTransaction`, which reads the current document first and
 *     re-runs the whole block if another device wrote in between.
 *
 * Because step 2 never depends on the previous value, two devices racing produce
 * the same end state regardless of write order — the later transaction simply
 * rewrites the same derived numbers. A plain `set()`/`update()` would not be
 * safe here and is deliberately not used.
 *
 * COST AWARENESS: this reads the results collection once per commit. At ~120
 * students that is a few hundred documents on a heavy grading day — far inside
 * Spark's 50K/day read quota. Fast Checking Mode callers should debounce
 * (see CheckingViewModel) so a 30-student sweep triggers one recalc, not 30.
 */
@Singleton
class StatisticsRepositoryImpl @Inject constructor(
    private val db: FirebaseFirestore,
    private val statisticsDao: StatisticsDao,
    private val studentDao: StudentDao,
    private val session: SessionProvider,
) : StatisticsRepository {

    /** UI observes the cached copy so opening Dashboard costs zero reads. */
    override fun observeSummary(): Flow<StatisticsSummary> =
        statisticsDao.observe().map { it?.toSummary() ?: StatisticsSummary() }

    override suspend fun recalculateAndCommit(): AppResult<Unit> = runCatchingRepo {
        val teacherId = session.requireTeacherId()

        // (1) Authoritative read of every result. Source.DEFAULT lets Firestore
        // serve from its offline cache when there's no connection, so an offline
        // recalc still produces a locally-correct summary that syncs later.
        val snapshot = FirestorePaths.results(db, teacherId).get(Source.DEFAULT).await()
        val results = snapshot.documents.mapNotNull { doc ->
            doc.data?.let { resultFromFirestore(doc.id, it) }
        }

        val totalStudents = studentDao.activeCount()
        // (2) Derive everything fresh from the snapshot via the pure calculator.
        val summary = StatisticsCalculator.compute(
            results = results,
            activeStudentCount = totalStudents,
            nowMillis = System.currentTimeMillis(),
        )

        // (3) Transactional commit — re-reads the doc and retries on conflict.
        db.runTransaction { txn ->
            val ref = FirestorePaths.statisticsSummary(db, teacherId)
            val existing = txn.get(ref)
            val existingAt = existing.get("lastRecalculatedAt").asEpochMillis()

            // Guard against an out-of-order retry overwriting a newer commit with
            // an older snapshot: only skip if the stored doc is strictly newer
            // than the moment this computation's snapshot was taken.
            if (existingAt > summary.lastRecalculatedAt) return@runTransaction null

            txn.set(ref, summary.toFirestoreMap())
            null
        }.await()

        statisticsDao.upsert(summary.toEntity())
    }

    private fun StatisticsSummary.toFirestoreMap(): Map<String, Any?> = mapOf(
        "totalStudents" to totalStudents,
        "averageGrade" to averageGrade,
        "completionRate" to completionRate,
        "missingHomeworkCount" to missingHomeworkCount,
        "monthlyProgress" to monthlyProgress,
        "weeklyProgress" to weeklyProgress,
        "lastRecalculatedAt" to Timestamp(java.util.Date(lastRecalculatedAt)),
    )

    private fun StatisticsSummary.toEntity() = StatisticsEntity(
        id = StatisticsEntity.SINGLETON_ID,
        totalStudents = totalStudents,
        averageGrade = averageGrade,
        completionRate = completionRate,
        missingHomeworkCount = missingHomeworkCount,
        monthlyProgressJson = monthlyProgress.encode(),
        weeklyProgressJson = weeklyProgress.encode(),
        lastRecalculatedAt = lastRecalculatedAt,
    )

    private fun StatisticsEntity.toSummary() = StatisticsSummary(
        totalStudents = totalStudents,
        averageGrade = averageGrade,
        completionRate = completionRate,
        missingHomeworkCount = missingHomeworkCount,
        monthlyProgress = monthlyProgressJson.decode(),
        weeklyProgress = weeklyProgressJson.decode(),
        lastRecalculatedAt = lastRecalculatedAt,
    )
}

/*
 * Progress maps are stored in Room as a compact "key=value;key=value" string
 * rather than pulling in a JSON dependency for two fields. Keys are generated
 * (yyyy-MM / yyyy-Www) so they can never contain the separators.
 */
internal fun Map<String, Double>.encode(): String =
    entries.joinToString(";") { "${it.key}=${it.value}" }

internal fun String.decode(): Map<String, Double> =
    if (isBlank()) emptyMap() else split(";").mapNotNull { pair ->
        val parts = pair.split("=")
        if (parts.size == 2) parts[0] to (parts[1].toDoubleOrNull() ?: return@mapNotNull null) else null
    }.toMap()
