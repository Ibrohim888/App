package com.teacherhomework.manager.presentation.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.data.local.dao.NotificationDao
import com.teacherhomework.manager.data.local.entity.NotificationEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * One history entry, decoded from its stored structured form.
 *
 * The stored row holds a TYPE plus a parameter map — never a pre-rendered
 * sentence — so switching the app language re-renders past notifications in the
 * new language instead of leaving a mix of languages in the list.
 */
data class NotificationItem(
    val id: String,
    val type: String,
    val params: Map<String, String>,
    val postedAt: Long,
    val read: Boolean,
    val deepLink: String?,
)

@HiltViewModel
class NotificationCenterViewModel @Inject constructor(
    private val notificationDao: NotificationDao,
) : ViewModel() {

    val notifications: StateFlow<List<NotificationItem>> =
        notificationDao.observeRecent(HISTORY_LIMIT)
            .map { list -> list.map { it.toItem() } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val unreadCount: StateFlow<Int> = notificationDao.observeUnreadCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    fun markRead(id: String) = viewModelScope.launch { notificationDao.markRead(id) }

    private fun NotificationEntity.toItem() = NotificationItem(
        id = id,
        type = type,
        params = paramsJson.decodeParams(),
        postedAt = postedAt,
        read = read,
        deepLink = deepLink,
    )

    private companion object {
        const val HISTORY_LIMIT = 50
    }
}

/**
 * Parses the small flat `{"key":"value",...}` blobs the workers write.
 *
 * Hand-rolled rather than pulling in a JSON library: these blobs are produced by
 * this app only, are always flat string→string, and a malformed one must yield
 * an empty map rather than crash the history screen.
 */
internal fun String.decodeParams(): Map<String, String> = runCatching {
    trim()
        .removePrefix("{")
        .removeSuffix("}")
        .split("\",\"")
        .mapNotNull { pair ->
            val idx = pair.indexOf("\":\"")
            if (idx <= 0) return@mapNotNull null
            val key = pair.substring(0, idx).removePrefix("\"")
            val value = pair.substring(idx + 3).removeSuffix("\"")
            key to value.replace("\\\"", "\"").replace("\\\\", "\\")
        }
        .toMap()
}.getOrDefault(emptyMap())
