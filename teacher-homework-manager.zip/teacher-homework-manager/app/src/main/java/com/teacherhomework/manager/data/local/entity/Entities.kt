package com.teacherhomework.manager.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Room entities mirroring the Firestore collections (offline-first cache and the
 * UI's source of truth). Enums are stored as their String tokens and timestamps
 * as epoch-millis Longs, matching the domain model, so mapping is 1:1.
 *
 * [syncState] tracks whether a locally-written row has been pushed to Firestore
 * yet (SYNCED / PENDING / FAILED) — used by the sync manager (Phase 7) and the
 * per-record sync indicator.
 */
@Entity(tableName = "students", indices = [Index("className"), Index("isActive")])
data class StudentEntity(
    @PrimaryKey val id: String,
    val firstName: String,
    val lastName: String,
    val fullName: String,
    val className: String?,
    val phone: String?,
    val notes: String?,
    val photo: String?,
    val createdAt: Long,
    val isActive: Boolean,
    val syncState: String,
)

@Entity(tableName = "homework", indices = [Index("status"), Index("className"), Index("deadline")])
data class HomeworkEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subject: String,
    val description: String,
    val className: String,
    val attachmentURL: String?,
    val assignedDate: Long,
    val deadline: Long,
    val status: String,
    val createdAt: Long,
    val updatedAt: Long,
    val syncState: String,
)

@Entity(
    tableName = "results",
    indices = [Index("homeworkId"), Index("studentId"), Index(value = ["homeworkId", "studentId"], unique = true)],
)
data class ResultEntity(
    @PrimaryKey val id: String,
    val studentId: String,
    val homeworkId: String,
    val completionStatus: String,
    val grade: Double?,
    val gradeType: String,
    val comment: String?,
    val checkedDate: Long,
    val checkedBy: String,
    val syncState: String,
)

/**
 * Cached copy of `statistics/summary`, so the Dashboard renders instantly and
 * offline without a Firestore read. Exactly one row ever exists — keyed by
 * [SINGLETON_ID] — because the remote document is itself a singleton.
 *
 * The two progress maps are stored as compact "key=value;..." strings rather
 * than adding a JSON dependency for two fields; see the encode/decode helpers in
 * StatisticsRepositoryImpl.
 */
@Entity(tableName = "statistics")
data class StatisticsEntity(
    @PrimaryKey val id: String,
    val totalStudents: Int,
    val averageGrade: Double,
    val completionRate: Double,
    val missingHomeworkCount: Int,
    val monthlyProgressJson: String,
    val weeklyProgressJson: String,
    val lastRecalculatedAt: Long,
) {
    companion object {
        const val SINGLETON_ID = "summary"
    }
}

/**
 * Locally-stored notification history (In-App Notification Center, Phase 6).
 * Stores STRUCTURED data (type + params), not a pre-rendered string, so entries
 * re-render in the correct language if the teacher changes app language after a
 * notification was posted (LOCALIZATION POLICY / Phase 6 DoD).
 */
@Entity(tableName = "notifications", indices = [Index("postedAt")])
data class NotificationEntity(
    @PrimaryKey val id: String,
    val type: String,
    /** JSON-encoded parameter map (e.g. {"subject":"Math","count":"3"}). */
    val paramsJson: String,
    val postedAt: Long,
    val read: Boolean,
    /** Optional deep-link target, e.g. "homework/{id}" or "student/{id}". */
    val deepLink: String?,
)
