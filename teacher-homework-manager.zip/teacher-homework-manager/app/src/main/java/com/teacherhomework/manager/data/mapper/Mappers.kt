package com.teacherhomework.manager.data.mapper

import com.google.firebase.Timestamp
import com.teacherhomework.manager.data.local.entity.HomeworkEntity
import com.teacherhomework.manager.data.local.entity.ResultEntity
import com.teacherhomework.manager.data.local.entity.StudentEntity
import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.GradeType
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.domain.model.Result
import com.teacherhomework.manager.domain.model.Student
import com.teacherhomework.manager.domain.model.SyncState

/*
 * Mapping between the three representations of each record:
 *   Firestore Map<String, Any?>  <->  domain model  <->  Room entity
 *
 * Field names in the Firestore maps are the CONTRACT from CLAUDE.md and must not
 * be renamed — note `completionStatus` (not `status`) on results, which is
 * deliberately different from homework's `status` to keep the two enums from
 * being confused.
 *
 * Firestore stores dates as Timestamp; the domain uses epoch millis. These
 * helpers convert both ways and tolerate a missing/!Timestamp value by falling
 * back to 0L rather than throwing, so one malformed remote document can't crash
 * a whole list sync.
 */

fun Any?.asEpochMillis(): Long = when (this) {
    is Timestamp -> toDate().time
    is Number -> toLong()
    else -> 0L
}

fun Long.asTimestamp(): Timestamp = Timestamp(java.util.Date(this))

// ---------- Student ----------

fun StudentEntity.toDomain() = Student(
    id = id,
    firstName = firstName,
    lastName = lastName,
    fullName = fullName,
    className = className,
    phone = phone,
    notes = notes,
    photo = photo,
    createdAt = createdAt,
    isActive = isActive,
    syncState = runCatching { SyncState.valueOf(syncState) }.getOrDefault(SyncState.SYNCED),
)

fun Student.toEntity() = StudentEntity(
    id = id,
    firstName = firstName,
    lastName = lastName,
    fullName = fullName,
    className = className,
    phone = phone,
    notes = notes,
    photo = photo,
    createdAt = createdAt,
    isActive = isActive,
    syncState = syncState.name,
)

fun Student.toFirestoreMap(): Map<String, Any?> = mapOf(
    "firstName" to firstName,
    "lastName" to lastName,
    "fullName" to fullName,
    "className" to className,
    "phone" to phone,
    "notes" to notes,
    "photo" to photo,
    "createdAt" to createdAt.asTimestamp(),
    "isActive" to isActive,
)

fun studentFromFirestore(id: String, data: Map<String, Any?>) = Student(
    id = id,
    firstName = data["firstName"] as? String ?: "",
    lastName = data["lastName"] as? String ?: "",
    fullName = data["fullName"] as? String ?: "",
    className = data["className"] as? String,
    phone = data["phone"] as? String,
    notes = data["notes"] as? String,
    photo = data["photo"] as? String,
    createdAt = data["createdAt"].asEpochMillis(),
    isActive = data["isActive"] as? Boolean ?: true,
    syncState = SyncState.SYNCED,
)

// ---------- Homework ----------

fun HomeworkEntity.toDomain() = Homework(
    id = id,
    title = title,
    subject = subject,
    description = description,
    className = className,
    attachmentURL = attachmentURL,
    assignedDate = assignedDate,
    deadline = deadline,
    status = HomeworkStatus.fromToken(status),
    createdAt = createdAt,
    updatedAt = updatedAt,
    syncState = runCatching { SyncState.valueOf(syncState) }.getOrDefault(SyncState.SYNCED),
)

fun Homework.toEntity() = HomeworkEntity(
    id = id,
    title = title,
    subject = subject,
    description = description,
    className = className,
    attachmentURL = attachmentURL,
    assignedDate = assignedDate,
    deadline = deadline,
    status = status.token,
    createdAt = createdAt,
    updatedAt = updatedAt,
    syncState = syncState.name,
)

fun Homework.toFirestoreMap(): Map<String, Any?> = mapOf(
    "title" to title,
    "subject" to subject,
    "description" to description,
    "className" to className,
    "attachmentURL" to attachmentURL,
    "assignedDate" to assignedDate.asTimestamp(),
    "deadline" to deadline.asTimestamp(),
    "status" to status.token,
    "createdAt" to createdAt.asTimestamp(),
    "updatedAt" to updatedAt.asTimestamp(),
)

fun homeworkFromFirestore(id: String, data: Map<String, Any?>) = Homework(
    id = id,
    title = data["title"] as? String ?: "",
    subject = data["subject"] as? String ?: "",
    description = data["description"] as? String ?: "",
    className = data["className"] as? String ?: "",
    attachmentURL = data["attachmentURL"] as? String,
    assignedDate = data["assignedDate"].asEpochMillis(),
    deadline = data["deadline"].asEpochMillis(),
    status = HomeworkStatus.fromToken(data["status"] as? String),
    createdAt = data["createdAt"].asEpochMillis(),
    updatedAt = data["updatedAt"].asEpochMillis(),
    syncState = SyncState.SYNCED,
)

// ---------- Result ----------

fun ResultEntity.toDomain() = Result(
    id = id,
    studentId = studentId,
    homeworkId = homeworkId,
    completionStatus = CompletionStatus.fromToken(completionStatus),
    grade = grade,
    gradeType = GradeType.fromToken(gradeType),
    comment = comment,
    checkedDate = checkedDate,
    checkedBy = checkedBy,
    syncState = runCatching { SyncState.valueOf(syncState) }.getOrDefault(SyncState.SYNCED),
)

fun Result.toEntity() = ResultEntity(
    id = id,
    studentId = studentId,
    homeworkId = homeworkId,
    completionStatus = completionStatus.token,
    grade = grade,
    gradeType = gradeType.token,
    comment = comment,
    checkedDate = checkedDate,
    checkedBy = checkedBy,
    syncState = syncState.name,
)

fun Result.toFirestoreMap(): Map<String, Any?> = mapOf(
    "studentId" to studentId,
    "homeworkId" to homeworkId,
    // NOTE: `completionStatus`, deliberately NOT `status` — see NAMING DISAMBIGUATION.
    "completionStatus" to completionStatus.token,
    "grade" to grade,
    "gradeType" to gradeType.token,
    "comment" to comment,
    "checkedDate" to checkedDate.asTimestamp(),
    "checkedBy" to checkedBy,
)

fun resultFromFirestore(id: String, data: Map<String, Any?>) = Result(
    id = id,
    studentId = data["studentId"] as? String ?: "",
    homeworkId = data["homeworkId"] as? String ?: "",
    completionStatus = CompletionStatus.fromToken(data["completionStatus"] as? String),
    grade = (data["grade"] as? Number)?.toDouble(),
    gradeType = GradeType.fromToken(data["gradeType"] as? String),
    comment = data["comment"] as? String,
    checkedDate = data["checkedDate"].asEpochMillis(),
    checkedBy = data["checkedBy"] as? String ?: "",
    syncState = SyncState.SYNCED,
)
