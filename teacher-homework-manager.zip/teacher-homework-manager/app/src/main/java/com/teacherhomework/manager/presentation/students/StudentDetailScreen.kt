package com.teacherhomework.manager.presentation.students

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.CompletionStatusBadge
import com.teacherhomework.manager.presentation.components.ConfirmDialog
import com.teacherhomework.manager.presentation.components.EmptyStatePlaceholder
import com.teacherhomework.manager.presentation.components.InitialsAvatar
import com.teacherhomework.manager.presentation.components.OverflowAction
import com.teacherhomework.manager.presentation.components.StatTile
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.util.DateFormat
import com.teacherhomework.manager.presentation.util.toStringRes

/**
 * Student profile: identity header, stat rollup, and full homework history.
 *
 * Two distinct removal actions are offered, with different weights:
 *  - Archive (overflow) — reversible, keeps every grade.
 *  - Delete permanently (overflow, destructive dialog) — removes the student AND
 *    all of their results. The dialog states that consequence explicitly.
 */
@Composable
fun StudentDetailScreen(
    onNavigateBack: () -> Unit,
    onEdit: (String) -> Unit,
    onOpenHomework: (String) -> Unit,
    viewModel: StudentDetailViewModel = hiltViewModel(),
) {
    val student by viewModel.student.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    var showArchiveDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val locale = LocalConfiguration.current.locales[0]

    LaunchedEffect(state.deleted) { if (state.deleted) onNavigateBack() }

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHostState.showSnackbar(context.getString(it.toStringRes()))
            viewModel.consumeError()
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = student?.fullName ?: stringResource(R.string.title_student),
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(onClick = { student?.let { onEdit(it.id) } }) {
                        Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.action_edit))
                    }
                },
                overflowActions = listOf(
                    OverflowAction(
                        label = stringResource(R.string.action_archive_student),
                        icon = Icons.Filled.Archive,
                        onClick = { showArchiveDialog = true },
                    ),
                    OverflowAction(
                        label = stringResource(R.string.action_delete_permanently),
                        icon = Icons.Filled.Delete,
                        onClick = { showDeleteDialog = true },
                    ),
                ),
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Card(
                    shape = AppCorner.Card,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        InitialsAvatar(name = student?.fullName.orEmpty(), size = 64.dp)
                        Spacer(Modifier.padding(horizontal = 8.dp))
                        Column {
                            Text(
                                text = student?.fullName.orEmpty(),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                            )
                            student?.className?.takeIf { it.isNotBlank() }?.let {
                                Text(
                                    text = it,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            student?.phone?.takeIf { it.isNotBlank() }?.let {
                                Text(
                                    text = it,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        label = stringResource(R.string.stat_completion),
                        value = "${stats.completionRate.toInt()}%",
                        modifier = Modifier.weight(1f),
                    )
                    StatTile(
                        label = stringResource(R.string.stat_average),
                        value = if (stats.averageGrade == 0.0) "—"
                        else String.format(locale, "%.1f", stats.averageGrade),
                        modifier = Modifier.weight(1f),
                    )
                    StatTile(
                        label = stringResource(R.string.stat_missing),
                        value = stats.missing.toString(),
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            student?.notes?.takeIf { it.isNotBlank() }?.let { notes ->
                item {
                    Card(
                        shape = AppCorner.Card,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                text = stringResource(R.string.field_notes),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(notes, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            item {
                Text(
                    text = stringResource(R.string.section_homework_history),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }

            if (history.isEmpty()) {
                item {
                    EmptyStatePlaceholder(
                        icon = Icons.Outlined.Assignment,
                        title = stringResource(R.string.empty_history_title),
                        message = stringResource(R.string.empty_history_message),
                        modifier = Modifier.height(220.dp),
                    )
                }
            } else {
                items(history, key = { it.result.id }) { entry ->
                    Card(
                        onClick = { entry.homework?.let { onOpenHomework(it.id) } },
                        shape = AppCorner.Card,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    text = entry.homework?.title
                                        ?: stringResource(R.string.label_deleted_homework),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    text = DateFormat.date(entry.result.checkedDate, locale),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            entry.result.grade?.let { grade ->
                                Text(
                                    text = String.format(locale, "%.0f", grade),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(end = 10.dp),
                                )
                            }
                            CompletionStatusBadge(entry.result.completionStatus)
                        }
                    }
                }
            }
        }
    }

    if (showArchiveDialog) {
        ConfirmDialog(
            title = stringResource(R.string.dialog_archive_student_title),
            message = stringResource(R.string.dialog_archive_student_message),
            confirmLabel = stringResource(R.string.action_archive),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                showArchiveDialog = false
                viewModel.archive()
            },
            onDismiss = { showArchiveDialog = false },
        )
    }

    if (showDeleteDialog) {
        ConfirmDialog(
            title = stringResource(R.string.dialog_delete_student_title),
            // Names the exact number of results that will be destroyed, so the
            // teacher understands the scope before confirming.
            message = stringResource(R.string.dialog_delete_student_message, stats.total),
            confirmLabel = stringResource(R.string.action_delete_permanently),
            dismissLabel = stringResource(R.string.action_cancel),
            destructive = true,
            onConfirm = {
                showDeleteDialog = false
                viewModel.deletePermanently()
            },
            onDismiss = { showDeleteDialog = false },
        )
    }
}
