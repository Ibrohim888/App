package com.teacherhomework.manager.presentation.statistics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.BarChart
import com.teacherhomework.manager.presentation.components.EmptyStatePlaceholder
import com.teacherhomework.manager.presentation.components.OverflowAction
import com.teacherhomework.manager.presentation.components.StatTile
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.theme.LocalStatusColors
import com.teacherhomework.manager.presentation.util.DateFormat

/**
 * Statistics: headline figures, status distribution, grade trends, and a
 * per-class comparison.
 *
 * Every number here is computed on-device (no Cloud Functions) and read from the
 * local cache, so the screen opens instantly and works offline.
 */
@Composable
fun StatisticsScreen(
    onOpenReports: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: StatisticsViewModel = hiltViewModel(),
) {
    val summary by viewModel.summary.collectAsStateWithLifecycle()
    val distribution by viewModel.distribution.collectAsStateWithLifecycle()
    val monthly by viewModel.monthlyTrend.collectAsStateWithLifecycle()
    val weekly by viewModel.weeklyTrend.collectAsStateWithLifecycle()
    val classStats by viewModel.classStats.collectAsStateWithLifecycle()
    val locale = LocalConfiguration.current.locales[0]

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.nav_statistics),
                overflowActions = listOf(
                    OverflowAction(
                        label = stringResource(R.string.action_recalculate),
                        onClick = { viewModel.recalculate() },
                    ),
                    OverflowAction(
                        label = stringResource(R.string.nav_reports),
                        onClick = onOpenReports,
                    ),
                    OverflowAction(
                        label = stringResource(R.string.nav_settings),
                        onClick = onOpenSettings,
                    ),
                ),
            )
        },
    ) { padding ->
        if (distribution.total == 0) {
            EmptyStatePlaceholder(
                icon = Icons.Outlined.BarChart,
                title = stringResource(R.string.empty_statistics_title),
                message = stringResource(R.string.empty_statistics_message),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
            )
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        label = stringResource(R.string.stat_students),
                        value = summary.totalStudents.toString(),
                        modifier = Modifier.weight(1f),
                    )
                    StatTile(
                        label = stringResource(R.string.stat_completion),
                        value = "${summary.completionRate.toInt()}%",
                        modifier = Modifier.weight(1f),
                    )
                    StatTile(
                        label = stringResource(R.string.stat_average),
                        value = if (summary.averageGrade == 0.0) "—"
                        else String.format(locale, "%.1f", summary.averageGrade),
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            item { DistributionCard(distribution) }

            if (monthly.isNotEmpty()) {
                item {
                    ChartCard(title = stringResource(R.string.chart_monthly_average)) {
                        BarChart(
                            entries = monthly,
                            // Grades are normalized to 0-100, so pinning the
                            // ceiling keeps months comparable month to month.
                            maxValue = 100.0,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }

            if (weekly.isNotEmpty()) {
                item {
                    ChartCard(title = stringResource(R.string.chart_weekly_average)) {
                        BarChart(
                            entries = weekly,
                            maxValue = 100.0,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }

            if (classStats.isNotEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.section_by_class),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                items(classStats, key = { it.className }) { stat ->
                    Card(
                        shape = AppCorner.Card,
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    text = stat.className,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    text = stringResource(
                                        R.string.class_student_count,
                                        stat.studentCount,
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = if (stat.averageGrade == 0.0) "—"
                                    else String.format(locale, "%.1f", stat.averageGrade),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                Text(
                                    text = "${stat.completionRate.toInt()}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }

            if (summary.lastRecalculatedAt > 0) {
                item {
                    Text(
                        text = stringResource(
                            R.string.stats_last_updated,
                            DateFormat.dateTime(summary.lastRecalculatedAt, locale),
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun ChartCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = AppCorner.Card,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

/**
 * COMPLETED / PARTIAL / MISSING split as a proportional bar plus explicit
 * counts. The counts matter: a stacked bar alone conveys the split by color
 * only, which fails for color-blind users and in a grayscale screenshot.
 */
@Composable
private fun DistributionCard(distribution: StatusDistribution) {
    val colors = LocalStatusColors.current
    val total = distribution.total.coerceAtLeast(1)

    Card(
        shape = AppCorner.Card,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                text = stringResource(R.string.section_status_distribution),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(14.dp)
                    .clip(AppCorner.Badge)
            ) {
                Segment(distribution.completed, total, colors.completedText)
                Segment(distribution.partial, total, colors.partialText)
                Segment(distribution.missing, total, colors.missingText)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                LegendItem(
                    stringResource(R.string.status_completed),
                    distribution.completed,
                    colors.completedText,
                )
                LegendItem(
                    stringResource(R.string.status_partial),
                    distribution.partial,
                    colors.partialText,
                )
                LegendItem(
                    stringResource(R.string.status_missing),
                    distribution.missing,
                    colors.missingText,
                )
            }
        }
    }
}

/** One proportional slice of the distribution bar. */
@Composable
private fun RowScope.Segment(count: Int, total: Int, color: Color) {
    if (count <= 0) return
    Box(
        Modifier
            .weight(count.toFloat() / total)
            .fillMaxHeight()
            .background(color)
    )
}

@Composable
private fun LegendItem(label: String, count: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .height(10.dp)
                .width(10.dp)
                .clip(AppCorner.Badge)
                .background(color)
        )
        Spacer(Modifier.width(5.dp))
        Text(
            text = "$label: $count",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
