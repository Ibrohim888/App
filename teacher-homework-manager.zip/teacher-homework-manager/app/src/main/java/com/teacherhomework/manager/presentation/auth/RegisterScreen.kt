package com.teacherhomework.manager.presentation.auth

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.presentation.components.AppTextField
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.PrimaryButton
import com.teacherhomework.manager.presentation.util.toStringRes

/**
 * Registration screen, wired to Firebase Auth. On success the repository also
 * creates the `teachers/{uid}` document, seeded with the language and theme the
 * teacher already picked on the first-launch screens.
 */
@Composable
fun RegisterScreen(
    onRegisterSuccess: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateBack: () -> Unit,
    viewModel: AuthViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(state.isAuthenticated) {
        if (state.isAuthenticated) onRegisterSuccess()
    }

    LaunchedEffect(state.formError) {
        state.formError?.let { error ->
            snackbarHostState.showSnackbar(context.getString(error.toStringRes()))
            viewModel.consumeFormError()
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.register_title),
                onNavigateBack = onNavigateBack,
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
        ) {
            Text(
                text = stringResource(R.string.register_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(20.dp))
            AppTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = stringResource(R.string.field_full_name),
                errorText = state.nameError?.let { stringResource(it.toStringRes()) },
            )
            Spacer(Modifier.height(16.dp))
            AppTextField(
                value = email,
                onValueChange = { email = it },
                label = stringResource(R.string.field_email),
                keyboardType = KeyboardType.Email,
                errorText = state.emailError?.let { stringResource(it.toStringRes()) },
            )
            Spacer(Modifier.height(16.dp))
            AppTextField(
                value = password,
                onValueChange = { password = it },
                label = stringResource(R.string.field_password),
                isPassword = true,
                errorText = state.passwordError?.let { stringResource(it.toStringRes()) },
            )
            Spacer(Modifier.height(16.dp))
            AppTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = stringResource(R.string.field_confirm_password),
                isPassword = true,
                errorText = state.confirmPasswordError?.let { stringResource(it.toStringRes()) },
            )
            Spacer(Modifier.height(24.dp))
            PrimaryButton(
                text = stringResource(R.string.action_register),
                onClick = { viewModel.register(fullName, email, password, confirmPassword) },
                loading = state.isLoading,
            )
            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.prompt_have_account),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = onNavigateToLogin) {
                    Text(
                        text = stringResource(R.string.prompt_sign_in),
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}
