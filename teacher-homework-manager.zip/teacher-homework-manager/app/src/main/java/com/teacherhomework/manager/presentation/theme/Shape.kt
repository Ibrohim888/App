package com.teacherhomework.manager.presentation.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/**
 * Corner-radius scale from UI STYLE DIRECTION, mapped onto Material 3's [Shapes]
 * roles so standard components pick up the rounded, warm look automatically:
 *   - extraSmall 8dp  → chips / status badges
 *   - small      12dp → buttons
 *   - medium     16dp → cards
 *   - large      22dp → large containers
 *   - extraLarge 28dp → gradient header container
 */
val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

/** Named shapes for cases where the semantic Material role isn't a clean fit. */
object AppCorner {
    val Badge = RoundedCornerShape(10.dp)
    val Chip = RoundedCornerShape(10.dp)
    val Button = RoundedCornerShape(14.dp)
    val Card = RoundedCornerShape(16.dp)
    val Avatar = RoundedCornerShape(13.dp) // rounded-square list-row avatar
    /** Gradient header: rounded only on the bottom, per the header treatment. */
    val HeaderBottom = RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp)
}
