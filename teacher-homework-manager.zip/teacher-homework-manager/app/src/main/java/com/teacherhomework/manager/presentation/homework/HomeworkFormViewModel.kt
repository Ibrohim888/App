package com.teacherhomework.manager.presentation.homework

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.domain.model.SyncState
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import com.teacherhomework.manager.presentation.navigation.NavRoutes
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject

data class HomeworkFormUiState(
    val title: String = "",
    val subject: String = "",
    val description: String = "",
    val className: String = "",
    val assignedDate: Long = System.currentTimeMillis(),
    val deadline: Long = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(7),
    val status: HomeworkStatus = HomeworkStatus.ACTIVE,
    val titleError: AppError? = null,
    val subjectError: AppError? = null,
    val classNameError: AppError? = null,
    val deadlineError: AppError? = null,
    val isSaving: Boolean = false,
    val saved: Boolean = false,
    val error: AppError? = null,
    /**
     * True when editing an assignment that already has grades AND the deadline
     * has been changed. Drives the inline notice explaining that already-entered
     * grades are NOT retroactively re-evaluated (HOMEWORK EDITING POLICY).
     */
    val showDeadlineChangeNotice: Boolean = false,
)

/**
 * Create/edit a homework assignment.
 *
 * EDITING POLICY: every field stays editable at any status and any age, even
 * once results exist — nothing is locked. The one obligation is honesty: if the
 * deadline changes on an assignment that already has grades, the UI must say
 * plainly that existing grades won't be re-evaluated.
 */
@HiltViewModel
class HomeworkFormViewModel @Inject constructor(
    private val homeworkRepository: HomeworkRepository,
    private val resultRepository: ResultRepository,
    studentRepository: StudentRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val homeworkId: String = savedStateHandle[NavRoutes.ARG_HOMEWORK_ID] ?: NavRoutes.NEW
    val isNew: Boolean = homeworkId == NavRoutes.NEW

    private val _uiState = MutableStateFlow(HomeworkFormUiState())
    val uiState: StateFlow<HomeworkFormUiState> = _uiState.asStateFlow()

    /**
     * Class options come from the teacher's actual students, not free text —
     * this is what guarantees a homework's `className` matches real students so
     * the checking screen can find them.
     */
    val classNames: StateFlow<List<String>> = studentRepository.observeClassNames()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private var loadedCreatedAt: Long = 0L
    private var originalDeadline: Long = 0L
    private var hasResults: Boolean = false

    init {
        if (!isNew) {
            viewModelScope.launch {
                homeworkRepository.getHomework(homeworkId)?.let { hw ->
                    loadedCreatedAt = hw.createdAt
                    originalDeadline = hw.deadline
                    hasResults = resultRepository.hasResultsForHomework(homeworkId)
                    _uiState.update {
                        it.copy(
                            title = hw.title,
                            subject = hw.subject,
                            description = hw.description,
                            className = hw.className,
                            assignedDate = hw.assignedDate,
                            deadline = hw.deadline,
                            status = hw.status,
                        )
                    }
                }
            }
        }
    }

    fun onTitleChange(v: String) = _uiState.update { it.copy(title = v, titleError = null) }
    fun onSubjectChange(v: String) = _uiState.update { it.copy(subject = v, subjectError = null) }
    fun onDescriptionChange(v: String) = _uiState.update { it.copy(description = v) }
    fun onClassNameChange(v: String) = _uiState.update { it.copy(className = v, classNameError = null) }
    fun onStatusChange(v: HomeworkStatus) = _uiState.update { it.copy(status = v) }

    fun onAssignedDateChange(v: Long) = _uiState.update {
        it.copy(assignedDate = v, deadlineError = null)
    }

    /** Surfaces the "existing grades won't change" notice when it's warranted. */
    fun onDeadlineChange(v: Long) = _uiState.update {
        it.copy(
            deadline = v,
            deadlineError = null,
            showDeadlineChangeNotice = !isNew && hasResults && v != originalDeadline,
        )
    }

    fun save() {
        val s = _uiState.value
        val titleError = if (s.title.isBlank()) AppError.EMPTY_FIELD else null
        val subjectError = if (s.subject.isBlank()) AppError.EMPTY_FIELD else null
        val classError = if (s.className.isBlank()) AppError.EMPTY_FIELD else null
        // A deadline before the assigned date is always a data-entry mistake.
        val deadlineError = if (s.deadline < s.assignedDate) AppError.DEADLINE_BEFORE_ASSIGNED else null

        if (titleError != null || subjectError != null || classError != null || deadlineError != null) {
            _uiState.update {
                it.copy(
                    titleError = titleError,
                    subjectError = subjectError,
                    classNameError = classError,
                    deadlineError = deadlineError,
                )
            }
            return
        }

        _uiState.update { it.copy(isSaving = true) }
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val homework = Homework(
                id = if (isNew) UUID.randomUUID().toString() else homeworkId,
                title = s.title.trim(),
                subject = s.subject.trim(),
                description = s.description.trim(),
                className = s.className.trim(),
                attachmentURL = null,
                assignedDate = s.assignedDate,
                deadline = s.deadline,
                status = s.status,
                createdAt = if (isNew) now else loadedCreatedAt,
                updatedAt = now,
                syncState = SyncState.PENDING,
            )
            when (val result = homeworkRepository.upsertHomework(homework)) {
                is AppResult.Success -> _uiState.update { it.copy(isSaving = false, saved = true) }
                is AppResult.Error -> _uiState.update {
                    // Saved locally regardless; the banner is about the cloud copy.
                    it.copy(isSaving = false, saved = true, error = result.error)
                }
            }
        }
    }

    fun consumeError() = _uiState.update { it.copy(error = null) }
}
