package com.teacherhomework.manager.presentation.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.domain.model.AppLanguage
import com.teacherhomework.manager.domain.model.AppThemeColor
import com.teacherhomework.manager.domain.model.DarkModePreference
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.ConfirmDialog
import com.teacherhomework.manager.presentation.components.InitialsAvatar
import com.teacherhomework.manager.presentation.components.SecondaryButton
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.theme.resolveTheme
import java.util.Locale

/**
 * Settings — appearance, language, local reminders, storage, account.
 *
 * Language and theme changes apply IMMEDIATELY with no restart, because both are
 * held in app-level state that the whole Compose tree reads.
 */
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    onSignedOut: () -> Unit,
    onOpenReports: () -> Unit,
    onOpenAbout: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()
    val themeColor by viewModel.themeColor.collectAsStateWithLifecycle()
    val darkMode by viewModel.darkMode.collectAsStateWithLifecycle()
    val notifications by viewModel.notificationSettings.collectAsStateWithLifecycle()
    val teacher by viewModel.teacher.collectAsStateWithLifecycle()
    var showSignOutDialog by remember { mutableStateOf(false) }

    LaunchedEffect(state.signedOut) { if (state.signedOut) onSignedOut() }

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.nav_settings),
                onNavigateBack = onNavigateBack,
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            // ---- Account ----
            teacher?.let { t ->
                Card(
                    shape = AppCorner.Card,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        InitialsAvatar(name = t.fullName, size = 52.dp)
                        Spacer(Modifier.size(12.dp))
                        Column {
                            Text(
                                text = t.fullName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                text = t.email,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
            }

            // ---- Language ----
            SectionTitle(stringResource(R.string.settings_language))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AppLanguage.entries.forEach { lang ->
                    FilterChip(
                        selected = language == lang,
                        onClick = { viewModel.setLanguage(lang) },
                        // Each language is labeled in ITS OWN language, so a
                        // teacher who can't read the current UI can still find
                        // theirs — the standard for language pickers.
                        label = { Text(stringResource(lang.labelRes())) },
                        shape = AppCorner.Chip,
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            // ---- Accent theme ----
            SectionTitle(stringResource(R.string.settings_appearance))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                AppThemeColor.entries.forEach { theme ->
                    ThemeSwatch(
                        theme = theme,
                        isSelected = themeColor == theme,
                        onClick = { viewModel.setThemeColor(theme) },
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // ---- Dark mode ----
            SectionTitle(stringResource(R.string.settings_dark_mode))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkModePreference.entries.forEach { pref ->
                    FilterChip(
                        selected = darkMode == pref,
                        onClick = { viewModel.setDarkMode(pref) },
                        label = { Text(stringResource(pref.labelRes())) },
                        shape = AppCorner.Chip,
                    )
                }
            }

            Spacer(Modifier.height(22.dp))

            // ---- Local reminders ----
            SectionTitle(stringResource(R.string.settings_reminders))

            // HONEST DISCLOSURE: reminders are on-device and best-effort. The
            // teacher is told this here rather than discovering it when one
            // arrives late.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(AppCorner.Card)
                    .background(MaterialTheme.colorScheme.secondaryContainer)
                    .padding(12.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(Modifier.size(10.dp))
                Text(
                    text = stringResource(R.string.settings_reminders_disclosure),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }
            Spacer(Modifier.height(8.dp))

            SettingSwitch(
                title = stringResource(R.string.settings_reminders_enabled),
                checked = notifications.localRemindersEnabled,
                onCheckedChange = {
                    viewModel.setNotificationSettings(
                        notifications.copy(localRemindersEnabled = it)
                    )
                },
            )
            SettingSwitch(
                title = stringResource(R.string.settings_deadline_reminders),
                checked = notifications.deadlineReminders,
                enabled = notifications.localRemindersEnabled,
                onCheckedChange = {
                    viewModel.setNotificationSettings(notifications.copy(deadlineReminders = it))
                },
            )
            SettingSwitch(
                title = stringResource(R.string.settings_missing_alerts),
                checked = notifications.missingHomeworkAlerts,
                enabled = notifications.localRemindersEnabled,
                onCheckedChange = {
                    viewModel.setNotificationSettings(
                        notifications.copy(missingHomeworkAlerts = it)
                    )
                },
            )
            SettingSwitch(
                title = stringResource(R.string.settings_weekly_summary),
                checked = notifications.weeklyReportSummaries,
                enabled = notifications.localRemindersEnabled,
                onCheckedChange = {
                    viewModel.setNotificationSettings(
                        notifications.copy(weeklyReportSummaries = it)
                    )
                },
            )

            Spacer(Modifier.height(22.dp))

            // ---- Storage usage ----
            SectionTitle(stringResource(R.string.settings_storage))
            Text(
                text = stringResource(
                    R.string.settings_storage_used,
                    formatMb(state.storageBytesUsed),
                    formatMb(state.storageQuotaBytes),
                ),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { state.storageFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = if (state.showStorageWarning) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.primary,
            )
            if (state.showStorageWarning) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.settings_storage_warning),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            Spacer(Modifier.height(22.dp))

            SectionTitle(stringResource(R.string.settings_other))
            SettingRow(
                title = stringResource(R.string.nav_reports),
                onClick = onOpenReports,
            )
            SettingRow(
                title = stringResource(R.string.nav_about),
                onClick = onOpenAbout,
            )

            Spacer(Modifier.height(24.dp))
            SecondaryButton(
                text = stringResource(R.string.action_sign_out),
                onClick = { showSignOutDialog = true },
            )
            Spacer(Modifier.height(28.dp))
        }
    }

    if (showSignOutDialog) {
        ConfirmDialog(
            title = stringResource(R.string.dialog_sign_out_title),
            message = stringResource(R.string.dialog_sign_out_message),
            confirmLabel = stringResource(R.string.action_sign_out),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                showSignOutDialog = false
                viewModel.signOut()
            },
            onDismiss = { showSignOutDialog = false },
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(bottom = 8.dp),
    )
}

/** A labeled switch row; the whole row is the 48dp+ tap target. */
@Composable
private fun SettingSwitch(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            color = if (enabled) MaterialTheme.colorScheme.onSurface
            else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange, enabled = enabled)
    }
}

@Composable
private fun SettingRow(title: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
    }
}

/**
 * A live accent preview, not a flat swatch: the circle shows the theme's actual
 * gradient so the teacher sees what the header will look like.
 */
@Composable
private fun ThemeSwatch(
    theme: AppThemeColor,
    isSelected: Boolean,
    onClick: () -> Unit,
) {
    // resolveTheme is the single source of truth for accent visuals — reusing it
    // means a swatch can never drift from what the theme actually renders.
    val resolved = resolveTheme(theme, darkTheme = false)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(AppCorner.Card)
            .clickable(onClick = onClick)
            .padding(6.dp),
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(resolved.gradient.start, resolved.gradient.end)
                    )
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (isSelected) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = null,
                    tint = Color.White,
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = stringResource(theme.labelRes()),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun formatMb(bytes: Long): String =
    String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))

@androidx.annotation.StringRes
private fun DarkModePreference.labelRes(): Int = when (this) {
    DarkModePreference.SYSTEM -> R.string.dark_mode_system
    DarkModePreference.LIGHT -> R.string.dark_mode_light
    DarkModePreference.DARK -> R.string.dark_mode_dark
}

/**
 * Language names are `translatable="false"` endonyms (O'zbekcha / Русский /
 * English) — identical in every locale file on purpose.
 */
@androidx.annotation.StringRes
private fun AppLanguage.labelRes(): Int = when (this) {
    AppLanguage.UZBEK -> R.string.language_uzbek
    AppLanguage.RUSSIAN -> R.string.language_russian
    AppLanguage.ENGLISH -> R.string.language_english
}

@androidx.annotation.StringRes
private fun AppThemeColor.labelRes(): Int = when (this) {
    AppThemeColor.FOREST_GREEN -> R.string.theme_forest_green
    AppThemeColor.TRUST_BLUE -> R.string.theme_trust_blue
    AppThemeColor.VIOLET -> R.string.theme_violet
    AppThemeColor.WARM_ROSE -> R.string.theme_warm_rose
    AppThemeColor.TEAL -> R.string.theme_teal
}
