package com.teacherhomework.manager.presentation.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.teacherhomework.manager.R
import com.teacherhomework.manager.domain.model.AppThemeColor
import com.teacherhomework.manager.presentation.components.PrimaryButton
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.theme.resolveTheme

/**
 * MANDATORY first-launch screen #2 (immediately after language selection,
 * before auth). Shows all 5 themes as equally-weighted LIVE PREVIEW cards — each
 * a miniature dashboard header + stat card rendered in that theme's real colors
 * (not a flat swatch), per THEME COLOR POLICY — so the teacher sees what they're
 * choosing. A Continue primary CTA confirms.
 *
 * @param onContinue invoked with the chosen accent; caller persists it and
 *        advances to the auth screens, which then render in this theme.
 */
@Composable
fun ThemeColorSelectionScreen(
    onContinue: (AppThemeColor) -> Unit,
) {
    var selected by remember { mutableStateOf(AppThemeColor.DEFAULT) }

    val themeLabels = mapOf(
        AppThemeColor.FOREST_GREEN to R.string.theme_forest_green,
        AppThemeColor.TRUST_BLUE to R.string.theme_trust_blue,
        AppThemeColor.VIOLET to R.string.theme_violet,
        AppThemeColor.WARM_ROSE to R.string.theme_warm_rose,
        AppThemeColor.TEAL to R.string.theme_teal,
    )

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 28.dp),
        ) {
            Text(
                text = stringResource(R.string.theme_select_title),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.theme_select_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(20.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(AppThemeColor.entries) { theme ->
                    ThemePreviewCard(
                        theme = theme,
                        label = stringResource(themeLabels.getValue(theme)),
                        selected = selected == theme,
                        onSelect = { selected = theme },
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            PrimaryButton(
                text = stringResource(R.string.action_continue),
                onClick = { onContinue(selected) },
            )
        }
    }
}

/**
 * A single theme option: a live mini-preview (gradient header + a stat card +
 * a status pill) rendered in [theme]'s actual colors via [resolveTheme], plus a
 * localized label and a selected checkmark. The preview honors the current
 * light/dark mode so the teacher previews what they'll actually see.
 */
@Composable
private fun ThemePreviewCard(
    theme: AppThemeColor,
    label: String,
    selected: Boolean,
    onSelect: () -> Unit,
) {
    val resolved = resolveTheme(theme, isSystemInDarkTheme())
    val selectedDesc = stringResource(R.string.cd_selected)

    Card(
        shape = AppCorner.Card,
        colors = CardDefaults.cardColors(containerColor = resolved.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = if (selected) 6.dp else 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (selected) Modifier.border(2.5.dp, resolved.colorScheme.primary, AppCorner.Card)
                else Modifier
            )
            .selectable(selected = selected, onClick = onSelect),
    ) {
        Column {
            // Mini gradient header with an overlapping stat card.
            Box {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(66.dp)
                        .clip(RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(resolved.gradient.start, resolved.gradient.end)
                            )
                        )
                        .padding(10.dp),
                ) {
                    Text(
                        text = stringResource(R.string.theme_preview_greeting),
                        style = MaterialTheme.typography.labelMedium,
                        color = resolved.colorScheme.onPrimary,
                    )
                }
                // Overlapping stat card (negative offset via padding on parent Column below)
                Card(
                    shape = AppCorner.Badge,
                    colors = CardDefaults.cardColors(containerColor = resolved.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 10.dp)
                        .padding(top = 40.dp)
                        .fillMaxWidth(0.7f),
                ) {
                    Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                        Text(
                            text = stringResource(R.string.theme_preview_stat_value),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = resolved.colorScheme.primary,
                        )
                        Text(
                            text = stringResource(R.string.theme_preview_stat_label),
                            style = MaterialTheme.typography.labelMedium,
                            color = resolved.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    color = resolved.colorScheme.onSurface,
                )
                if (selected) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = selectedDesc,
                        tint = resolved.colorScheme.primary,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
        }
    }
}
