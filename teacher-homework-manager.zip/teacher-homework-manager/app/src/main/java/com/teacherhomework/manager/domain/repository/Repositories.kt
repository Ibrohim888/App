package com.teacherhomework.manager.domain.repository

import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.domain.model.NotificationSettings
import com.teacherhomework.manager.domain.model.Result
import com.teacherhomework.manager.domain.model.StatisticsSummary
import com.teacherhomework.manager.domain.model.Student
import com.teacherhomework.manager.domain.model.Teacher
import com.teacherhomework.manager.domain.model.TeacherSettings
import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.flow.Flow

/**
 * Teacher document + settings. Settings are written both locally (DataStore, via
 * AppPreferences) and here to Firestore (`teachers/{teacherId}.settings`) so they
 * survive reinstall / new-device login.
 */
interface TeacherRepository {
    fun observeTeacher(): Flow<Teacher?>
    suspend fun ensureTeacherDocument(uid: String, fullName: String, email: String, settings: TeacherSettings): AppResult<Unit>
    suspend fun updateSettings(settings: TeacherSettings): AppResult<Unit>
    suspend fun updateLastLogin()
}

/**
 * Students. Reads come from Room first (offline-first); a background sync
 * reconciles with Firestore. Lists are paginated at the query level (limit +
 * className/search filters) so we never fetch all ~120 students at once
 * (COST AWARENESS).
 */
interface StudentRepository {
    /** Observe students from the local cache, filtered/sorted. activeOnly hides soft-deleted. */
    fun observeStudents(search: String = "", className: String? = null, activeOnly: Boolean = true): Flow<List<Student>>
    fun observeStudent(studentId: String): Flow<Student?>
    /** Distinct non-null className values across the teacher's students (for the homework class picker). */
    fun observeClassNames(): Flow<List<String>>
    suspend fun getStudent(studentId: String): Student?
    suspend fun upsertStudent(student: Student): AppResult<Unit>
    /** Soft delete: sets isActive=false; keeps results/statistics intact. */
    suspend fun softDeleteStudent(studentId: String): AppResult<Unit>
    /** Hard delete: removes the student AND cascades to their results. Triggers a stats recalc afterward. */
    suspend fun hardDeleteStudent(studentId: String): AppResult<Unit>
    /** Pull latest from Firestore into Room. */
    suspend fun refresh(): AppResult<Unit>
}

/** Homework assignments. */
interface HomeworkRepository {
    fun observeHomework(status: HomeworkStatus? = null, subject: String? = null, search: String = ""): Flow<List<Homework>>
    fun observeHomeworkById(homeworkId: String): Flow<Homework?>
    suspend fun getHomework(homeworkId: String): Homework?
    suspend fun upsertHomework(homework: Homework): AppResult<Unit>
    /**
     * Deletes the homework and CASCADES to every result referencing it, then
     * triggers a statistics recalculation.
     *
     * POLICY OVERRIDE (teacher decision, supersedes the original spec): deleting
     * a graded homework is no longer blocked. The UI must instead show a
     * confirmation dialog (warning that recorded grades will also be removed)
     * when results exist — see [com.teacherhomework.manager.domain.usecase.CheckHomeworkDeletionUseCase].
     * Because deletion is now always permitted, NO security rule blocks
     * homework deletion based on existing results.
     */
    suspend fun deleteHomework(homeworkId: String): AppResult<Unit>
    suspend fun archiveHomework(homeworkId: String): AppResult<Unit>
    suspend fun refresh(): AppResult<Unit>
}

/** Student results (grading). */
interface ResultRepository {
    fun observeResultsForHomework(homeworkId: String): Flow<List<Result>>
    fun observeResultsForStudent(studentId: String): Flow<List<Result>>
    /**
     * Every cached result. Used by the Dashboard to compute "needs attention"
     * across all assignments at once; reads from Room, so it costs no Firestore
     * reads regardless of how often the screen recomposes.
     */
    fun observeAllResults(): Flow<List<Result>>
    /** Reactive "does this homework have any results" — drives the delete-disable state live. */
    fun observeHasResults(homeworkId: String): Flow<Boolean>
    suspend fun hasResultsForHomework(homeworkId: String): Boolean
    /** Number of recorded results for a homework — sizes the delete-warning copy. */
    suspend fun countResultsForHomework(homeworkId: String): Int
    suspend fun getResultFor(homeworkId: String, studentId: String): Result?
    /** Upserts a result (grade validated by ValidateGradeUseCase before this is called). */
    suspend fun upsertResult(result: Result): AppResult<Unit>
    suspend fun deleteResultsForStudent(studentId: String): AppResult<Unit>
    suspend fun allResults(): List<Result>
    suspend fun refresh(): AppResult<Unit>
}

/** Client-computed statistics (on-device; no Cloud Functions). */
interface StatisticsRepository {
    fun observeSummary(): Flow<StatisticsSummary>
    /**
     * Recomputes the summary from the authoritative `results` collection and
     * commits it via a Firestore transaction (idempotent, race-safe across
     * devices — MULTI-DEVICE WRITE SAFETY). See Phase 4.
     */
    suspend fun recalculateAndCommit(): AppResult<Unit>
}

/** Local-only notification preferences (no push fields — permanently out of scope). */
interface NotificationSettingsRepository {
    fun observe(): Flow<NotificationSettings>
    suspend fun update(settings: NotificationSettings): AppResult<Unit>
}
