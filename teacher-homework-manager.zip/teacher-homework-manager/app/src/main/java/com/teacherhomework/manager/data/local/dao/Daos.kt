package com.teacherhomework.manager.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import com.teacherhomework.manager.data.local.entity.HomeworkEntity
import com.teacherhomework.manager.data.local.entity.NotificationEntity
import com.teacherhomework.manager.data.local.entity.ResultEntity
import com.teacherhomework.manager.data.local.entity.StatisticsEntity
import com.teacherhomework.manager.data.local.entity.StudentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    /**
     * Observe students filtered by an optional search term (matches first/last/
     * full name or class) and optional class, active-only by default. LIMIT caps
     * the page size so we never load the entire roster at once (COST AWARENESS).
     */
    @Query(
        """
        SELECT * FROM students
        WHERE (:activeOnly = 0 OR isActive = 1)
          AND (:className IS NULL OR className = :className)
          AND (
                :search = '' OR
                firstName LIKE '%' || :search || '%' OR
                lastName  LIKE '%' || :search || '%' OR
                fullName  LIKE '%' || :search || '%' OR
                className LIKE '%' || :search || '%'
              )
        ORDER BY className ASC, fullName ASC
        LIMIT :limit
        """
    )
    fun observe(search: String, className: String?, activeOnly: Boolean, limit: Int): Flow<List<StudentEntity>>

    @Query("SELECT * FROM students WHERE id = :id")
    fun observeById(id: String): Flow<StudentEntity?>

    @Query("SELECT * FROM students WHERE id = :id")
    suspend fun getById(id: String): StudentEntity?

    @Query("SELECT DISTINCT className FROM students WHERE className IS NOT NULL AND className != '' AND isActive = 1 ORDER BY className ASC")
    fun observeClassNames(): Flow<List<String>>

    @Upsert
    suspend fun upsert(student: StudentEntity)

    @Upsert
    suspend fun upsertAll(students: List<StudentEntity>)

    @Query("UPDATE students SET isActive = 0, syncState = :syncState WHERE id = :id")
    suspend fun softDelete(id: String, syncState: String)

    @Query("DELETE FROM students WHERE id = :id")
    suspend fun hardDelete(id: String)

    @Query("SELECT COUNT(*) FROM students WHERE isActive = 1")
    suspend fun activeCount(): Int

    /** Rows not yet confirmed in Firestore — the sync manager's retry queue. */
    @Query("SELECT * FROM students WHERE syncState != :syncedState")
    suspend fun getPending(syncedState: String): List<StudentEntity>
}

@Dao
interface HomeworkDao {
    @Query(
        """
        SELECT * FROM homework
        WHERE (:status IS NULL OR status = :status)
          AND (:subject IS NULL OR subject = :subject)
          AND (:search = '' OR title LIKE '%' || :search || '%' OR subject LIKE '%' || :search || '%')
        ORDER BY deadline ASC
        """
    )
    fun observe(status: String?, subject: String?, search: String): Flow<List<HomeworkEntity>>

    @Query("SELECT * FROM homework WHERE id = :id")
    fun observeById(id: String): Flow<HomeworkEntity?>

    @Query("SELECT * FROM homework WHERE id = :id")
    suspend fun getById(id: String): HomeworkEntity?

    @Upsert
    suspend fun upsert(homework: HomeworkEntity)

    @Upsert
    suspend fun upsertAll(homework: List<HomeworkEntity>)

    @Query("DELETE FROM homework WHERE id = :id")
    suspend fun delete(id: String)

    /** Rows not yet confirmed in Firestore — the sync manager's retry queue. */
    @Query("SELECT * FROM homework WHERE syncState != :syncedState")
    suspend fun getPending(syncedState: String): List<HomeworkEntity>
}

@Dao
interface ResultDao {
    @Query("SELECT * FROM results WHERE homeworkId = :homeworkId")
    fun observeForHomework(homeworkId: String): Flow<List<ResultEntity>>

    @Query("SELECT * FROM results WHERE studentId = :studentId ORDER BY checkedDate DESC")
    fun observeForStudent(studentId: String): Flow<List<ResultEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM results WHERE homeworkId = :homeworkId)")
    fun observeHasResults(homeworkId: String): Flow<Boolean>

    @Query("SELECT COUNT(*) FROM results WHERE homeworkId = :homeworkId")
    suspend fun countForHomework(homeworkId: String): Int

    @Query("SELECT * FROM results WHERE homeworkId = :homeworkId AND studentId = :studentId LIMIT 1")
    suspend fun getFor(homeworkId: String, studentId: String): ResultEntity?

    @Query("SELECT * FROM results")
    suspend fun getAll(): List<ResultEntity>

    @Query("SELECT * FROM results")
    fun observeAll(): Flow<List<ResultEntity>>

    @Upsert
    suspend fun upsert(result: ResultEntity)

    @Upsert
    suspend fun upsertAll(results: List<ResultEntity>)

    @Query("DELETE FROM results WHERE studentId = :studentId")
    suspend fun deleteForStudent(studentId: String)

    @Query("DELETE FROM results WHERE homeworkId = :homeworkId")
    suspend fun deleteForHomework(homeworkId: String)

    /** Rows not yet confirmed in Firestore — the sync manager's retry queue. */
    @Query("SELECT * FROM results WHERE syncState != :syncedState")
    suspend fun getPending(syncedState: String): List<ResultEntity>
}

@Dao
interface StatisticsDao {
    /** Single cached summary row; null until the first recalculation completes. */
    @Query("SELECT * FROM statistics WHERE id = 'summary'")
    fun observe(): Flow<StatisticsEntity?>

    @Upsert
    suspend fun upsert(statistics: StatisticsEntity)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY postedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(notification: NotificationEntity)

    @Query("UPDATE notifications SET read = 1 WHERE id = :id")
    suspend fun markRead(id: String)

    @Query("SELECT COUNT(*) FROM notifications WHERE read = 0")
    fun observeUnreadCount(): Flow<Int>
}
