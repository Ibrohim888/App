package com.teacherhomework.manager.workers

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.teacherhomework.manager.domain.model.NotificationSettings
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Calendar
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Registers and cancels the periodic LOCAL reminder work.
 *
 * All three are periodic requests with `KEEP`, so re-running [sync] on every app
 * start doesn't reset their schedules. When the teacher turns a reminder off,
 * its work is CANCELLED rather than left running and short-circuiting inside the
 * worker — cancelling means the OS stops waking us at all, which is better for
 * battery.
 *
 * The initial delay aims each job at a sensible local time; WorkManager treats
 * that as the start of a flex window, not a guarantee. Periodic work also has a
 * platform minimum interval of 15 minutes, which none of these approach.
 */
@Singleton
class ReminderScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val workManager get() = WorkManager.getInstance(context)

    /** Applies [settings] — scheduling what's enabled and cancelling what isn't. */
    fun sync(settings: NotificationSettings) {
        if (!settings.localRemindersEnabled) {
            cancelAll()
            return
        }
        if (settings.deadlineReminders) scheduleDeadlineReminders() else cancel(DeadlineReminderWorker.WORK_NAME)
        if (settings.missingHomeworkAlerts) scheduleMissingAlerts() else cancel(MissingHomeworkWorker.WORK_NAME)
        if (settings.weeklyReportSummaries) scheduleWeeklySummary() else cancel(WeeklySummaryWorker.WORK_NAME)
    }

    /** Daily, aimed at 08:00 local — before the school day starts. */
    private fun scheduleDeadlineReminders() {
        val request = PeriodicWorkRequestBuilder<DeadlineReminderWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(millisUntil(hour = 8), TimeUnit.MILLISECONDS)
            .build()
        workManager.enqueueUniquePeriodicWork(
            DeadlineReminderWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }

    /** Daily, aimed at 18:00 local — after lessons, when grading usually happens. */
    private fun scheduleMissingAlerts() {
        val request = PeriodicWorkRequestBuilder<MissingHomeworkWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(millisUntil(hour = 18), TimeUnit.MILLISECONDS)
            .build()
        workManager.enqueueUniquePeriodicWork(
            MissingHomeworkWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }

    /** Weekly, aimed at Sunday 19:00 local. */
    private fun scheduleWeeklySummary() {
        val request = PeriodicWorkRequestBuilder<WeeklySummaryWorker>(7, TimeUnit.DAYS)
            .setInitialDelay(millisUntilSunday(hour = 19), TimeUnit.MILLISECONDS)
            .build()
        workManager.enqueueUniquePeriodicWork(
            WeeklySummaryWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }

    private fun cancel(name: String) = workManager.cancelUniqueWork(name)

    fun cancelAll() {
        cancel(DeadlineReminderWorker.WORK_NAME)
        cancel(MissingHomeworkWorker.WORK_NAME)
        cancel(WeeklySummaryWorker.WORK_NAME)
    }

    /** Milliseconds until the next occurrence of [hour]:00 local time. */
    private fun millisUntil(hour: Int): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            // Already past today → aim at tomorrow.
            if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis - now.timeInMillis
    }

    /** Milliseconds until the next Sunday at [hour]:00 local time. */
    private fun millisUntilSunday(hour: Int): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            val daysUntilSunday = (Calendar.SUNDAY - get(Calendar.DAY_OF_WEEK) + 7) % 7
            add(Calendar.DAY_OF_YEAR, daysUntilSunday)
            if (before(now)) add(Calendar.DAY_OF_YEAR, 7)
        }
        return target.timeInMillis - now.timeInMillis
    }
}
