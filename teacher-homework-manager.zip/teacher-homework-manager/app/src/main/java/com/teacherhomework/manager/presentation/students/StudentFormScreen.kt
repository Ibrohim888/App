package com.teacherhomework.manager.presentation.students

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.presentation.components.AppTextField
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.PrimaryButton
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.util.toStringRes

/**
 * Create/edit a student.
 *
 * The class field is free text but offers the teacher's existing class names as
 * one-tap chips — this is what keeps `className` values consistent enough for
 * the homework class picker to work, without forcing a rigid class entity.
 */
@Composable
fun StudentFormScreen(
    onNavigateBack: () -> Unit,
    onSaved: () -> Unit,
    viewModel: StudentFormViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val classNames by viewModel.classNames.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(state.saved) { if (state.saved) onSaved() }

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHostState.showSnackbar(context.getString(it.toStringRes()))
            viewModel.consumeError()
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(
                    if (viewModel.isNew) R.string.title_add_student else R.string.title_edit_student
                ),
                onNavigateBack = onNavigateBack,
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
        ) {
            AppTextField(
                value = state.firstName,
                onValueChange = viewModel::onFirstNameChange,
                label = stringResource(R.string.field_first_name),
                errorText = state.firstNameError?.let { stringResource(it.toStringRes()) },
            )
            Spacer(Modifier.height(14.dp))
            AppTextField(
                value = state.lastName,
                onValueChange = viewModel::onLastNameChange,
                label = stringResource(R.string.field_last_name),
                errorText = state.lastNameError?.let { stringResource(it.toStringRes()) },
            )
            Spacer(Modifier.height(14.dp))
            AppTextField(
                value = state.className,
                onValueChange = viewModel::onClassNameChange,
                label = stringResource(R.string.field_class_name),
            )
            if (classNames.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    classNames.forEach { name ->
                        AssistChip(
                            onClick = { viewModel.onClassNameChange(name) },
                            label = { Text(name) },
                            shape = AppCorner.Chip,
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            AppTextField(
                value = state.phone,
                onValueChange = viewModel::onPhoneChange,
                label = stringResource(R.string.field_phone),
                keyboardType = KeyboardType.Phone,
            )
            Spacer(Modifier.height(14.dp))
            AppTextField(
                value = state.notes,
                onValueChange = viewModel::onNotesChange,
                label = stringResource(R.string.field_notes),
                singleLine = false,
            )
            Spacer(Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.field_active_student),
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    Text(
                        text = stringResource(R.string.field_active_student_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = state.isActive, onCheckedChange = viewModel::onActiveChange)
            }
            Spacer(Modifier.height(28.dp))
            PrimaryButton(
                text = stringResource(R.string.action_save),
                onClick = viewModel::save,
                loading = state.isSaving,
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}
