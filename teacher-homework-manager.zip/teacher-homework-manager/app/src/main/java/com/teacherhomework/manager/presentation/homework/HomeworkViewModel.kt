package com.teacherhomework.manager.presentation.homework

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeworkListUiState(
    val search: String = "",
    val statusFilter: HomeworkStatus? = null,
    val isRefreshing: Boolean = false,
    val error: AppError? = null,
)

private data class HomeworkQuery(val search: String, val status: HomeworkStatus?)

/**
 * Homework list with status filtering and search.
 *
 * By default ARCHIVED assignments are excluded from the "all" view — an archived
 * item is meant to be out of the way, so showing it unfiltered would defeat the
 * purpose of archiving. Selecting the Archived chip shows them explicitly.
 */
@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
@HiltViewModel
class HomeworkViewModel @Inject constructor(
    private val homeworkRepository: HomeworkRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeworkListUiState())
    val uiState: StateFlow<HomeworkListUiState> = _uiState.asStateFlow()

    val homework: StateFlow<List<Homework>> = _uiState
        .map { HomeworkQuery(it.search.trim(), it.statusFilter) }
        .distinctUntilChanged()
        .debounce { if (it.search.isEmpty()) 0L else SEARCH_DEBOUNCE_MS }
        .flatMapLatest { query ->
            homeworkRepository.observeHomework(status = query.status, search = query.search)
                .map { list ->
                    if (query.status == null) {
                        list.filter { it.status != HomeworkStatus.ARCHIVED }
                    } else {
                        list
                    }
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        refresh()
    }

    fun onSearchChange(value: String) = _uiState.update { it.copy(search = value) }

    fun onStatusFilterChange(status: HomeworkStatus?) =
        _uiState.update { it.copy(statusFilter = status) }

    fun refresh() {
        _uiState.update { it.copy(isRefreshing = true) }
        viewModelScope.launch {
            val result = homeworkRepository.refresh()
            _uiState.update {
                it.copy(isRefreshing = false, error = (result as? AppResult.Error)?.error)
            }
        }
    }

    fun consumeError() = _uiState.update { it.copy(error = null) }

    private companion object {
        const val SEARCH_DEBOUNCE_MS = 250L
    }
}
