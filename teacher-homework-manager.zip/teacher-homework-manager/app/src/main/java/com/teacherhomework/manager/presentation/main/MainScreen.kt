package com.teacherhomework.manager.presentation.main

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.teacherhomework.manager.presentation.calendar.CalendarScreen
import com.teacherhomework.manager.presentation.dashboard.DashboardScreen
import com.teacherhomework.manager.presentation.homework.HomeworkScreen
import com.teacherhomework.manager.presentation.navigation.BottomNavDestination
import com.teacherhomework.manager.presentation.statistics.StatisticsScreen
import com.teacherhomework.manager.presentation.students.StudentsScreen

/**
 * The signed-in shell: a bottom navigation bar over the 5 top-level
 * destinations, each of which owns its own TopAppBar (so each can carry the
 * overflow actions that actually make sense for it, rather than one generic menu).
 *
 * Navigation OUT of the shell (detail screens, settings, reports) is delegated
 * upward through the callbacks, so the outer NavHost owns those routes and Back
 * from a detail screen returns to the correct tab with its state intact.
 */
@Composable
fun MainScreen(
    onOpenStudent: (String) -> Unit,
    onAddStudent: () -> Unit,
    onOpenHomework: (String) -> Unit,
    onAddHomework: () -> Unit,
    onStartChecking: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenReports: () -> Unit,
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val currentDestination = BottomNavDestination.entries
        .firstOrNull { it.route == currentRoute } ?: BottomNavDestination.START

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                BottomNavDestination.entries.forEach { destination ->
                    val selected = currentDestination == destination
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(destination.route) {
                                // Standard bottom-nav behavior: one top-level
                                // back stack, state restored per tab, no dupes.
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(destination.icon, contentDescription = null) },
                        label = { Text(stringResource(destination.labelRes)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                            indicatorColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                        ),
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = BottomNavDestination.START.route,
            modifier = Modifier.padding(padding),
        ) {
            composable(BottomNavDestination.DASHBOARD.route) {
                DashboardScreen(
                    onOpenHomework = onOpenHomework,
                    onStartChecking = onStartChecking,
                    onOpenSettings = onOpenSettings,
                    onOpenNotifications = onOpenNotifications,
                )
            }
            composable(BottomNavDestination.STUDENTS.route) {
                StudentsScreen(
                    onOpenStudent = onOpenStudent,
                    onAddStudent = onAddStudent,
                    onOpenSettings = onOpenSettings,
                )
            }
            composable(BottomNavDestination.HOMEWORK.route) {
                HomeworkScreen(
                    onOpenHomework = onOpenHomework,
                    onAddHomework = onAddHomework,
                    onOpenSettings = onOpenSettings,
                )
            }
            composable(BottomNavDestination.CALENDAR.route) {
                CalendarScreen(
                    onOpenHomework = onOpenHomework,
                    onOpenSettings = onOpenSettings,
                )
            }
            composable(BottomNavDestination.STATISTICS.route) {
                StatisticsScreen(
                    onOpenReports = onOpenReports,
                    onOpenSettings = onOpenSettings,
                )
            }
        }
    }
}
