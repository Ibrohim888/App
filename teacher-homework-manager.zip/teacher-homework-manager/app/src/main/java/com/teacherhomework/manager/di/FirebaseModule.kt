package com.teacherhomework.manager.di

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.firestoreSettings
import com.google.firebase.firestore.ktx.persistentCacheSettings
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Provides the Firebase service singletons used across the app.
 *
 * All three are Spark-free-plan services (Auth, Firestore, Storage). Cloud
 * Functions and Cloud Messaging are intentionally absent and permanently out of
 * scope (FREE-TIER POLICY). Repositories in later phases inject these.
 */
@Module
@InstallIn(SingletonComponent::class)
object FirebaseModule {

    @Provides
    @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = Firebase.auth

    /**
     * Firestore with an explicitly-sized offline cache.
     *
     * Local persistence is on by default on Android, but the size is pinned here
     * so a teacher with a season of homework never silently evicts cached data
     * mid-lesson. 100 MB is far more than this data model needs (text documents
     * only — attachments live in Storage) while staying modest on device.
     */
    @Provides
    @Singleton
    fun provideFirebaseFirestore(): FirebaseFirestore = Firebase.firestore.apply {
        firestoreSettings = firestoreSettings {
            setLocalCacheSettings(
                persistentCacheSettings {
                    setSizeBytes(100L * 1024 * 1024)
                }
            )
        }
    }

    @Provides
    @Singleton
    fun provideFirebaseStorage(): FirebaseStorage = Firebase.storage
}
