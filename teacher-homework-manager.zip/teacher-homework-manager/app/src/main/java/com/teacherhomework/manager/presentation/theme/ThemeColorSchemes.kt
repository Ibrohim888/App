package com.teacherhomework.manager.presentation.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.teacherhomework.manager.domain.model.AppThemeColor

/**
 * Builds the Material 3 [ColorScheme] for a given accent + mode, plus the
 * matching header [AccentGradient]. There are 5 accents x 2 modes = 10 schemes,
 * all sharing the warm neutral background/surface tokens and differing only in
 * the accent hue family.
 *
 * @param primary the accent's main color (used for buttons, active states)
 * @param primaryDark a lighter accent tone that reads correctly on dark surfaces
 * @param gradientEnd the lighter end of the header gradient (also used as the
 *        light-mode primaryContainer tint so containers stay in-family)
 */
private fun lightScheme(primary: Color, gradientEnd: Color) = lightColorScheme(
    primary = primary,
    onPrimary = White,
    primaryContainer = gradientEnd,
    onPrimaryContainer = White,
    secondary = gradientEnd,
    onSecondary = White,
    secondaryContainer = gradientEnd.copy(alpha = 0.18f).compositeOverWhite(),
    onSecondaryContainer = OnBackgroundLight,
    tertiary = primary,
    background = WarmBackgroundLight,
    onBackground = OnBackgroundLight,
    surface = SurfaceLight,
    onSurface = OnBackgroundLight,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = OnSurfaceVariantLight,
    outline = OutlineLight,
    outlineVariant = OutlineLight,
    error = StatusMissingText,
    onError = White,
    errorContainer = StatusMissingBg,
    onErrorContainer = StatusMissingText,
)

private fun darkScheme(primaryDark: Color, gradientEnd: Color) = darkColorScheme(
    primary = primaryDark,
    onPrimary = Color(0xFF102019),
    primaryContainer = primaryDark.copy(alpha = 0.24f).compositeOverDark(),
    onPrimaryContainer = White,
    secondary = gradientEnd,
    onSecondary = Color(0xFF102019),
    secondaryContainer = gradientEnd.copy(alpha = 0.22f).compositeOverDark(),
    onSecondaryContainer = OnBackgroundDark,
    tertiary = primaryDark,
    background = WarmBackgroundDark,
    onBackground = OnBackgroundDark,
    surface = SurfaceDark,
    onSurface = OnBackgroundDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = OnSurfaceVariantDark,
    outline = OutlineDark,
    outlineVariant = OutlineDark,
    error = StatusMissingTextDark,
    onError = Color(0xFF201010),
    errorContainer = StatusMissingBgDark,
    onErrorContainer = StatusMissingTextDark,
)

/** Everything a screen needs to render in a given accent + mode. */
data class ResolvedTheme(
    val colorScheme: ColorScheme,
    val gradient: AccentGradient,
    val statusColors: StatusColors,
)

/**
 * Resolves the concrete scheme/gradient/status set for an accent + dark flag.
 * This is the single source of truth mapping [AppThemeColor] -> visuals.
 */
fun resolveTheme(theme: AppThemeColor, darkTheme: Boolean): ResolvedTheme {
    val (primary, gradientEnd, primaryDark) = when (theme) {
        AppThemeColor.FOREST_GREEN -> Triple(ForestPrimary, ForestGradientEnd, ForestPrimaryDark)
        AppThemeColor.TRUST_BLUE -> Triple(BluePrimary, BlueGradientEnd, BluePrimaryDark)
        AppThemeColor.VIOLET -> Triple(VioletPrimary, VioletGradientEnd, VioletPrimaryDark)
        AppThemeColor.WARM_ROSE -> Triple(RosePrimary, RoseGradientEnd, RosePrimaryDark)
        AppThemeColor.TEAL -> Triple(TealPrimary, TealGradientEnd, TealPrimaryDark)
    }
    return ResolvedTheme(
        colorScheme = if (darkTheme) darkScheme(primaryDark, gradientEnd)
        else lightScheme(primary, gradientEnd),
        gradient = if (darkTheme) AccentGradient(primaryDark, gradientEnd)
        else AccentGradient(primary, gradientEnd),
        statusColors = if (darkTheme) DarkStatusColors else LightStatusColors,
    )
}

// --- Small compositing helpers so tinted containers stay opaque (ColorScheme
// slots must be opaque colors, not alpha-blended ones). ---
private fun Color.compositeOverWhite(): Color = compositeOver(White)
private fun Color.compositeOverDark(): Color = compositeOver(SurfaceDark)

private fun Color.compositeOver(bg: Color): Color {
    val a = alpha
    return Color(
        red = red * a + bg.red * (1 - a),
        green = green * a + bg.green * (1 - a),
        blue = blue * a + bg.blue * (1 - a),
        alpha = 1f,
    )
}
