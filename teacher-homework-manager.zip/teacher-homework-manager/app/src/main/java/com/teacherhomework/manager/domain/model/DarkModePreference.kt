package com.teacherhomework.manager.domain.model

/**
 * The teacher's dark-mode choice. SYSTEM follows the device setting; LIGHT/DARK
 * force a mode. Orthogonal to [AppThemeColor] per THEME COLOR POLICY — any accent
 * pairs with any mode. Persisted as [token].
 */
enum class DarkModePreference(val token: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark");

    /** Resolves to a concrete dark flag, or null for "follow system". */
    fun toDarkFlag(): Boolean? = when (this) {
        SYSTEM -> null
        LIGHT -> false
        DARK -> true
    }

    companion object {
        val DEFAULT = SYSTEM
        fun fromToken(token: String?): DarkModePreference =
            entries.firstOrNull { it.token == token } ?: DEFAULT
    }
}
