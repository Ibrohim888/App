package com.teacherhomework.manager.presentation.statistics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.GradeType
import com.teacherhomework.manager.domain.model.StatisticsSummary
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.repository.StatisticsRepository
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.presentation.components.BarEntry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Aggregate counts across all recorded results, for the distribution row. */
data class StatusDistribution(
    val completed: Int = 0,
    val partial: Int = 0,
    val missing: Int = 0,
) {
    val total: Int get() = completed + partial + missing
}

/** Per-class comparison row. */
data class ClassStat(
    val className: String,
    val studentCount: Int,
    val averageGrade: Double,
    val completionRate: Double,
)

data class StatisticsUiState(val isRecalculating: Boolean = false)

/**
 * Statistics screen state: the stored summary plus a few views derived live from
 * the cached results (status distribution, per-class comparison).
 *
 * The stored summary comes from the transactional recalculation; the derived
 * views are computed here from Room so they stay correct even between recalcs.
 */
@HiltViewModel
class StatisticsViewModel @Inject constructor(
    private val statisticsRepository: StatisticsRepository,
    private val resultRepository: ResultRepository,
    studentRepository: StudentRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(StatisticsUiState())
    val uiState: StateFlow<StatisticsUiState> = _uiState.asStateFlow()

    val summary: StateFlow<StatisticsSummary> = statisticsRepository.observeSummary()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatisticsSummary())

    val distribution: StateFlow<StatusDistribution> = resultRepository.observeAllResults()
        .map { results ->
            StatusDistribution(
                completed = results.count { it.completionStatus == CompletionStatus.COMPLETED },
                partial = results.count { it.completionStatus == CompletionStatus.PARTIAL },
                missing = results.count { it.completionStatus == CompletionStatus.MISSING },
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatusDistribution())

    /** Last 6 months of average grade, oldest first — the trend chart's data. */
    val monthlyTrend: StateFlow<List<BarEntry>> = summary
        .map { s ->
            s.monthlyProgress.entries
                .sortedBy { it.key }
                .takeLast(TREND_BUCKETS)
                // "2026-03" → "03": the year is implied by the range and would
                // not fit under a narrow bar.
                .map { BarEntry(label = it.key.takeLast(2), value = it.value) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Last 8 weeks of average grade. */
    val weeklyTrend: StateFlow<List<BarEntry>> = summary
        .map { s ->
            s.weeklyProgress.entries
                .sortedBy { it.key }
                .takeLast(WEEKLY_BUCKETS)
                .map { BarEntry(label = it.key.substringAfter("W"), value = it.value) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /**
     * Per-class averages. Joins students to results in memory — both are already
     * cached, so this comparison costs no extra reads.
     */
    val classStats: StateFlow<List<ClassStat>> = combine(
        studentRepository.observeStudents(),
        resultRepository.observeAllResults(),
    ) { students, results ->
        val resultsByStudent = results.groupBy { it.studentId }
        students
            .filter { !it.className.isNullOrBlank() }
            .groupBy { it.className!! }
            .map { (className, classStudents) ->
                val classResults = classStudents.flatMap { resultsByStudent[it.id].orEmpty() }
                val graded = classResults.mapNotNull { r ->
                    r.grade?.let { if (r.gradeType == GradeType.POINT_10) it * 10.0 else it }
                }
                val score = classResults.sumOf {
                    when (it.completionStatus) {
                        CompletionStatus.COMPLETED -> 1.0
                        CompletionStatus.PARTIAL -> 0.5
                        CompletionStatus.MISSING -> 0.0
                    }
                }
                ClassStat(
                    className = className,
                    studentCount = classStudents.size,
                    averageGrade = if (graded.isEmpty()) 0.0 else graded.average(),
                    completionRate = if (classResults.isEmpty()) 0.0
                    else (score / classResults.size) * 100.0,
                )
            }
            .sortedByDescending { it.averageGrade }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Forces a fresh transactional recalculation from the results collection. */
    fun recalculate() {
        _uiState.update { it.copy(isRecalculating = true) }
        viewModelScope.launch {
            statisticsRepository.recalculateAndCommit()
            _uiState.update { it.copy(isRecalculating = false) }
        }
    }

    private companion object {
        const val TREND_BUCKETS = 6
        const val WEEKLY_BUCKETS = 8
    }
}
