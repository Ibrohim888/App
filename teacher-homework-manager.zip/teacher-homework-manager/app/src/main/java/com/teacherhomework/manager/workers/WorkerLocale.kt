package com.teacherhomework.manager.workers

import android.content.Context
import android.content.res.Configuration
import com.teacherhomework.manager.data.preferences.AppPreferences
import kotlinx.coroutines.flow.first
import java.util.Locale

/**
 * Resolves a [Context] whose resources render in the TEACHER's chosen app
 * language rather than the device's system language.
 *
 * This matters specifically for notifications: a worker runs outside any
 * Activity, so `applicationContext.getString()` would use the system locale. The
 * localization policy requires notification text to follow the teacher's app
 * language choice at the moment the notification is posted, which is exactly
 * what this provides.
 */
object WorkerLocale {

    suspend fun localizedContext(base: Context, preferences: AppPreferences): Context {
        val tag = preferences.settingsSnapshot.first().language
        val locale = Locale.forLanguageTag(tag)
        val config = Configuration(base.resources.configuration).apply { setLocale(locale) }
        return base.createConfigurationContext(config)
    }
}
