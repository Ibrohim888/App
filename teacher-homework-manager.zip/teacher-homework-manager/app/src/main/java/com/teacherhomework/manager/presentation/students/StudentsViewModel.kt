package com.teacherhomework.manager.presentation.students

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.model.Student
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class StudentsUiState(
    val search: String = "",
    val selectedClass: String? = null,
    val showInactive: Boolean = false,
    val isRefreshing: Boolean = false,
    val error: AppError? = null,
)

/** The subset of UI state that actually affects the roster query. */
private data class RosterQuery(
    val search: String,
    val className: String?,
    val showInactive: Boolean,
)

/**
 * Roster list: search, class filter, and delete actions.
 *
 * The query key is projected out of the full UI state first, so changing an
 * unrelated field (isRefreshing, error) never re-runs the query. Typing is then
 * DEBOUNCED by 250ms — without it every keystroke would re-run the Room query
 * and rebuild the list, which is visible jank on a long roster and pointless
 * work while the teacher is still typing. `flatMapLatest` cancels the in-flight
 * query as soon as a newer term arrives.
 */
@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
@HiltViewModel
class StudentsViewModel @Inject constructor(
    private val studentRepository: StudentRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(StudentsUiState())
    val uiState: StateFlow<StudentsUiState> = _uiState.asStateFlow()

    /** Class names for the filter chips, derived live from the roster itself. */
    val classNames: StateFlow<List<String>> = studentRepository.observeClassNames()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val students: StateFlow<List<Student>> = _uiState
        .map { RosterQuery(it.search.trim(), it.selectedClass, it.showInactive) }
        .distinctUntilChanged()
        .debounce { query -> if (query.search.isEmpty()) 0L else SEARCH_DEBOUNCE_MS }
        .flatMapLatest { query ->
            studentRepository.observeStudents(
                search = query.search,
                className = query.className,
                activeOnly = !query.showInactive,
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        // Pull once on open so a fresh install / second device fills the cache.
        refresh()
    }

    fun onSearchChange(value: String) = _uiState.update { it.copy(search = value) }

    fun onClassFilterChange(className: String?) =
        _uiState.update { it.copy(selectedClass = className) }

    fun onShowInactiveChange(show: Boolean) = _uiState.update { it.copy(showInactive = show) }

    fun refresh() {
        _uiState.update { it.copy(isRefreshing = true) }
        viewModelScope.launch {
            val result = studentRepository.refresh()
            _uiState.update {
                it.copy(isRefreshing = false, error = (result as? AppResult.Error)?.error)
            }
        }
    }

    /** Hides the student but keeps every grade they earned. */
    fun archiveStudent(studentId: String) = viewModelScope.launch {
        val result = studentRepository.softDeleteStudent(studentId)
        _uiState.update { it.copy(error = (result as? AppResult.Error)?.error) }
    }

    /** Irreversible: removes the student and all of their results. */
    fun deleteStudentPermanently(studentId: String) = viewModelScope.launch {
        val result = studentRepository.hardDeleteStudent(studentId)
        _uiState.update { it.copy(error = (result as? AppResult.Error)?.error) }
    }

    fun consumeError() = _uiState.update { it.copy(error = null) }

    private companion object {
        const val SEARCH_DEBOUNCE_MS = 250L
    }
}
