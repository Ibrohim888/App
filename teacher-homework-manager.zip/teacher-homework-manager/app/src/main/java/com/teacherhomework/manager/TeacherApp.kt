package com.teacherhomework.manager

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.notifications.NotificationHelper
import com.teacherhomework.manager.workers.ReminderScheduler
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Application entry point.
 *
 * Implements [Configuration.Provider] so WorkManager uses Hilt's
 * [HiltWorkerFactory] — without it, the `@HiltWorker` reminder workers can't have
 * their repositories injected and would fail to instantiate at runtime.
 *
 * On start it also (a) creates the notification channels and (b) re-syncs the
 * reminder schedule from the teacher's stored preferences, which is what
 * restores reminders after a reboot or an app update clears them.
 */
@HiltAndroidApp
class TeacherApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var notificationHelper: NotificationHelper
    @Inject lateinit var reminderScheduler: ReminderScheduler
    @Inject lateinit var appPreferences: AppPreferences

    /** App-lifetime scope for the one-shot startup work below. */
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        notificationHelper.createChannels()

        appScope.launch {
            // Re-applies whatever the teacher had enabled. Periodic work is
            // enqueued with KEEP, so this never resets an existing schedule.
            val settings = appPreferences.notificationSettings.first()
            reminderScheduler.sync(settings)
        }
    }
}
