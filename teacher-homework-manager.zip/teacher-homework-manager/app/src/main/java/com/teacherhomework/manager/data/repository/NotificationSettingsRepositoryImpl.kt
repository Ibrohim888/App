package com.teacherhomework.manager.data.repository

import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.data.remote.NotificationSettingsRemoteDataSource
import com.teacherhomework.manager.domain.model.NotificationSettings
import com.teacherhomework.manager.domain.repository.NotificationSettingsRepository
import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Reminder preferences for the LOCAL notification system (WorkManager +
 * NotificationCompat). There are deliberately no push/FCM fields anywhere in
 * this type — cross-device push is permanently out of scope.
 *
 * DataStore is the read source because the WorkManager workers need these values
 * on a background thread with no network guarantee; Firestore is a backup mirror
 * so the teacher's choices survive a reinstall.
 */
@Singleton
class NotificationSettingsRepositoryImpl @Inject constructor(
    private val preferences: AppPreferences,
    private val remote: NotificationSettingsRemoteDataSource,
    private val session: SessionProvider,
) : NotificationSettingsRepository {

    override fun observe(): Flow<NotificationSettings> = preferences.notificationSettings

    override suspend fun update(settings: NotificationSettings): AppResult<Unit> {
        preferences.setNotificationSettings(settings)
        return runCatchingRepo { remote.update(session.requireTeacherId(), settings) }
    }
}
