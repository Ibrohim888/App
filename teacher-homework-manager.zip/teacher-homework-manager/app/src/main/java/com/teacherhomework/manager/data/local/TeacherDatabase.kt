package com.teacherhomework.manager.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.teacherhomework.manager.data.local.dao.HomeworkDao
import com.teacherhomework.manager.data.local.dao.NotificationDao
import com.teacherhomework.manager.data.local.dao.ResultDao
import com.teacherhomework.manager.data.local.dao.StatisticsDao
import com.teacherhomework.manager.data.local.dao.StudentDao
import com.teacherhomework.manager.data.local.entity.HomeworkEntity
import com.teacherhomework.manager.data.local.entity.NotificationEntity
import com.teacherhomework.manager.data.local.entity.ResultEntity
import com.teacherhomework.manager.data.local.entity.StatisticsEntity
import com.teacherhomework.manager.data.local.entity.StudentEntity

/**
 * The offline cache. All UI reads flow from here (Room is the source of truth),
 * so the app works fully offline; Firestore is reconciled in the background.
 * Enum/timestamp fields are stored as primitives, so no TypeConverters are
 * needed. Bump the version and add a migration when the schema changes.
 */
@Database(
    entities = [
        StudentEntity::class,
        HomeworkEntity::class,
        ResultEntity::class,
        StatisticsEntity::class,
        NotificationEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class TeacherDatabase : RoomDatabase() {
    abstract fun studentDao(): StudentDao
    abstract fun homeworkDao(): HomeworkDao
    abstract fun resultDao(): ResultDao
    abstract fun statisticsDao(): StatisticsDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        const val NAME = "teacher_homework.db"
    }
}
