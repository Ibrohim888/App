package com.teacherhomework.manager.presentation.checking

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.GradeType
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.Result
import com.teacherhomework.manager.domain.model.Student
import com.teacherhomework.manager.domain.model.SyncState
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.domain.usecase.ValidateGradeUseCase
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import com.teacherhomework.manager.presentation.navigation.NavRoutes
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

/** One student's row on the checking screen: the student and their result so far. */
data class CheckingRow(
    val student: Student,
    val result: Result?,
) {
    val status: CompletionStatus? get() = result?.completionStatus
    val grade: Double? get() = result?.grade
    val isChecked: Boolean get() = result != null
}

data class CheckingUiState(
    val gradeType: GradeType = GradeType.PERCENT,
    val fastMode: Boolean = true,
    val savingStudentIds: Set<String> = emptySet(),
    val error: AppError? = null,
)

/**
 * Grading screen for one homework — the app's hottest interaction.
 *
 * FAST CHECKING MODE: tapping a status writes immediately, with no Save step.
 * Each write goes to Room first so the toggle flips instantly (well under the
 * 100ms perceptual threshold) even with no connection; the Firestore push and
 * the statistics recalculation happen after, off the interaction path.
 *
 * The student list is scoped to the homework's `className`, which is why that
 * field is required on every assignment — it is what makes "check this class"
 * a bounded, one-screen operation rather than a scroll through the whole roster.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class CheckingViewModel @Inject constructor(
    private val resultRepository: ResultRepository,
    private val validateGrade: ValidateGradeUseCase,
    homeworkRepository: HomeworkRepository,
    studentRepository: StudentRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val homeworkId: String = savedStateHandle[NavRoutes.ARG_HOMEWORK_ID] ?: ""

    private val _uiState = MutableStateFlow(CheckingUiState())
    val uiState: StateFlow<CheckingUiState> = _uiState.asStateFlow()

    val homework: StateFlow<Homework?> = homeworkRepository.observeHomeworkById(homeworkId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /**
     * Students in this homework's class, joined to any result already recorded.
     * `flatMapLatest` re-scopes the roster if the assignment's class is edited
     * while the screen is open.
     */
    val rows: StateFlow<List<CheckingRow>> = homework
        .flatMapLatest { hw ->
            if (hw == null) {
                kotlinx.coroutines.flow.flowOf(emptyList())
            } else {
                combine(
                    studentRepository.observeStudents(className = hw.className, activeOnly = true),
                    resultRepository.observeResultsForHomework(homeworkId),
                ) { students, results ->
                    val byStudent = results.associateBy { it.studentId }
                    students.map { CheckingRow(it, byStudent[it.id]) }
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setGradeType(type: GradeType) = _uiState.update { it.copy(gradeType = type) }

    fun setFastMode(enabled: Boolean) = _uiState.update { it.copy(fastMode = enabled) }

    /**
     * Records (or updates) a status for one student. Grade and comment are
     * preserved when only the status changes, so switching COMPLETED → PARTIAL
     * doesn't silently wipe a grade the teacher already typed.
     */
    fun setStatus(studentId: String, status: CompletionStatus) {
        val existing = rows.value.firstOrNull { it.student.id == studentId }?.result
        saveResult(
            studentId = studentId,
            status = status,
            grade = existing?.grade,
            comment = existing?.comment,
        )
    }

    /**
     * Records a grade. Validation runs through the single domain use case (the
     * same one the security rules mirror server-side); an out-of-range value is
     * rejected here rather than written and rejected later.
     */
    fun setGrade(studentId: String, gradeText: String) {
        val row = rows.value.firstOrNull { it.student.id == studentId }
        val gradeType = _uiState.value.gradeType
        val grade = gradeText.trim().toDoubleOrNull()

        if (gradeText.isNotBlank() && grade == null) {
            _uiState.update { it.copy(error = AppError.GRADE_OUT_OF_RANGE) }
            return
        }
        if (!validateGrade.isValid(grade, gradeType)) {
            _uiState.update { it.copy(error = AppError.GRADE_OUT_OF_RANGE) }
            return
        }

        saveResult(
            studentId = studentId,
            // A grade entered before any status implies the work was done.
            status = row?.status ?: CompletionStatus.COMPLETED,
            grade = grade,
            comment = row?.result?.comment,
        )
    }

    fun setComment(studentId: String, comment: String) {
        val row = rows.value.firstOrNull { it.student.id == studentId }
        saveResult(
            studentId = studentId,
            status = row?.status ?: CompletionStatus.COMPLETED,
            grade = row?.grade,
            comment = comment.trim().ifBlank { null },
        )
    }

    /**
     * Marks every not-yet-checked student in the class with one status. Used for
     * "everyone did it, except…" flows, which is how most classes actually get
     * checked. Already-recorded students are left alone so this can never
     * silently overwrite a deliberate entry.
     */
    fun markAllUnchecked(status: CompletionStatus) = viewModelScope.launch {
        rows.value.filter { !it.isChecked }.forEach { row ->
            saveResultSuspending(row.student.id, status, grade = null, comment = null)
        }
    }

    private fun saveResult(
        studentId: String,
        status: CompletionStatus,
        grade: Double?,
        comment: String?,
    ) = viewModelScope.launch {
        saveResultSuspending(studentId, status, grade, comment)
    }

    private suspend fun saveResultSuspending(
        studentId: String,
        status: CompletionStatus,
        grade: Double?,
        comment: String?,
    ) {
        val existing = rows.value.firstOrNull { it.student.id == studentId }?.result
        _uiState.update { it.copy(savingStudentIds = it.savingStudentIds + studentId) }

        val result = Result(
            // Reuse the existing document id so re-checking a student updates
            // their row instead of creating a duplicate result.
            id = existing?.id ?: UUID.randomUUID().toString(),
            studentId = studentId,
            homeworkId = homeworkId,
            completionStatus = status,
            grade = grade,
            gradeType = _uiState.value.gradeType,
            comment = comment,
            checkedDate = System.currentTimeMillis(),
            checkedBy = CHECKED_BY_TEACHER,
            syncState = SyncState.PENDING,
        )

        val outcome = resultRepository.upsertResult(result)
        _uiState.update {
            it.copy(
                savingStudentIds = it.savingStudentIds - studentId,
                error = (outcome as? AppResult.Error)?.error,
            )
        }
    }

    fun consumeError() = _uiState.update { it.copy(error = null) }

    private companion object {
        /**
         * Single-teacher app: every result is recorded by the account owner. The
         * field exists in the data model for future multi-teacher support.
         */
        const val CHECKED_BY_TEACHER = "teacher"
    }
}
