package com.teacherhomework.manager.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.teacherhomework.manager.domain.model.AppLanguage
import com.teacherhomework.manager.domain.model.AppThemeColor
import com.teacherhomework.manager.domain.model.DarkModePreference
import com.teacherhomework.manager.domain.model.NotificationSettings
import com.teacherhomework.manager.domain.model.TeacherSettings
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/** Single DataStore instance for the process, scoped to the app Context. */
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "teacher_prefs")

/**
 * Local (on-device) persistence of the teacher's onboarding choices: chosen
 * language, accent theme, and dark-mode preference.
 *
 * Language and theme are stored here the moment they're chosen on the
 * first-launch selection screens, so every screen afterward renders correctly
 * with no network round-trip. Whether each has been chosen yet is represented
 * by the key being absent (null) — that's what the launch router uses to decide
 * whether to show the selection screens (Phase 1 DoD: skip them on relaunch).
 *
 * In Phase 2 these same values are additionally mirrored to Firestore
 * (`teachers/{teacherId}.settings`) once an account exists; this class remains
 * the fast, offline-first local source.
 */
@Singleton
class AppPreferences @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val THEME_COLOR = stringPreferencesKey("theme_color")
        val DARK_MODE = stringPreferencesKey("dark_mode")

        // Local reminder preferences (WorkManager). No push/FCM keys — out of scope.
        val REMINDERS_ENABLED = booleanPreferencesKey("reminders_enabled")
        val DEADLINE_REMINDERS = booleanPreferencesKey("deadline_reminders")
        val MISSING_ALERTS = booleanPreferencesKey("missing_homework_alerts")
        val WEEKLY_SUMMARIES = booleanPreferencesKey("weekly_report_summaries")

        /** Last time a full Firestore→Room sync completed (epoch millis). */
        val LAST_SYNC_AT = longPreferencesKey("last_sync_at")
        /** Cumulative bytes uploaded to Storage by this teacher (quota warning). */
        val STORAGE_BYTES_USED = longPreferencesKey("storage_bytes_used")
    }

    /** null until the teacher picks a language on the first-launch screen. */
    val language: Flow<AppLanguage?> = context.dataStore.data.map { prefs ->
        prefs[Keys.LANGUAGE]?.let { AppLanguage.fromTag(it) }
    }

    /** null until the teacher picks an accent on the first-launch screen. */
    val themeColor: Flow<AppThemeColor?> = context.dataStore.data.map { prefs ->
        prefs[Keys.THEME_COLOR]?.let { AppThemeColor.fromId(it) }
    }

    /** Defaults to SYSTEM until explicitly changed in Settings (Phase 2). */
    val darkModePreference: Flow<DarkModePreference> = context.dataStore.data.map { prefs ->
        DarkModePreference.fromToken(prefs[Keys.DARK_MODE])
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.tag }
    }

    suspend fun setThemeColor(themeColor: AppThemeColor) {
        context.dataStore.edit { it[Keys.THEME_COLOR] = themeColor.id }
    }

    suspend fun setDarkModePreference(pref: DarkModePreference) {
        context.dataStore.edit { it[Keys.DARK_MODE] = pref.token }
    }

    /**
     * Applies a whole [TeacherSettings] map at once — used when settings arrive
     * from Firestore after logging in on a new device, so the local store adopts
     * the account's stored language/theme in a single atomic edit rather than
     * three separate ones (which would cause three recompositions).
     */
    suspend fun setSettingsSnapshot(settings: TeacherSettings) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LANGUAGE] = settings.language
            prefs[Keys.THEME_COLOR] = settings.themeColor
            prefs[Keys.DARK_MODE] =
                if (settings.darkMode) DarkModePreference.DARK.token else DarkModePreference.LIGHT.token
        }
    }

    /** Current settings as the Firestore-shaped map (for mirroring upward). */
    val settingsSnapshot: Flow<TeacherSettings> = context.dataStore.data.map { prefs ->
        TeacherSettings(
            language = prefs[Keys.LANGUAGE] ?: AppLanguage.DEFAULT.tag,
            themeColor = prefs[Keys.THEME_COLOR] ?: AppThemeColor.DEFAULT.id,
            darkMode = DarkModePreference.fromToken(prefs[Keys.DARK_MODE]) == DarkModePreference.DARK,
        )
    }

    // ---------- Local reminder preferences ----------

    val notificationSettings: Flow<NotificationSettings> = context.dataStore.data.map { prefs ->
        NotificationSettings(
            localRemindersEnabled = prefs[Keys.REMINDERS_ENABLED] ?: true,
            deadlineReminders = prefs[Keys.DEADLINE_REMINDERS] ?: true,
            missingHomeworkAlerts = prefs[Keys.MISSING_ALERTS] ?: true,
            weeklyReportSummaries = prefs[Keys.WEEKLY_SUMMARIES] ?: true,
        )
    }

    suspend fun setNotificationSettings(settings: NotificationSettings) {
        context.dataStore.edit { prefs ->
            prefs[Keys.REMINDERS_ENABLED] = settings.localRemindersEnabled
            prefs[Keys.DEADLINE_REMINDERS] = settings.deadlineReminders
            prefs[Keys.MISSING_ALERTS] = settings.missingHomeworkAlerts
            prefs[Keys.WEEKLY_SUMMARIES] = settings.weeklyReportSummaries
        }
    }

    // ---------- Sync + storage bookkeeping ----------

    val lastSyncAt: Flow<Long> = context.dataStore.data.map { it[Keys.LAST_SYNC_AT] ?: 0L }

    suspend fun setLastSyncAt(epochMillis: Long) {
        context.dataStore.edit { it[Keys.LAST_SYNC_AT] = epochMillis }
    }

    /**
     * Running total of bytes this teacher has uploaded, used to warn at 80% of
     * their share of the 5 GB free Storage quota (FILE UPLOAD CONSTRAINTS).
     */
    val storageBytesUsed: Flow<Long> = context.dataStore.data.map { it[Keys.STORAGE_BYTES_USED] ?: 0L }

    suspend fun addStorageBytesUsed(delta: Long) {
        context.dataStore.edit { prefs ->
            prefs[Keys.STORAGE_BYTES_USED] = ((prefs[Keys.STORAGE_BYTES_USED] ?: 0L) + delta).coerceAtLeast(0L)
        }
    }
}
