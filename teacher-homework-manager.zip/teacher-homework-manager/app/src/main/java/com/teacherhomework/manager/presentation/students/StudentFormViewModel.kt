package com.teacherhomework.manager.presentation.students

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.model.Student
import com.teacherhomework.manager.domain.model.SyncState
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import com.teacherhomework.manager.presentation.navigation.NavRoutes
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class StudentFormUiState(
    val firstName: String = "",
    val lastName: String = "",
    val className: String = "",
    val phone: String = "",
    val notes: String = "",
    val isActive: Boolean = true,
    val firstNameError: AppError? = null,
    val lastNameError: AppError? = null,
    val isSaving: Boolean = false,
    val isLoaded: Boolean = false,
    val saved: Boolean = false,
    val error: AppError? = null,
)

/**
 * Create/edit form for a student.
 *
 * The route carries `studentId`; the sentinel [NavRoutes.NEW] means create mode.
 * In edit mode the existing record is loaded once into the form fields — the
 * fields are then plain local state, so typing doesn't write to the database on
 * every keystroke.
 */
@HiltViewModel
class StudentFormViewModel @Inject constructor(
    private val studentRepository: StudentRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val studentId: String = savedStateHandle[NavRoutes.ARG_STUDENT_ID] ?: NavRoutes.NEW
    val isNew: Boolean = studentId == NavRoutes.NEW

    private val _uiState = MutableStateFlow(StudentFormUiState())
    val uiState: StateFlow<StudentFormUiState> = _uiState.asStateFlow()

    /** Existing class names, offered as suggestions so spelling stays consistent. */
    val classNames: StateFlow<List<String>> = studentRepository.observeClassNames()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Preserved so an edit doesn't reset createdAt. */
    private var loadedCreatedAt: Long = 0L

    init {
        if (!isNew) {
            viewModelScope.launch {
                studentRepository.getStudent(studentId)?.let { student ->
                    loadedCreatedAt = student.createdAt
                    _uiState.update {
                        it.copy(
                            firstName = student.firstName,
                            lastName = student.lastName,
                            className = student.className.orEmpty(),
                            phone = student.phone.orEmpty(),
                            notes = student.notes.orEmpty(),
                            isActive = student.isActive,
                            isLoaded = true,
                        )
                    }
                }
            }
        } else {
            _uiState.update { it.copy(isLoaded = true) }
        }
    }

    fun onFirstNameChange(v: String) = _uiState.update { it.copy(firstName = v, firstNameError = null) }
    fun onLastNameChange(v: String) = _uiState.update { it.copy(lastName = v, lastNameError = null) }
    fun onClassNameChange(v: String) = _uiState.update { it.copy(className = v) }
    fun onPhoneChange(v: String) = _uiState.update { it.copy(phone = v) }
    fun onNotesChange(v: String) = _uiState.update { it.copy(notes = v) }
    fun onActiveChange(v: Boolean) = _uiState.update { it.copy(isActive = v) }

    fun save() {
        val s = _uiState.value
        val firstError = if (s.firstName.isBlank()) AppError.EMPTY_FIELD else null
        val lastError = if (s.lastName.isBlank()) AppError.EMPTY_FIELD else null
        if (firstError != null || lastError != null) {
            _uiState.update { it.copy(firstNameError = firstError, lastNameError = lastError) }
            return
        }

        _uiState.update { it.copy(isSaving = true) }
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val student = Student(
                // A client-generated UUID lets a student be created fully offline
                // and keeps the Room row and Firestore document on the same id.
                id = if (isNew) UUID.randomUUID().toString() else studentId,
                firstName = s.firstName.trim(),
                lastName = s.lastName.trim(),
                // Denormalized so list queries can sort/search on one field.
                fullName = "${s.firstName.trim()} ${s.lastName.trim()}",
                className = s.className.trim().ifBlank { null },
                phone = s.phone.trim().ifBlank { null },
                notes = s.notes.trim().ifBlank { null },
                photo = null,
                createdAt = if (isNew) now else loadedCreatedAt,
                isActive = s.isActive,
                syncState = SyncState.PENDING,
            )
            when (val result = studentRepository.upsertStudent(student)) {
                is AppResult.Success -> _uiState.update { it.copy(isSaving = false, saved = true) }
                is AppResult.Error -> _uiState.update {
                    // The row is already in Room, so the edit isn't lost — the
                    // banner only tells the teacher the cloud copy is pending.
                    it.copy(isSaving = false, saved = true, error = result.error)
                }
            }
        }
    }

    fun consumeError() = _uiState.update { it.copy(error = null) }
}
