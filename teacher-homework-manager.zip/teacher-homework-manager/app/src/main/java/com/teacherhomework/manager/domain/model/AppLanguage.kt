package com.teacherhomework.manager.domain.model

/**
 * The three languages the app fully supports (UI, reports, notifications).
 *
 * Uzbek is the product default. [tag] is the BCP-47 language tag used both for
 * Android locale overrides and as the value persisted to DataStore and to
 * `teachers/{teacherId}.settings.language` in Firestore (Phase 2). Keeping the
 * Firestore value equal to the locale tag avoids a second mapping table.
 */
enum class AppLanguage(val tag: String) {
    UZBEK("uz"),
    RUSSIAN("ru"),
    ENGLISH("en");

    companion object {
        /** Product default per LOCALIZATION POLICY. */
        val DEFAULT = UZBEK

        /**
         * Resolves a stored/remote tag back to the enum, falling back to the
         * default rather than throwing if an unknown value is ever read (e.g. a
         * future language added on another device). Matches only the primary
         * subtag so region-qualified tags like "uz-Latn" still resolve.
         */
        fun fromTag(tag: String?): AppLanguage =
            entries.firstOrNull { it.tag.equals(tag?.substringBefore('-'), ignoreCase = true) }
                ?: DEFAULT
    }
}
