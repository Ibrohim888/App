package com.teacherhomework.manager.presentation.homework

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.EmptyStatePlaceholder
import com.teacherhomework.manager.presentation.components.HomeworkStatusBadge
import com.teacherhomework.manager.presentation.components.OverflowAction
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.util.DateFormat
import com.teacherhomework.manager.presentation.util.toStringRes

/**
 * Homework list with search and status filter chips.
 *
 * Each row shows a relative deadline ("in 3 days" / "2 days overdue") rather
 * than only an absolute date — the relative form is what a teacher actually
 * scans for when deciding what needs attention today.
 */
@Composable
fun HomeworkScreen(
    onOpenHomework: (String) -> Unit,
    onAddHomework: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: HomeworkViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val homework by viewModel.homework.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHostState.showSnackbar(context.getString(it.toStringRes()))
            viewModel.consumeError()
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.nav_homework),
                overflowActions = listOf(
                    OverflowAction(
                        label = stringResource(R.string.action_refresh),
                        onClick = { viewModel.refresh() },
                    ),
                    OverflowAction(
                        label = stringResource(R.string.nav_settings),
                        onClick = onOpenSettings,
                    ),
                ),
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddHomework,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text(stringResource(R.string.action_add_homework)) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            OutlinedTextField(
                value = state.search,
                onValueChange = viewModel::onSearchChange,
                label = { Text(stringResource(R.string.action_search_homework)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = AppCorner.Button,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(
                    selected = state.statusFilter == null,
                    onClick = { viewModel.onStatusFilterChange(null) },
                    label = { Text(stringResource(R.string.filter_all)) },
                    shape = AppCorner.Chip,
                )
                HomeworkStatus.entries.forEach { status ->
                    FilterChip(
                        selected = state.statusFilter == status,
                        onClick = {
                            viewModel.onStatusFilterChange(
                                if (state.statusFilter == status) null else status
                            )
                        },
                        label = { Text(stringResource(status.labelRes())) },
                        shape = AppCorner.Chip,
                    )
                }
            }

            if (homework.isEmpty()) {
                EmptyStatePlaceholder(
                    icon = Icons.Outlined.MenuBook,
                    title = stringResource(R.string.empty_homework_title),
                    message = stringResource(R.string.empty_homework_message),
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(homework, key = { it.id }) { item ->
                        HomeworkRow(homework = item, onClick = { onOpenHomework(item.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeworkRow(homework: Homework, onClick: () -> Unit) {
    val context = LocalContext.current
    val locale = LocalConfiguration.current.locales[0]
    // Overdue only matters while the assignment is still open for work.
    val isOverdue = homework.deadline < System.currentTimeMillis() &&
        homework.status == HomeworkStatus.ACTIVE

    Card(
        onClick = onClick,
        shape = AppCorner.Card,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = homework.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                HomeworkStatusBadge(homework.status)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = "${homework.subject} · ${homework.className}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = DateFormat.relativeDeadline(context, homework.deadline),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = if (isOverdue) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.primary,
            )
        }
    }
}

/** Localized label for a homework lifecycle status. */
@androidx.annotation.StringRes
private fun HomeworkStatus.labelRes(): Int = when (this) {
    HomeworkStatus.DRAFT -> R.string.homework_status_draft
    HomeworkStatus.ACTIVE -> R.string.homework_status_active
    HomeworkStatus.COMPLETED -> R.string.homework_status_completed
    HomeworkStatus.ARCHIVED -> R.string.homework_status_archived
}
