package com.teacherhomework.manager.presentation.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Semantic status color pairs (soft-tinted background + saturated same-hue text)
 * for RESULT STATUS badges (COMPLETED / PARTIAL / MISSING) and inactive states.
 *
 * These are exposed through [LocalStatusColors] so any screen can read
 * theme-correct, mode-correct status colors without threading them manually.
 * They are intentionally constant across all 5 accent themes.
 */
@Immutable
data class StatusColors(
    val completedBg: Color,
    val completedText: Color,
    val partialBg: Color,
    val partialText: Color,
    val missingBg: Color,
    val missingText: Color,
    val inactiveBg: Color,
    val inactiveText: Color,
)

val LightStatusColors = StatusColors(
    completedBg = StatusCompletedBg, completedText = StatusCompletedText,
    partialBg = StatusPartialBg, partialText = StatusPartialText,
    missingBg = StatusMissingBg, missingText = StatusMissingText,
    inactiveBg = StatusInactiveBg, inactiveText = StatusInactiveText,
)

val DarkStatusColors = StatusColors(
    completedBg = StatusCompletedBgDark, completedText = StatusCompletedTextDark,
    partialBg = StatusPartialBgDark, partialText = StatusPartialTextDark,
    missingBg = StatusMissingBgDark, missingText = StatusMissingTextDark,
    inactiveBg = StatusInactiveBgDark, inactiveText = StatusInactiveTextDark,
)

/** Falls back to the light set if a composable is used outside [TeacherAppTheme]. */
val LocalStatusColors = staticCompositionLocalOf { LightStatusColors }

/**
 * The active accent gradient (header treatment). Start = primary, end = a
 * lighter same-family tone, per UI STYLE DIRECTION's gradient header spec.
 */
@Immutable
data class AccentGradient(val start: Color, val end: Color)

val LocalAccentGradient = staticCompositionLocalOf { AccentGradient(ForestPrimary, ForestGradientEnd) }
