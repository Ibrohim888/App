package com.teacherhomework.manager.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.teacherhomework.manager.R
import com.teacherhomework.manager.data.local.dao.NotificationDao
import com.teacherhomework.manager.data.local.entity.NotificationEntity
import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.repository.StatisticsRepository
import com.teacherhomework.manager.notifications.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Weekly digest of the past 7 days: how much was checked and the average grade.
 *
 * Also refreshes the statistics document, so the figure the teacher sees in the
 * notification matches what the Dashboard will show when they open the app.
 */
@HiltWorker
class WeeklySummaryWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val resultRepository: ResultRepository,
    private val statisticsRepository: StatisticsRepository,
    private val appPreferences: AppPreferences,
    private val notificationHelper: NotificationHelper,
    private val notificationDao: NotificationDao,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val settings = appPreferences.notificationSettings.first()
        if (!settings.localRemindersEnabled || !settings.weeklyReportSummaries) {
            return Result.success()
        }

        statisticsRepository.recalculateAndCommit()

        val now = System.currentTimeMillis()
        val weekAgo = now - TimeUnit.DAYS.toMillis(7)
        val weekResults = resultRepository.allResults().filter { it.checkedDate >= weekAgo }

        // Nothing happened this week — a digest saying "0" is just noise.
        if (weekResults.isEmpty()) return Result.success()

        val summary = statisticsRepository.observeSummary().first()
        val ctx = WorkerLocale.localizedContext(applicationContext, appPreferences)

        notificationHelper.post(
            channelId = NotificationHelper.CHANNEL_SUMMARY,
            notificationId = NotificationHelper.ID_SUMMARY,
            title = ctx.getString(R.string.notif_weekly_title),
            body = ctx.getString(
                R.string.notif_weekly_body,
                weekResults.size,
                summary.completionRate.toInt(),
            ),
            deepLink = DEEP_LINK_STATISTICS,
        )

        notificationDao.insert(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                type = TYPE_WEEKLY,
                paramsJson = """{"checked":"${weekResults.size}","rate":"${summary.completionRate.toInt()}"}""",
                postedAt = now,
                read = false,
                deepLink = DEEP_LINK_STATISTICS,
            )
        )
        return Result.success()
    }

    companion object {
        const val WORK_NAME = "weekly_summary"
        const val TYPE_WEEKLY = "WEEKLY"
        const val DEEP_LINK_STATISTICS = "statistics"
    }
}
