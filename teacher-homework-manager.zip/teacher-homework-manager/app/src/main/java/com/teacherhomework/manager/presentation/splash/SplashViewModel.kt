package com.teacherhomework.manager.presentation.splash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

/** Tri-state so the splash can wait rather than guessing while auth resolves. */
enum class AuthState { UNKNOWN, SIGNED_IN, SIGNED_OUT }

/**
 * Resolves whether a Firebase session already exists, which is what makes
 * auto-login work: a returning teacher goes splash → Dashboard without seeing
 * the Login screen at all.
 *
 * Starts at [AuthState.UNKNOWN] deliberately — routing on a premature "signed
 * out" would flash Login for a fraction of a second before bouncing to the
 * Dashboard.
 */
@HiltViewModel
class SplashViewModel @Inject constructor(
    authRepository: AuthRepository,
) : ViewModel() {

    val authState: StateFlow<AuthState> = authRepository.isSignedIn
        .map { if (it) AuthState.SIGNED_IN else AuthState.SIGNED_OUT }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AuthState.UNKNOWN)
}
