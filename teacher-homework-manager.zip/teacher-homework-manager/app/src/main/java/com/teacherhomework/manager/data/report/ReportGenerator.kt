package com.teacherhomework.manager.data.report

import android.content.Context
import com.teacherhomework.manager.R
import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.GradeType
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.Result
import com.teacherhomework.manager.domain.model.Student
import com.teacherhomework.manager.presentation.util.DateFormat
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/** What the teacher asked to export. */
enum class ReportType { CLASS_SUMMARY, STUDENT_DETAIL, HOMEWORK_DETAIL }

enum class ReportFormat { PDF, XLSX }

/**
 * Builds report content and writes it to local storage.
 *
 * LOCALIZATION: every label, column header, and boilerplate string is resolved
 * from string resources through a Context configured with the teacher's CHOSEN
 * app language at generation time — not the device language. Teacher-authored
 * free text (student names, homework titles, comments) is reproduced EXACTLY as
 * typed and is never translated.
 *
 * OFFLINE-FIRST: files are always written to app-private external storage first,
 * so generating a report never requires a connection. Uploading to Firebase
 * Storage for backup/sharing is a separate, optional step.
 */
@Singleton
class ReportGenerator @Inject constructor(
    @ApplicationContext private val appContext: Context,
    private val pdfWriter: PdfReportWriter,
) {
    private val xlsxWriter = XlsxWriter()

    /** All the data a report can draw from, already filtered by the caller. */
    data class ReportData(
        val students: List<Student>,
        val homework: List<Homework>,
        val results: List<Result>,
        val className: String? = null,
    )

    /**
     * @param languageTag the teacher's chosen app language ("uz"/"ru"/"en").
     * @param accentColor ARGB int of the active theme accent, for PDF headers.
     */
    fun generate(
        type: ReportType,
        format: ReportFormat,
        data: ReportData,
        languageTag: String,
        accentColor: Int,
    ): File {
        val locale = Locale.forLanguageTag(languageTag)
        // A Context whose resources resolve to the chosen language, so report
        // labels match the app UI even if the device language differs.
        val ctx = appContext.createConfigurationContext(
            android.content.res.Configuration(appContext.resources.configuration).apply {
                setLocale(locale)
            }
        )

        val now = System.currentTimeMillis()
        val fileName = buildFileName(type, format, now)
        val file = File(reportsDir(), fileName)

        return when (format) {
            ReportFormat.PDF -> writePdf(ctx, file, type, data, locale, accentColor, now)
            ReportFormat.XLSX -> writeXlsx(ctx, file, type, data, locale)
        }
    }

    /** App-private external dir — no storage permission needed on any API level. */
    fun reportsDir(): File =
        File(appContext.getExternalFilesDir(null), "reports").apply { mkdirs() }

    fun listReports(): List<File> =
        reportsDir().listFiles()?.sortedByDescending { it.lastModified() }.orEmpty()

    private fun buildFileName(type: ReportType, format: ReportFormat, now: Long): String {
        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date(now))
        val ext = if (format == ReportFormat.PDF) "pdf" else "xlsx"
        // File names stay ASCII/untranslated so they're safe on every filesystem
        // and easy to sort; only the CONTENT is localized.
        val prefix = when (type) {
            ReportType.CLASS_SUMMARY -> "class_summary"
            ReportType.STUDENT_DETAIL -> "student_report"
            ReportType.HOMEWORK_DETAIL -> "homework_report"
        }
        return "${prefix}_$stamp.$ext"
    }

    // ---------- PDF ----------

    private fun writePdf(
        ctx: Context,
        file: File,
        type: ReportType,
        data: ReportData,
        locale: Locale,
        accentColor: Int,
        now: Long,
    ): File {
        val rollup = rollup(data)
        val stats = listOf(
            PdfReportWriter.SummaryStat(
                label = ctx.getString(R.string.report_stat_students),
                value = data.students.size.toString(),
            ),
            PdfReportWriter.SummaryStat(
                label = ctx.getString(R.string.report_stat_completion),
                value = "${rollup.completionRate.toInt()}%",
            ),
            PdfReportWriter.SummaryStat(
                label = ctx.getString(R.string.report_stat_average),
                value = if (rollup.average == 0.0) "—"
                else String.format(locale, "%.1f", rollup.average),
            ),
            PdfReportWriter.SummaryStat(
                label = ctx.getString(R.string.report_stat_missing),
                value = rollup.missing.toString(),
            ),
        )

        val table = when (type) {
            ReportType.CLASS_SUMMARY -> studentSummaryTable(ctx, data, locale)
            ReportType.STUDENT_DETAIL -> resultDetailTable(ctx, data, locale)
            ReportType.HOMEWORK_DETAIL -> homeworkTable(ctx, data, locale)
        }

        return pdfWriter.write(
            file = file,
            title = ctx.getString(titleRes(type)),
            subtitle = data.className?.let { ctx.getString(R.string.report_subtitle_class, it) }
                .orEmpty(),
            generatedOnLabel = ctx.getString(R.string.report_generated_on),
            generatedOnValue = DateFormat.dateTime(now, locale),
            stats = stats,
            table = table,
            accentColor = accentColor,
        )
    }

    private fun studentSummaryTable(
        ctx: Context,
        data: ReportData,
        locale: Locale,
    ): PdfReportWriter.Table {
        val byStudent = data.results.groupBy { it.studentId }
        return PdfReportWriter.Table(
            columns = listOf(
                ctx.getString(R.string.report_col_student),
                ctx.getString(R.string.report_col_class),
                ctx.getString(R.string.status_completed),
                ctx.getString(R.string.status_partial),
                ctx.getString(R.string.status_missing),
                ctx.getString(R.string.report_col_average),
            ),
            weights = listOf(3f, 1.6f, 1.2f, 1.2f, 1.2f, 1.4f),
            rows = data.students.map { student ->
                val rs = byStudent[student.id].orEmpty()
                val graded = rs.mapNotNull { r -> r.grade?.let { normalize(it, r.gradeType) } }
                listOf(
                    student.fullName,
                    student.className.orEmpty(),
                    rs.count { it.completionStatus == CompletionStatus.COMPLETED }.toString(),
                    rs.count { it.completionStatus == CompletionStatus.PARTIAL }.toString(),
                    rs.count { it.completionStatus == CompletionStatus.MISSING }.toString(),
                    if (graded.isEmpty()) "—" else String.format(locale, "%.1f", graded.average()),
                )
            },
        )
    }

    private fun resultDetailTable(
        ctx: Context,
        data: ReportData,
        locale: Locale,
    ): PdfReportWriter.Table {
        val homeworkById = data.homework.associateBy { it.id }
        val studentById = data.students.associateBy { it.id }
        return PdfReportWriter.Table(
            columns = listOf(
                ctx.getString(R.string.report_col_student),
                ctx.getString(R.string.report_col_homework),
                ctx.getString(R.string.report_col_status),
                ctx.getString(R.string.report_col_grade),
                ctx.getString(R.string.report_col_checked),
            ),
            weights = listOf(2.4f, 3f, 1.6f, 1.1f, 1.6f),
            rows = data.results.sortedByDescending { it.checkedDate }.map { r ->
                listOf(
                    studentById[r.studentId]?.fullName.orEmpty(),
                    homeworkById[r.homeworkId]?.title.orEmpty(),
                    ctx.getString(r.completionStatus.labelRes()),
                    r.grade?.let { String.format(locale, "%.0f", it) } ?: "—",
                    DateFormat.dateShort(r.checkedDate, locale),
                )
            },
        )
    }

    private fun homeworkTable(
        ctx: Context,
        data: ReportData,
        locale: Locale,
    ): PdfReportWriter.Table {
        val byHomework = data.results.groupBy { it.homeworkId }
        return PdfReportWriter.Table(
            columns = listOf(
                ctx.getString(R.string.report_col_homework),
                ctx.getString(R.string.report_col_subject),
                ctx.getString(R.string.report_col_deadline),
                ctx.getString(R.string.report_col_checked_count),
                ctx.getString(R.string.report_col_average),
            ),
            weights = listOf(3f, 1.8f, 1.6f, 1.4f, 1.3f),
            rows = data.homework.sortedByDescending { it.deadline }.map { hw ->
                val rs = byHomework[hw.id].orEmpty()
                val graded = rs.mapNotNull { r -> r.grade?.let { normalize(it, r.gradeType) } }
                listOf(
                    hw.title,
                    hw.subject,
                    DateFormat.dateShort(hw.deadline, locale),
                    rs.size.toString(),
                    if (graded.isEmpty()) "—" else String.format(locale, "%.1f", graded.average()),
                )
            },
        )
    }

    // ---------- XLSX ----------

    private fun writeXlsx(
        ctx: Context,
        file: File,
        type: ReportType,
        data: ReportData,
        locale: Locale,
    ): File {
        val homeworkById = data.homework.associateBy { it.id }
        val studentById = data.students.associateBy { it.id }
        val byStudent = data.results.groupBy { it.studentId }

        val summarySheet = XlsxWriter.Sheet(
            name = ctx.getString(R.string.report_sheet_summary),
            header = listOf(
                ctx.getString(R.string.report_col_student),
                ctx.getString(R.string.report_col_class),
                ctx.getString(R.string.status_completed),
                ctx.getString(R.string.status_partial),
                ctx.getString(R.string.status_missing),
                ctx.getString(R.string.report_col_average),
            ),
            rows = data.students.map { student ->
                val rs = byStudent[student.id].orEmpty()
                val graded = rs.mapNotNull { r -> r.grade?.let { normalize(it, r.gradeType) } }
                listOf(
                    XlsxWriter.Cell.Text(student.fullName),
                    XlsxWriter.Cell.Text(student.className.orEmpty()),
                    XlsxWriter.Cell.Number(
                        rs.count { it.completionStatus == CompletionStatus.COMPLETED }.toDouble()
                    ),
                    XlsxWriter.Cell.Number(
                        rs.count { it.completionStatus == CompletionStatus.PARTIAL }.toDouble()
                    ),
                    XlsxWriter.Cell.Number(
                        rs.count { it.completionStatus == CompletionStatus.MISSING }.toDouble()
                    ),
                    // Numeric, not text, so the teacher can sort/chart it in Excel.
                    if (graded.isEmpty()) XlsxWriter.Cell.Empty
                    else XlsxWriter.Cell.Number(graded.average()),
                )
            },
        )

        val detailSheet = XlsxWriter.Sheet(
            name = ctx.getString(R.string.report_sheet_results),
            header = listOf(
                ctx.getString(R.string.report_col_student),
                ctx.getString(R.string.report_col_homework),
                ctx.getString(R.string.report_col_status),
                ctx.getString(R.string.report_col_grade),
                ctx.getString(R.string.report_col_checked),
                ctx.getString(R.string.field_comment),
            ),
            rows = data.results.sortedByDescending { it.checkedDate }.map { r ->
                listOf(
                    XlsxWriter.Cell.Text(studentById[r.studentId]?.fullName.orEmpty()),
                    XlsxWriter.Cell.Text(homeworkById[r.homeworkId]?.title.orEmpty()),
                    XlsxWriter.Cell.Text(ctx.getString(r.completionStatus.labelRes())),
                    r.grade?.let { XlsxWriter.Cell.Number(it) } ?: XlsxWriter.Cell.Empty,
                    XlsxWriter.Cell.Text(DateFormat.dateShort(r.checkedDate, locale)),
                    // Teacher-authored text, reproduced verbatim.
                    XlsxWriter.Cell.Text(r.comment.orEmpty()),
                )
            },
        )

        val homeworkSheet = XlsxWriter.Sheet(
            name = ctx.getString(R.string.report_sheet_homework),
            header = listOf(
                ctx.getString(R.string.report_col_homework),
                ctx.getString(R.string.report_col_subject),
                ctx.getString(R.string.report_col_class),
                ctx.getString(R.string.report_col_deadline),
                ctx.getString(R.string.report_col_checked_count),
            ),
            rows = data.homework.sortedByDescending { it.deadline }.map { hw ->
                listOf(
                    XlsxWriter.Cell.Text(hw.title),
                    XlsxWriter.Cell.Text(hw.subject),
                    XlsxWriter.Cell.Text(hw.className),
                    XlsxWriter.Cell.Text(DateFormat.dateShort(hw.deadline, locale)),
                    XlsxWriter.Cell.Number(
                        data.results.count { it.homeworkId == hw.id }.toDouble()
                    ),
                )
            },
        )

        val sheets = when (type) {
            ReportType.CLASS_SUMMARY -> listOf(summarySheet, detailSheet, homeworkSheet)
            ReportType.STUDENT_DETAIL -> listOf(detailSheet, summarySheet)
            ReportType.HOMEWORK_DETAIL -> listOf(homeworkSheet, detailSheet)
        }
        xlsxWriter.write(file, sheets)
        return file
    }

    // ---------- shared helpers ----------

    private data class Rollup(val completionRate: Double, val average: Double, val missing: Int)

    private fun rollup(data: ReportData): Rollup {
        if (data.results.isEmpty()) return Rollup(0.0, 0.0, 0)
        val score = data.results.sumOf {
            when (it.completionStatus) {
                CompletionStatus.COMPLETED -> 1.0
                CompletionStatus.PARTIAL -> 0.5
                CompletionStatus.MISSING -> 0.0
            }
        }
        val graded = data.results.mapNotNull { r -> r.grade?.let { normalize(it, r.gradeType) } }
        return Rollup(
            completionRate = (score / data.results.size) * 100.0,
            average = if (graded.isEmpty()) 0.0 else graded.average(),
            missing = data.results.count { it.completionStatus == CompletionStatus.MISSING },
        )
    }

    /** POINT_10 scaled to the 0-100 scale so mixed grade types average sensibly. */
    private fun normalize(grade: Double, type: GradeType): Double =
        if (type == GradeType.POINT_10) grade * 10.0 else grade

    private fun titleRes(type: ReportType): Int = when (type) {
        ReportType.CLASS_SUMMARY -> R.string.report_title_class_summary
        ReportType.STUDENT_DETAIL -> R.string.report_title_student_detail
        ReportType.HOMEWORK_DETAIL -> R.string.report_title_homework_detail
    }
}

/** Localized label for a result status, used in exported reports. */
private fun CompletionStatus.labelRes(): Int = when (this) {
    CompletionStatus.COMPLETED -> R.string.status_completed
    CompletionStatus.PARTIAL -> R.string.status_partial
    CompletionStatus.MISSING -> R.string.status_missing
}
