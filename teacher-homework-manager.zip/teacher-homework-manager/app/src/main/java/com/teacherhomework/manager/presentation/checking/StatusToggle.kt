package com.teacherhomework.manager.presentation.checking

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.teacherhomework.manager.R
import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.theme.LocalStatusColors

/**
 * The 3-way COMPLETED / PARTIAL / MISSING toggle.
 *
 * TOUCH TARGET STANDARD: this is explicitly called out as needing LARGE,
 * unmistakable targets because it is operated one-thumbed while standing, so each
 * segment is 56dp tall (well past the 48dp floor) and takes an equal third of the
 * screen width.
 *
 * ACCESSIBILITY: the selected segment is distinguished by a saturated border and
 * a bolder label as well as by fill color, so selection is never conveyed by
 * color alone; each segment is also marked with the `selected` semantics so
 * TalkBack announces the current state.
 */
@Composable
fun StatusToggle(
    selected: CompletionStatus?,
    onSelect: (CompletionStatus) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier = modifier.fillMaxWidth()) {
        CompletionStatus.entries.forEach { status ->
            StatusSegment(
                status = status,
                isSelected = selected == status,
                onClick = { onSelect(status) },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 3.dp),
            )
        }
    }
}

@Composable
private fun StatusSegment(
    status: CompletionStatus,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalStatusColors.current
    val (bg, fg, labelRes) = when (status) {
        CompletionStatus.COMPLETED ->
            Triple(colors.completedBg, colors.completedText, R.string.status_completed)
        CompletionStatus.PARTIAL ->
            Triple(colors.partialBg, colors.partialText, R.string.status_partial)
        CompletionStatus.MISSING ->
            Triple(colors.missingBg, colors.missingText, R.string.status_missing)
    }

    // Unselected segments sit on the neutral surface so the chosen one reads as
    // the only "lit" option at a glance across the whole list.
    val containerColor by animateColorAsState(
        targetValue = if (isSelected) bg else MaterialTheme.colorScheme.surfaceVariant,
        label = "statusSegmentBg",
    )
    val contentColor = if (isSelected) fg else MaterialTheme.colorScheme.onSurfaceVariant
    val label = stringResource(labelRes)

    Box(
        modifier = modifier
            .heightIn(min = 56.dp)
            .clip(AppCorner.Button)
            .background(containerColor)
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = if (isSelected) fg else androidx.compose.ui.graphics.Color.Transparent,
                shape = AppCorner.Button,
            )
            .clickable(onClick = onClick)
            .semantics {
                this.selected = isSelected
                role = Role.RadioButton
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = contentColor,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}
