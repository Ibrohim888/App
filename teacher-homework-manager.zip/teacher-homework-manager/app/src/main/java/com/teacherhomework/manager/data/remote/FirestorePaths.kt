package com.teacherhomework.manager.data.remote

import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore

/**
 * Central place that builds every Firestore path, so the teacher-scoped subtree
 * shape (`teachers/{teacherId}/...`) is written once rather than string-built at
 * each call site. Every read/write in the app is scoped under the signed-in
 * teacher's own document, which is exactly what the security rules enforce.
 */
object FirestorePaths {
    const val TEACHERS = "teachers"
    const val STUDENTS = "students"
    const val HOMEWORK = "homework"
    const val RESULTS = "results"
    const val STATISTICS = "statistics"
    const val NOTIFICATION_SETTINGS = "notificationSettings"
    const val CALENDAR_EVENTS = "calendarEvents"

    /** The single statistics document id (statistics/summary). */
    const val SUMMARY = "summary"
    /** The single notification-settings document id (notificationSettings/config). */
    const val CONFIG = "config"

    fun teacher(db: FirebaseFirestore, teacherId: String): DocumentReference =
        db.collection(TEACHERS).document(teacherId)

    fun students(db: FirebaseFirestore, teacherId: String): CollectionReference =
        teacher(db, teacherId).collection(STUDENTS)

    fun homework(db: FirebaseFirestore, teacherId: String): CollectionReference =
        teacher(db, teacherId).collection(HOMEWORK)

    fun results(db: FirebaseFirestore, teacherId: String): CollectionReference =
        teacher(db, teacherId).collection(RESULTS)

    fun statisticsSummary(db: FirebaseFirestore, teacherId: String): DocumentReference =
        teacher(db, teacherId).collection(STATISTICS).document(SUMMARY)

    fun notificationConfig(db: FirebaseFirestore, teacherId: String): DocumentReference =
        teacher(db, teacherId).collection(NOTIFICATION_SETTINGS).document(CONFIG)

    fun calendarEvents(db: FirebaseFirestore, teacherId: String): CollectionReference =
        teacher(db, teacherId).collection(CALENDAR_EVENTS)
}
