package com.teacherhomework.manager.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.domain.model.AppLanguage
import com.teacherhomework.manager.domain.model.AppThemeColor
import com.teacherhomework.manager.domain.model.DarkModePreference
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * App-wide UI state driving both the visual theme and the first-launch routing.
 *
 * [language]/[themeColor] are null until the teacher has made the corresponding
 * first-launch choice; the launch router uses that to decide whether to show the
 * selection screens. [effectiveLanguage]/[effectiveThemeColor] always give a
 * concrete value to render with (falling back to defaults) so the selection
 * screens themselves already appear themed.
 */
data class AppUiState(
    val isLoading: Boolean = true,
    val language: AppLanguage? = null,
    val themeColor: AppThemeColor? = null,
    val darkModePreference: DarkModePreference = DarkModePreference.DEFAULT,
) {
    val effectiveLanguage: AppLanguage get() = language ?: AppLanguage.DEFAULT
    val effectiveThemeColor: AppThemeColor get() = themeColor ?: AppThemeColor.DEFAULT
    val needsLanguageSelection: Boolean get() = language == null
    val needsThemeSelection: Boolean get() = themeColor == null
}

/**
 * Owns the app's global appearance/onboarding state, read from and written to
 * [AppPreferences]. Held at the Activity level so a change (theme, language,
 * dark mode) recomposes the entire app instantly — the mechanism behind
 * "takes effect immediately, no restart".
 */
@HiltViewModel
class AppViewModel @Inject constructor(
    private val appPreferences: AppPreferences,
) : ViewModel() {

    val uiState: StateFlow<AppUiState> = combine(
        appPreferences.language,
        appPreferences.themeColor,
        appPreferences.darkModePreference,
    ) { language, themeColor, darkMode ->
        AppUiState(
            isLoading = false,
            language = language,
            themeColor = themeColor,
            darkModePreference = darkMode,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AppUiState(isLoading = true),
    )

    /** Persists the first-launch (or Settings) language choice. */
    fun selectLanguage(language: AppLanguage) = viewModelScope.launch {
        appPreferences.setLanguage(language)
    }

    /** Persists the first-launch (or Settings) accent choice. */
    fun selectThemeColor(themeColor: AppThemeColor) = viewModelScope.launch {
        appPreferences.setThemeColor(themeColor)
    }

    /** Persists the dark-mode preference (Settings, Phase 2). */
    fun setDarkModePreference(pref: DarkModePreference) = viewModelScope.launch {
        appPreferences.setDarkModePreference(pref)
    }
}
