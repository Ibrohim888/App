package com.teacherhomework.manager.presentation.splash

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.presentation.AppUiState
import com.teacherhomework.manager.presentation.theme.LocalAccentGradient

/**
 * Splash / routing gate. Renders a branded gradient screen while the stored
 * language/theme and the Firebase session are being read, then routes once:
 *   - first launch (no language) → language selection
 *   - language chosen but not theme → theme selection
 *   - both chosen + signed in → Main (auto-login; Login is never shown)
 *   - both chosen + signed out → Login
 *
 * Routing waits for BOTH prefs and auth to resolve. Acting on a half-resolved
 * state would either flash the language screen at a returning teacher or bounce
 * them through Login on the way to the Dashboard.
 */
@Composable
fun SplashScreen(
    uiState: AppUiState,
    onRouteToLanguage: () -> Unit,
    onRouteToTheme: () -> Unit,
    onRouteToAuth: () -> Unit,
    onRouteToMain: () -> Unit,
    viewModel: SplashViewModel = hiltViewModel(),
) {
    val authState by viewModel.authState.collectAsStateWithLifecycle()

    LaunchedEffect(uiState.isLoading, uiState.needsLanguageSelection, uiState.needsThemeSelection, authState) {
        if (uiState.isLoading) return@LaunchedEffect
        when {
            uiState.needsLanguageSelection -> onRouteToLanguage()
            uiState.needsThemeSelection -> onRouteToTheme()
            authState == AuthState.UNKNOWN -> Unit // still resolving; hold here
            authState == AuthState.SIGNED_IN -> onRouteToMain()
            else -> onRouteToAuth()
        }
    }

    val gradient = LocalAccentGradient.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(listOf(gradient.start, gradient.end))),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onPrimary,
            )
            Spacer(Modifier.height(24.dp))
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(28.dp),
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = stringResource(R.string.splash_loading),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimary,
            )
        }
    }
}
