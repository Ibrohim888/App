package com.teacherhomework.manager.data.remote

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.teacherhomework.manager.data.mapper.asEpochMillis
import com.teacherhomework.manager.data.mapper.homeworkFromFirestore
import com.teacherhomework.manager.data.mapper.resultFromFirestore
import com.teacherhomework.manager.data.mapper.studentFromFirestore
import com.teacherhomework.manager.data.mapper.toFirestoreMap
import com.teacherhomework.manager.domain.model.AppLanguage
import com.teacherhomework.manager.domain.model.AppThemeColor
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.NotificationSettings
import com.teacherhomework.manager.domain.model.Result
import com.teacherhomework.manager.domain.model.Student
import com.teacherhomework.manager.domain.model.Teacher
import com.teacherhomework.manager.domain.model.TeacherSettings
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Thin Firestore access layer. Every method takes the `teacherId` explicitly so
 * the caller (repository) owns the "who am I" question and these classes stay
 * trivially testable against the Firebase Emulator.
 *
 * COST AWARENESS: the fetch* methods are one-shot `get()` calls used by the
 * refresh/sync path, not live snapshot listeners. The UI observes Room instead,
 * so a screen rotation or tab switch costs zero Firestore reads. Sync pulls are
 * bounded by `limit` and ordered so a partial pull is still the most relevant
 * slice of data.
 */
@Singleton
class StudentRemoteDataSource @Inject constructor(
    private val db: FirebaseFirestore,
) {
    suspend fun fetchAll(teacherId: String, limit: Long = 500): List<Student> =
        FirestorePaths.students(db, teacherId)
            .orderBy("fullName", Query.Direction.ASCENDING)
            .limit(limit)
            .get()
            .await()
            .documents
            .mapNotNull { doc -> doc.data?.let { studentFromFirestore(doc.id, it) } }

    suspend fun upsert(teacherId: String, student: Student) {
        FirestorePaths.students(db, teacherId)
            .document(student.id)
            .set(student.toFirestoreMap(), SetOptions.merge())
            .await()
    }

    suspend fun setActive(teacherId: String, studentId: String, isActive: Boolean) {
        FirestorePaths.students(db, teacherId)
            .document(studentId)
            .update("isActive", isActive)
            .await()
    }

    suspend fun delete(teacherId: String, studentId: String) {
        FirestorePaths.students(db, teacherId).document(studentId).delete().await()
    }
}

@Singleton
class HomeworkRemoteDataSource @Inject constructor(
    private val db: FirebaseFirestore,
) {
    suspend fun fetchAll(teacherId: String, limit: Long = 500): List<Homework> =
        FirestorePaths.homework(db, teacherId)
            .orderBy("deadline", Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()
            .documents
            .mapNotNull { doc -> doc.data?.let { homeworkFromFirestore(doc.id, it) } }

    suspend fun upsert(teacherId: String, homework: Homework) {
        FirestorePaths.homework(db, teacherId)
            .document(homework.id)
            .set(homework.toFirestoreMap(), SetOptions.merge())
            .await()
    }

    suspend fun delete(teacherId: String, homeworkId: String) {
        FirestorePaths.homework(db, teacherId).document(homeworkId).delete().await()
    }
}

@Singleton
class ResultRemoteDataSource @Inject constructor(
    private val db: FirebaseFirestore,
) {
    suspend fun fetchAll(teacherId: String, limit: Long = 2000): List<Result> =
        FirestorePaths.results(db, teacherId)
            .orderBy("checkedDate", Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()
            .documents
            .mapNotNull { doc -> doc.data?.let { resultFromFirestore(doc.id, it) } }

    suspend fun upsert(teacherId: String, result: Result) {
        FirestorePaths.results(db, teacherId)
            .document(result.id)
            .set(result.toFirestoreMap(), SetOptions.merge())
            .await()
    }

    /**
     * Deletes every result belonging to one homework, in batches of 400 (under
     * Firestore's 500-op batch cap). Used by the homework cascade-delete path.
     */
    suspend fun deleteForHomework(teacherId: String, homeworkId: String) {
        deleteWhere(teacherId, field = "homeworkId", value = homeworkId)
    }

    /** Deletes every result belonging to one student (hard-delete cascade). */
    suspend fun deleteForStudent(teacherId: String, studentId: String) {
        deleteWhere(teacherId, field = "studentId", value = studentId)
    }

    private suspend fun deleteWhere(teacherId: String, field: String, value: String) {
        val snapshot = FirestorePaths.results(db, teacherId)
            .whereEqualTo(field, value)
            .get()
            .await()
        snapshot.documents.chunked(400).forEach { chunk ->
            val batch = db.batch()
            chunk.forEach { batch.delete(it.reference) }
            batch.commit().await()
        }
    }
}

/** Teacher profile document + the settings map that mirrors DataStore. */
@Singleton
class TeacherRemoteDataSource @Inject constructor(
    private val db: FirebaseFirestore,
) {
    suspend fun fetch(teacherId: String): Teacher? {
        val doc = FirestorePaths.teacher(db, teacherId).get().await()
        val data = doc.data ?: return null
        @Suppress("UNCHECKED_CAST")
        val settingsMap = data["settings"] as? Map<String, Any?> ?: emptyMap()
        return Teacher(
            id = doc.id,
            fullName = data["fullName"] as? String ?: "",
            email = data["email"] as? String ?: "",
            profileImage = data["profileImage"] as? String,
            createdAt = data["createdAt"].asEpochMillis(),
            lastLogin = data["lastLogin"].asEpochMillis(),
            settings = TeacherSettings(
                language = settingsMap["language"] as? String ?: AppLanguage.DEFAULT.tag,
                themeColor = settingsMap["themeColor"] as? String ?: AppThemeColor.DEFAULT.id,
                darkMode = settingsMap["darkMode"] as? Boolean ?: false,
            ),
        )
    }

    suspend fun updateSettings(teacherId: String, settings: TeacherSettings) {
        FirestorePaths.teacher(db, teacherId).set(
            mapOf(
                "settings" to mapOf(
                    "language" to settings.language,
                    "themeColor" to settings.themeColor,
                    "darkMode" to settings.darkMode,
                ),
            ),
            SetOptions.merge(),
        ).await()
    }

    suspend fun updateProfile(teacherId: String, fullName: String, profileImage: String?) {
        val data = buildMap<String, Any?> {
            put("fullName", fullName)
            if (profileImage != null) put("profileImage", profileImage)
        }
        FirestorePaths.teacher(db, teacherId).set(data, SetOptions.merge()).await()
    }

    suspend fun updateLastLogin(teacherId: String) {
        FirestorePaths.teacher(db, teacherId)
            .set(mapOf("lastLogin" to com.google.firebase.Timestamp.now()), SetOptions.merge())
            .await()
    }
}

/** Local-only notification preferences mirrored to Firestore (no FCM fields). */
@Singleton
class NotificationSettingsRemoteDataSource @Inject constructor(
    private val db: FirebaseFirestore,
) {
    suspend fun fetch(teacherId: String): NotificationSettings? {
        val data = FirestorePaths.notificationConfig(db, teacherId).get().await().data ?: return null
        return NotificationSettings(
            localRemindersEnabled = data["localRemindersEnabled"] as? Boolean ?: true,
            deadlineReminders = data["deadlineReminders"] as? Boolean ?: true,
            missingHomeworkAlerts = data["missingHomeworkAlerts"] as? Boolean ?: true,
            weeklyReportSummaries = data["weeklyReportSummaries"] as? Boolean ?: true,
        )
    }

    suspend fun update(teacherId: String, settings: NotificationSettings) {
        FirestorePaths.notificationConfig(db, teacherId).set(
            mapOf(
                "localRemindersEnabled" to settings.localRemindersEnabled,
                "deadlineReminders" to settings.deadlineReminders,
                "missingHomeworkAlerts" to settings.missingHomeworkAlerts,
                "weeklyReportSummaries" to settings.weeklyReportSummaries,
            ),
            SetOptions.merge(),
        ).await()
    }
}
