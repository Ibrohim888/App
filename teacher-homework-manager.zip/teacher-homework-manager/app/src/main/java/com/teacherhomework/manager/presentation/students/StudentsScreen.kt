package com.teacherhomework.manager.presentation.students

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.People
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.domain.model.Student
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.EmptyStatePlaceholder
import com.teacherhomework.manager.presentation.components.InitialsAvatar
import com.teacherhomework.manager.presentation.components.OverflowAction
import com.teacherhomework.manager.presentation.components.StatusBadge
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.theme.LocalStatusColors
import com.teacherhomework.manager.presentation.util.toStringRes

/**
 * The roster. Search + class filter chips sit above a lazy list of student
 * cards; the FAB opens the create form.
 *
 * PERFORMANCE: the list is a [LazyColumn] keyed by student id, so adding or
 * renaming one student recomposes that row only, not the whole roster.
 */
@Composable
fun StudentsScreen(
    onOpenStudent: (String) -> Unit,
    onAddStudent: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: StudentsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val students by viewModel.students.collectAsStateWithLifecycle()
    val classNames by viewModel.classNames.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHostState.showSnackbar(context.getString(it.toStringRes()))
            viewModel.consumeError()
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.nav_students),
                overflowActions = listOf(
                    OverflowAction(
                        label = stringResource(
                            if (state.showInactive) R.string.action_hide_inactive
                            else R.string.action_show_inactive
                        ),
                        onClick = { viewModel.onShowInactiveChange(!state.showInactive) },
                    ),
                    OverflowAction(
                        label = stringResource(R.string.action_refresh),
                        onClick = { viewModel.refresh() },
                    ),
                    OverflowAction(
                        label = stringResource(R.string.nav_settings),
                        onClick = onOpenSettings,
                    ),
                ),
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddStudent,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text(stringResource(R.string.action_add_student)) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            OutlinedTextField(
                value = state.search,
                onValueChange = viewModel::onSearchChange,
                label = { Text(stringResource(R.string.action_search_students)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = AppCorner.Button,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            )

            if (classNames.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = state.selectedClass == null,
                        onClick = { viewModel.onClassFilterChange(null) },
                        label = { Text(stringResource(R.string.filter_all_classes)) },
                        shape = AppCorner.Chip,
                    )
                    classNames.forEach { className ->
                        FilterChip(
                            selected = state.selectedClass == className,
                            onClick = {
                                viewModel.onClassFilterChange(
                                    if (state.selectedClass == className) null else className
                                )
                            },
                            label = { Text(className) },
                            shape = AppCorner.Chip,
                        )
                    }
                }
            }

            if (students.isEmpty()) {
                EmptyStatePlaceholder(
                    icon = Icons.Outlined.People,
                    title = stringResource(R.string.empty_students_title),
                    message = stringResource(R.string.empty_students_message),
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                LazyColumn(
                    // Bottom padding clears the FAB so the last row is never
                    // hidden under it.
                    contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(students, key = { it.id }) { student ->
                        StudentRow(student = student, onClick = { onOpenStudent(student.id) })
                    }
                }
            }
        }
    }
}

/** One roster row: rounded-square initials avatar, name, class, inactive badge. */
@Composable
private fun StudentRow(student: Student, onClick: () -> Unit) {
    val statusColors = LocalStatusColors.current
    Card(
        onClick = onClick,
        shape = AppCorner.Card,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            InitialsAvatar(name = student.fullName, size = 48.dp)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = student.fullName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                if (!student.className.isNullOrBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = student.className,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (!student.isActive) {
                StatusBadge(
                    text = stringResource(R.string.status_inactive),
                    backgroundColor = statusColors.inactiveBg,
                    textColor = statusColors.inactiveText,
                )
            }
        }
    }
}
