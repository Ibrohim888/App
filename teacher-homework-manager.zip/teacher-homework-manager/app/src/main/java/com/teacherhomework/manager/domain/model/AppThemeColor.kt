package com.teacherhomework.manager.domain.model

/**
 * The 5 selectable accent themes. All share the same "warm & friendly" shape
 * language and neutral background (see UI STYLE DIRECTION); only the accent hue
 * family changes between them.
 *
 * [id] is the stable token persisted to DataStore and to
 * `teachers/{teacherId}.settings.themeColor` in Firestore (Phase 2). These
 * tokens are contract values — never rename them once data exists.
 */
enum class AppThemeColor(val id: String) {
    FOREST_GREEN("forest_green"),
    TRUST_BLUE("trust_blue"),
    VIOLET("violet"),
    WARM_ROSE("warm_rose"),
    TEAL("teal");

    companion object {
        /** Default accent on a fresh install, before the teacher chooses one. */
        val DEFAULT = FOREST_GREEN

        /** Resolves a stored/remote id back to the enum, falling back to default. */
        fun fromId(id: String?): AppThemeColor =
            entries.firstOrNull { it.id == id } ?: DEFAULT
    }
}
