package com.teacherhomework.manager.presentation.util

import android.content.Context
import com.teacherhomework.manager.R
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Date/time formatting helpers.
 *
 * All of these take an explicit [Locale] (derived from the teacher's chosen app
 * language, NOT the device language) so month names and ordering match the rest
 * of the UI — a teacher running the app in Uzbek on a Russian phone should see
 * Uzbek dates (LOCALIZATION POLICY).
 */
object DateFormat {

    fun date(epochMillis: Long, locale: Locale): String =
        SimpleDateFormat("dd MMM yyyy", locale).format(Date(epochMillis))

    fun dateShort(epochMillis: Long, locale: Locale): String =
        SimpleDateFormat("dd.MM.yyyy", locale).format(Date(epochMillis))

    fun dateTime(epochMillis: Long, locale: Locale): String =
        SimpleDateFormat("dd MMM yyyy, HH:mm", locale).format(Date(epochMillis))

    fun time(epochMillis: Long, locale: Locale): String =
        SimpleDateFormat("HH:mm", locale).format(Date(epochMillis))

    fun monthYear(epochMillis: Long, locale: Locale): String =
        SimpleDateFormat("LLLL yyyy", locale).format(Date(epochMillis))

    /**
     * Human-friendly relative deadline text ("in 3 days", "2 days overdue",
     * "today"). Uses whole-day boundaries rather than raw 24-hour arithmetic, so
     * a deadline at 23:00 tonight reads "today", not "in 0 days".
     */
    fun relativeDeadline(context: Context, deadlineMillis: Long, nowMillis: Long = System.currentTimeMillis()): String {
        val days = daysBetween(nowMillis, deadlineMillis)
        return when {
            days == 0L -> context.getString(R.string.due_today)
            days == 1L -> context.getString(R.string.due_tomorrow)
            days > 1L -> context.getString(R.string.due_in_days, days.toInt())
            days == -1L -> context.getString(R.string.overdue_yesterday)
            else -> context.getString(R.string.overdue_days, (-days).toInt())
        }
    }

    /**
     * Whole calendar days from [fromMillis] to [toMillis] (negative if in the
     * past). Both are normalized to local midnight first so the result counts
     * date boundaries crossed, not elapsed hours.
     */
    fun daysBetween(fromMillis: Long, toMillis: Long): Long {
        val from = atStartOfDay(fromMillis)
        val to = atStartOfDay(toMillis)
        return TimeUnit.MILLISECONDS.toDays(to - from)
    }

    /** Local midnight at the start of the day containing [epochMillis]. */
    fun atStartOfDay(epochMillis: Long): Long = Calendar.getInstance().apply {
        timeInMillis = epochMillis
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    /** Local 23:59:59.999 of the day containing [epochMillis]. */
    fun atEndOfDay(epochMillis: Long): Long = Calendar.getInstance().apply {
        timeInMillis = epochMillis
        set(Calendar.HOUR_OF_DAY, 23)
        set(Calendar.MINUTE, 59)
        set(Calendar.SECOND, 59)
        set(Calendar.MILLISECOND, 999)
    }.timeInMillis

    /** True when the two instants fall on the same local calendar day. */
    fun isSameDay(a: Long, b: Long): Boolean = atStartOfDay(a) == atStartOfDay(b)
}
