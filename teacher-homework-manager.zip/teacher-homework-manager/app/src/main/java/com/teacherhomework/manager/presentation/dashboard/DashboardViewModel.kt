package com.teacherhomework.manager.presentation.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.model.CompletionStatus
import com.teacherhomework.manager.domain.model.Homework
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.domain.model.StatisticsSummary
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.repository.StatisticsRepository
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.presentation.util.DateFormat
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import javax.inject.Inject

/** An assignment that needs the teacher's attention, and why. */
data class AttentionItem(
    val homework: Homework,
    val kind: Kind,
    val ungradedCount: Int,
) {
    enum class Kind {
        /** Deadline already passed and grading isn't finished. */
        OVERDUE,

        /** Deadline is within the next few days. */
        DUE_SOON,

        /** Deadline passed, nothing recorded at all. */
        UNCHECKED,
    }
}

data class DashboardUiState(
    val isRefreshing: Boolean = false,
)

/**
 * Dashboard: the always-correct, live in-app view of what needs attention.
 *
 * This exists specifically because local reminders are best-effort — Android's
 * background scheduler may run a WorkManager job hours late or not at all if the
 * device is dozing. The teacher must never depend on a notification firing to
 * learn that something is overdue, so this list is recomputed from the live data
 * every time the screen is observed (KNOWN DEFERRED ITEMS mitigation).
 */
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val statisticsRepository: StatisticsRepository,
    private val studentRepository: StudentRepository,
    private val homeworkRepository: HomeworkRepository,
    private val resultRepository: ResultRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    val summary: StateFlow<StatisticsSummary> = statisticsRepository.observeSummary()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatisticsSummary())

    val activeStudentCount: StateFlow<Int> = studentRepository.observeStudents()
        .map { it.size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    /**
     * Assignments needing attention, most urgent first (overdue before due-soon,
     * then by deadline). Only ACTIVE assignments qualify — a DRAFT isn't out yet
     * and an ARCHIVED/COMPLETED one is deliberately done.
     */
    val attentionItems: StateFlow<List<AttentionItem>> = combine(
        homeworkRepository.observeHomework(status = HomeworkStatus.ACTIVE),
        studentRepository.observeStudents(),
        resultRepository.observeAllResults(),
    ) { homework, students, results ->
        val now = System.currentTimeMillis()
        val soonCutoff = now + TimeUnit.DAYS.toMillis(DUE_SOON_DAYS)
        val resultsByHomework = results.groupBy { it.homeworkId }
        val studentsByClass = students.groupBy { it.className }

        homework.mapNotNull { hw ->
            val classSize = studentsByClass[hw.className]?.size ?: 0
            val recorded = resultsByHomework[hw.id].orEmpty()
            val ungraded = (classSize - recorded.size).coerceAtLeast(0)

            val kind = when {
                hw.deadline < now && recorded.isEmpty() && classSize > 0 ->
                    AttentionItem.Kind.UNCHECKED
                hw.deadline < now && ungraded > 0 -> AttentionItem.Kind.OVERDUE
                hw.deadline in now..soonCutoff -> AttentionItem.Kind.DUE_SOON
                else -> null
            } ?: return@mapNotNull null

            AttentionItem(homework = hw, kind = kind, ungradedCount = ungraded)
        }.sortedWith(
            compareBy<AttentionItem> { it.kind.ordinal }.thenBy { it.homework.deadline }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Assignments due today, shown as the "today" strip. */
    val dueToday: StateFlow<List<Homework>> =
        homeworkRepository.observeHomework(status = HomeworkStatus.ACTIVE)
            .map { list ->
                val now = System.currentTimeMillis()
                list.filter { DateFormat.isSameDay(it.deadline, now) }
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        refresh()
    }

    /**
     * Pulls all three collections and recomputes statistics. Called on open and
     * from pull-to-refresh — deliberately not on every recomposition, so the
     * read cost stays bounded (COST AWARENESS).
     */
    fun refresh() {
        _uiState.update { it.copy(isRefreshing = true) }
        viewModelScope.launch {
            studentRepository.refresh()
            homeworkRepository.refresh()
            resultRepository.refresh()
            statisticsRepository.recalculateAndCommit()
            _uiState.update { it.copy(isRefreshing = false) }
        }
    }

    private companion object {
        /** How far ahead a deadline counts as "due soon" on the Dashboard. */
        const val DUE_SOON_DAYS = 3L
    }
}
