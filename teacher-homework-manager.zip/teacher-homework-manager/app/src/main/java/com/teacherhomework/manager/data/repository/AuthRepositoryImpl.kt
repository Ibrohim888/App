package com.teacherhomework.manager.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.data.remote.FirestorePaths
import com.teacherhomework.manager.domain.model.AppLanguage
import com.teacherhomework.manager.domain.model.AppThemeColor
import com.teacherhomework.manager.domain.repository.AuthRepository
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.tasks.await
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Firebase Authentication implementation.
 *
 * On [register] it also creates the `teachers/{uid}` document, seeding
 * `settings.language` / `settings.themeColor` from the choices the teacher
 * already made on the first-launch selection screens (read from DataStore) —
 * this is the "written to Firestore once the account exists" half of the
 * LOCALIZATION / THEME COLOR policies. On [login] the same settings are merged
 * up, so a device that onboarded offline still publishes its choices.
 *
 * Firebase exceptions are translated into [AppError] kinds so the UI can render
 * localized messages instead of raw English SDK text.
 */
@Singleton
class AuthRepositoryImpl @Inject constructor(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore,
    private val appPreferences: AppPreferences,
) : AuthRepository {

    override val currentUserId: String?
        get() = auth.currentUser?.uid

    /**
     * Emits on every auth state change (sign-in, sign-out, token refresh), which
     * is what makes auto-login on relaunch and reactive sign-out routing work.
     */
    override val isSignedIn: Flow<Boolean> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { trySend(it.currentUser != null) }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    override suspend fun register(
        fullName: String,
        email: String,
        password: String,
    ): AppResult<String> = runCatchingAuth {
        val credential = auth.createUserWithEmailAndPassword(email.trim(), password).await()
        val uid = credential.user?.uid ?: error("Missing uid after registration")
        writeTeacherDocument(uid, fullName.trim(), email.trim(), isNew = true)
        uid
    }

    override suspend fun login(email: String, password: String): AppResult<String> = runCatchingAuth {
        val credential = auth.signInWithEmailAndPassword(email.trim(), password).await()
        val uid = credential.user?.uid ?: error("Missing uid after login")
        // Merge settings + lastLogin; never overwrites fullName on an existing doc.
        writeTeacherDocument(uid, fullName = null, email = email.trim(), isNew = false)
        uid
    }

    override suspend fun sendPasswordReset(email: String): AppResult<Unit> = runCatchingAuth {
        auth.sendPasswordResetEmail(email.trim()).await()
    }

    override suspend fun logout() {
        auth.signOut()
    }

    /**
     * Creates or merges `teachers/{uid}`. Uses SetOptions.merge() so logging in
     * on a second device never clobbers existing profile fields; only the
     * settings the teacher currently has locally, plus lastLogin, are updated.
     */
    private suspend fun writeTeacherDocument(
        uid: String,
        fullName: String?,
        email: String,
        isNew: Boolean,
    ) {
        val language = appPreferences.language.first() ?: AppLanguage.DEFAULT
        val themeColor = appPreferences.themeColor.first() ?: AppThemeColor.DEFAULT
        val darkMode = appPreferences.darkModePreference.first().toDarkFlag() ?: false
        val now = com.google.firebase.Timestamp.now()

        val data = buildMap<String, Any?> {
            put("email", email)
            put("lastLogin", now)
            put(
                "settings",
                mapOf(
                    "language" to language.tag,
                    "themeColor" to themeColor.id,
                    "darkMode" to darkMode,
                ),
            )
            if (fullName != null) put("fullName", fullName)
            if (isNew) {
                put("createdAt", now)
                put("profileImage", null)
            }
        }

        FirestorePaths.teacher(firestore, uid).set(data, SetOptions.merge()).await()
    }

    /**
     * Runs an auth/Firestore call and maps thrown exceptions onto [AppError]
     * kinds. Network failures are separated from credential failures so the UI
     * can tell the teacher "you're offline" vs "wrong password".
     */
    private suspend inline fun <T> runCatchingAuth(block: () -> T): AppResult<T> = try {
        AppResult.Success(block())
    } catch (e: FirebaseAuthWeakPasswordException) {
        AppResult.Error(AppError.WEAK_PASSWORD, e)
    } catch (e: FirebaseAuthUserCollisionException) {
        AppResult.Error(AppError.EMAIL_ALREADY_IN_USE, e)
    } catch (e: FirebaseAuthInvalidUserException) {
        AppResult.Error(AppError.USER_NOT_FOUND, e)
    } catch (e: FirebaseAuthInvalidCredentialsException) {
        AppResult.Error(AppError.WRONG_CREDENTIALS, e)
    } catch (e: IOException) {
        AppResult.Error(AppError.NETWORK, e)
    } catch (e: Exception) {
        AppResult.Error(AppError.UNKNOWN, e)
    }
}
