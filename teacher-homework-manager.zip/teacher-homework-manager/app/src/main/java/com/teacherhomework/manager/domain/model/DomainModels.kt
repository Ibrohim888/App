package com.teacherhomework.manager.domain.model

/**
 * Domain models — pure Kotlin, framework-free. These mirror the Firestore data
 * model in CLAUDE.md exactly (field names are contract; do not rename). Data-
 * layer entities (Room) and Firestore DTOs map to/from these.
 *
 * Timestamps are represented as epoch milliseconds (Long) in the domain layer to
 * stay framework-free; the data layer converts to/from Firestore Timestamp.
 */

/** teachers/{teacherId} */
data class Teacher(
    val id: String,
    val fullName: String,
    val email: String,
    val profileImage: String? = null,
    val createdAt: Long = 0L,
    val lastLogin: Long = 0L,
    val settings: TeacherSettings = TeacherSettings(),
)

/** teachers/{teacherId}.settings map. */
data class TeacherSettings(
    val language: String = AppLanguage.DEFAULT.tag,
    val themeColor: String = AppThemeColor.DEFAULT.id,
    val darkMode: Boolean = false,
)

/** teachers/{teacherId}/students/{studentId} */
data class Student(
    val id: String,
    val firstName: String,
    val lastName: String,
    val fullName: String,
    val className: String? = null,
    val phone: String? = null,
    val notes: String? = null,
    val photo: String? = null,
    val createdAt: Long = 0L,
    val isActive: Boolean = true,
    val syncState: SyncState = SyncState.SYNCED,
)

/** teachers/{teacherId}/homework/{homeworkId} */
data class Homework(
    val id: String,
    val title: String,
    val subject: String,
    val description: String = "",
    /** REQUIRED — scopes homework to a class/group; sourced from student className values. */
    val className: String,
    val attachmentURL: String? = null,
    val assignedDate: Long = 0L,
    val deadline: Long = 0L,
    val status: HomeworkStatus = HomeworkStatus.DRAFT,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val syncState: SyncState = SyncState.SYNCED,
)

/** teachers/{teacherId}/results/{resultId} */
data class Result(
    val id: String,
    val studentId: String,
    val homeworkId: String,
    val completionStatus: CompletionStatus,
    val grade: Double? = null,
    val gradeType: GradeType = GradeType.PERCENT,
    val comment: String? = null,
    val checkedDate: Long = 0L,
    val checkedBy: String = "",
    val syncState: SyncState = SyncState.SYNCED,
)

/** teachers/{teacherId}/statistics/summary */
data class StatisticsSummary(
    val totalStudents: Int = 0,
    val averageGrade: Double = 0.0,
    val completionRate: Double = 0.0,
    val missingHomeworkCount: Int = 0,
    val monthlyProgress: Map<String, Double> = emptyMap(),
    val weeklyProgress: Map<String, Double> = emptyMap(),
    val lastRecalculatedAt: Long = 0L,
)

/** teachers/{teacherId}/notificationSettings/config */
data class NotificationSettings(
    val localRemindersEnabled: Boolean = true,
    val deadlineReminders: Boolean = true,
    val missingHomeworkAlerts: Boolean = true,
    val weeklyReportSummaries: Boolean = true,
)
