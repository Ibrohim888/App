package com.teacherhomework.manager.presentation.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.sp
import com.teacherhomework.manager.R

/*
 * Typography per UI STYLE DIRECTION:
 *   - 'Manrope' (rounded-geometric) for headings / numbers / stat figures.
 *   - 'Inter' (humanist sans) for body text and labels.
 *
 * Both are loaded via the Google Fonts downloadable-fonts provider, so no font
 * binaries ship in the APK. Both families include full Cyrillic and Latin
 * (Uzbek) coverage. If the provider is unavailable at runtime the system falls
 * back to the platform default rather than crashing.
 *
 * NOTE (glyph check, Phase 1 DoD): Manrope and Inter both render Cyrillic and
 * Uzbek-Latin glyphs (including o‘/g‘ with the modifier letter turned comma)
 * correctly. If a future translation needs a glyph neither covers, swap in a
 * Cyrillic-complete rounded-geometric alternative here — this is the single
 * place fonts are declared.
 */

private val provider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs,
)

private val manropeGF = GoogleFont("Manrope")
private val interGF = GoogleFont("Inter")

val ManropeFamily = FontFamily(
    Font(googleFont = manropeGF, fontProvider = provider, weight = FontWeight.Normal),
    Font(googleFont = manropeGF, fontProvider = provider, weight = FontWeight.Medium),
    Font(googleFont = manropeGF, fontProvider = provider, weight = FontWeight.SemiBold),
    Font(googleFont = manropeGF, fontProvider = provider, weight = FontWeight.Bold),
    Font(googleFont = manropeGF, fontProvider = provider, weight = FontWeight.ExtraBold),
)

val InterFamily = FontFamily(
    Font(googleFont = interGF, fontProvider = provider, weight = FontWeight.Normal),
    Font(googleFont = interGF, fontProvider = provider, weight = FontWeight.Medium),
    Font(googleFont = interGF, fontProvider = provider, weight = FontWeight.SemiBold),
    Font(googleFont = interGF, fontProvider = provider, weight = FontWeight.Bold),
)

/**
 * Material 3 type scale. Display/headline/title roles use Manrope (the display
 * family); body/label roles use Inter. Base body is 16sp with 1.5 line-height
 * for readability, per the accessibility baseline.
 */
val AppTypography = Typography(
    displaySmall = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.ExtraBold,
        fontSize = 30.sp, lineHeight = 36.sp,
    ),
    headlineMedium = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.Bold,
        fontSize = 24.sp, lineHeight = 30.sp, // screen title (24sp)
    ),
    headlineSmall = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.Bold,
        fontSize = 20.sp, lineHeight = 26.sp,
    ),
    titleLarge = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp, lineHeight = 24.sp, // section title (18sp)
    ),
    titleMedium = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp, lineHeight = 22.sp,
    ),
    bodyLarge = TextStyle(
        fontFamily = InterFamily, fontWeight = FontWeight.Normal,
        fontSize = 16.sp, lineHeight = 24.sp, // body (16sp, 1.5 line-height)
    ),
    bodyMedium = TextStyle(
        fontFamily = InterFamily, fontWeight = FontWeight.Normal,
        fontSize = 14.sp, lineHeight = 20.sp,
    ),
    labelLarge = TextStyle(
        fontFamily = InterFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp, lineHeight = 20.sp, // button labels (15-16sp, semibold)
    ),
    labelMedium = TextStyle(
        fontFamily = InterFamily, fontWeight = FontWeight.Medium,
        fontSize = 12.sp, lineHeight = 16.sp,
    ),
)
