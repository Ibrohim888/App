package com.teacherhomework.manager.presentation.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.teacherhomework.manager.domain.repository.AuthRepository
import com.teacherhomework.manager.domain.util.AppError
import com.teacherhomework.manager.domain.util.AppResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * State for all three auth screens. [fieldErrors] holds per-field validation
 * errors so a message renders directly under the offending input (FORMS & FEEDBACK
 * rule: errors belong next to their field, not only in a banner at the top),
 * while [formError] carries whole-form failures like "no network".
 */
data class AuthUiState(
    val isLoading: Boolean = false,
    val emailError: AppError? = null,
    val passwordError: AppError? = null,
    val confirmPasswordError: AppError? = null,
    val nameError: AppError? = null,
    val formError: AppError? = null,
    /** Set once a sign-in/registration succeeds — the screen navigates on this. */
    val isAuthenticated: Boolean = false,
    /** Set after a reset email is sent, so the screen can show its confirmation. */
    val resetEmailSent: Boolean = false,
)

/**
 * Drives Login, Register, and Forgot-Password.
 *
 * Validation runs client-side first (cheap, instant, and avoids burning a network
 * call on an obviously-bad form), then Firebase's own errors are mapped onto the
 * same [AppError] kinds so both sources render identically localized copy.
 */
@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun login(email: String, password: String) {
        if (!validateLogin(email, password)) return
        _uiState.update { it.copy(isLoading = true, formError = null) }
        viewModelScope.launch {
            when (val result = authRepository.login(email, password)) {
                is AppResult.Success -> _uiState.update {
                    it.copy(isLoading = false, isAuthenticated = true)
                }
                is AppResult.Error -> _uiState.update {
                    it.copy(isLoading = false, formError = result.error)
                }
            }
        }
    }

    fun register(fullName: String, email: String, password: String, confirmPassword: String) {
        if (!validateRegister(fullName, email, password, confirmPassword)) return
        _uiState.update { it.copy(isLoading = true, formError = null) }
        viewModelScope.launch {
            when (val result = authRepository.register(fullName, email, password)) {
                is AppResult.Success -> _uiState.update {
                    it.copy(isLoading = false, isAuthenticated = true)
                }
                is AppResult.Error -> _uiState.update {
                    it.copy(isLoading = false, formError = result.error)
                }
            }
        }
    }

    fun sendPasswordReset(email: String) {
        if (!isEmailValid(email)) {
            _uiState.update { it.copy(emailError = AppError.INVALID_EMAIL) }
            return
        }
        _uiState.update { it.copy(isLoading = true, formError = null, emailError = null) }
        viewModelScope.launch {
            when (val result = authRepository.sendPasswordReset(email)) {
                is AppResult.Success -> _uiState.update {
                    it.copy(isLoading = false, resetEmailSent = true)
                }
                is AppResult.Error -> _uiState.update {
                    it.copy(isLoading = false, formError = result.error)
                }
            }
        }
    }

    /** Clears the form-level banner after it's been shown (e.g. in a Snackbar). */
    fun consumeFormError() = _uiState.update { it.copy(formError = null) }

    // ---------- Validation ----------

    private fun validateLogin(email: String, password: String): Boolean {
        val emailError = when {
            email.isBlank() -> AppError.EMPTY_FIELD
            !isEmailValid(email) -> AppError.INVALID_EMAIL
            else -> null
        }
        val passwordError = if (password.isBlank()) AppError.EMPTY_FIELD else null
        _uiState.update { it.copy(emailError = emailError, passwordError = passwordError) }
        return emailError == null && passwordError == null
    }

    private fun validateRegister(
        fullName: String,
        email: String,
        password: String,
        confirmPassword: String,
    ): Boolean {
        val nameError = if (fullName.isBlank()) AppError.EMPTY_FIELD else null
        val emailError = when {
            email.isBlank() -> AppError.EMPTY_FIELD
            !isEmailValid(email) -> AppError.INVALID_EMAIL
            else -> null
        }
        // Firebase enforces a 6-character minimum; checking locally avoids a
        // round-trip and gives the teacher the message immediately.
        val passwordError = when {
            password.isBlank() -> AppError.EMPTY_FIELD
            password.length < MIN_PASSWORD_LENGTH -> AppError.WEAK_PASSWORD
            else -> null
        }
        val confirmError = when {
            confirmPassword.isBlank() -> AppError.EMPTY_FIELD
            confirmPassword != password -> AppError.PASSWORDS_DO_NOT_MATCH
            else -> null
        }
        _uiState.update {
            it.copy(
                nameError = nameError,
                emailError = emailError,
                passwordError = passwordError,
                confirmPasswordError = confirmError,
            )
        }
        return nameError == null && emailError == null &&
            passwordError == null && confirmError == null
    }

    private fun isEmailValid(email: String): Boolean =
        android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()

    private companion object {
        const val MIN_PASSWORD_LENGTH = 6
    }
}
