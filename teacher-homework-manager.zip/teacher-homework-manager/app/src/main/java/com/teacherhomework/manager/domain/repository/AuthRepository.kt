package com.teacherhomework.manager.domain.repository

import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.flow.Flow

/**
 * Authentication contract (Firebase Auth impl in the data layer). All calls that
 * can fail return [AppResult] with an [com.teacherhomework.manager.domain.util.AppError]
 * kind so the UI can show localized error copy.
 */
interface AuthRepository {
    /** The signed-in teacher's uid, or null if signed out. */
    val currentUserId: String?

    /** Emits true while a user session exists (drives auto-login routing). */
    val isSignedIn: Flow<Boolean>

    /** Registers, creates the teacher document, and returns the new uid. */
    suspend fun register(fullName: String, email: String, password: String): AppResult<String>

    /** Signs in and returns the uid. */
    suspend fun login(email: String, password: String): AppResult<String>

    /** Sends a password-reset email. */
    suspend fun sendPasswordReset(email: String): AppResult<Unit>

    /** Signs out the current session. */
    suspend fun logout()
}
