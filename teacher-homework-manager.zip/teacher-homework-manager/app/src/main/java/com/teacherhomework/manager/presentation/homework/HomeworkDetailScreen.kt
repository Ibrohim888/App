package com.teacherhomework.manager.presentation.homework

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.teacherhomework.manager.R
import com.teacherhomework.manager.presentation.components.AppTopBar
import com.teacherhomework.manager.presentation.components.ConfirmDialog
import com.teacherhomework.manager.presentation.components.HomeworkStatusBadge
import com.teacherhomework.manager.presentation.components.OverflowAction
import com.teacherhomework.manager.presentation.components.PrimaryButton
import com.teacherhomework.manager.presentation.components.StatTile
import com.teacherhomework.manager.presentation.theme.AppCorner
import com.teacherhomework.manager.presentation.util.DateFormat
import com.teacherhomework.manager.presentation.util.toStringRes

/**
 * One assignment in full, with its grading progress and the primary "Check
 * homework" action.
 *
 * DELETION (policy override): Delete is ALWAYS enabled — never greyed out. When
 * grades already exist, confirming goes through a destructive dialog that states
 * how many recorded grades will be permanently removed along with it. Archive
 * remains offered as the non-destructive alternative, but is no longer forced.
 */
@Composable
fun HomeworkDetailScreen(
    onNavigateBack: () -> Unit,
    onEdit: (String) -> Unit,
    onStartChecking: (String) -> Unit,
    viewModel: HomeworkDetailViewModel = hiltViewModel(),
) {
    val homework by viewModel.homework.collectAsStateWithLifecycle()
    val progress by viewModel.progress.collectAsStateWithLifecycle()
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val locale = LocalConfiguration.current.locales[0]

    LaunchedEffect(state.finished) { if (state.finished) onNavigateBack() }

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHostState.showSnackbar(context.getString(it.toStringRes()))
            viewModel.consumeError()
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.title_homework_detail),
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(onClick = { homework?.let { onEdit(it.id) } }) {
                        Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.action_edit))
                    }
                },
                overflowActions = listOf(
                    OverflowAction(
                        label = stringResource(R.string.action_archive),
                        icon = Icons.Filled.Archive,
                        onClick = viewModel::archive,
                    ),
                    OverflowAction(
                        label = stringResource(R.string.action_delete),
                        icon = Icons.Filled.Delete,
                        // Always tappable — the dialog handles the warning.
                        onClick = viewModel::requestDelete,
                    ),
                ),
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        val hw = homework
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            if (hw != null) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(
                        text = hw.title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f),
                    )
                    HomeworkStatusBadge(hw.status)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "${hw.subject} · ${hw.className}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))

                Card(
                    shape = AppCorner.Card,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(14.dp)) {
                        DetailRow(
                            label = stringResource(R.string.field_assigned_date),
                            value = DateFormat.date(hw.assignedDate, locale),
                        )
                        Spacer(Modifier.height(8.dp))
                        DetailRow(
                            label = stringResource(R.string.field_deadline),
                            value = DateFormat.date(hw.deadline, locale),
                        )
                        if (hw.description.isNotBlank()) {
                            Spacer(Modifier.height(12.dp))
                            Text(
                                text = stringResource(R.string.field_description),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(3.dp))
                            Text(hw.description, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text(
                    text = stringResource(R.string.section_progress),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        label = stringResource(R.string.status_completed),
                        value = progress.completed.toString(),
                        modifier = Modifier.weight(1f),
                    )
                    StatTile(
                        label = stringResource(R.string.status_partial),
                        value = progress.partial.toString(),
                        modifier = Modifier.weight(1f),
                    )
                    StatTile(
                        label = stringResource(R.string.status_missing),
                        value = progress.missing.toString(),
                        modifier = Modifier.weight(1f),
                    )
                }

                Spacer(Modifier.height(24.dp))
                PrimaryButton(
                    text = stringResource(R.string.action_check_homework),
                    onClick = { onStartChecking(hw.id) },
                    loading = state.isWorking,
                )
                Spacer(Modifier.height(20.dp))
            }
        }
    }

    // ---- Deletion confirmations ----

    when (val prompt = state.deletePrompt) {
        is DeletePrompt.None -> Unit

        is DeletePrompt.Simple -> ConfirmDialog(
            title = stringResource(R.string.dialog_delete_homework_title),
            message = stringResource(R.string.dialog_delete_homework_message),
            confirmLabel = stringResource(R.string.action_delete),
            dismissLabel = stringResource(R.string.action_cancel),
            destructive = true,
            onConfirm = viewModel::confirmDelete,
            onDismiss = viewModel::dismissDeletePrompt,
        )

        // Graded homework: allowed, but the teacher is told exactly what is lost.
        is DeletePrompt.WithResults -> ConfirmDialog(
            title = stringResource(R.string.dialog_delete_graded_homework_title),
            message = stringResource(
                R.string.dialog_delete_graded_homework_message,
                prompt.resultCount,
            ),
            confirmLabel = stringResource(R.string.action_delete_anyway),
            dismissLabel = stringResource(R.string.action_cancel),
            destructive = true,
            onConfirm = viewModel::confirmDelete,
            onDismiss = viewModel::dismissDeletePrompt,
        )
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
