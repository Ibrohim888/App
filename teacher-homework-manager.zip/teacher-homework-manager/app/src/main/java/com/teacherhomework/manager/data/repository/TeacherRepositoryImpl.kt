package com.teacherhomework.manager.data.repository

import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.data.remote.TeacherRemoteDataSource
import com.teacherhomework.manager.domain.model.Teacher
import com.teacherhomework.manager.domain.model.TeacherSettings
import com.teacherhomework.manager.domain.repository.TeacherRepository
import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Teacher profile + settings.
 *
 * Settings live in two places on purpose: DataStore (authoritative for what the
 * UI renders right now, works offline and before login) and Firestore (so a
 * reinstall or a second device restores the teacher's language/theme). DataStore
 * is written first and never blocks on the network; the Firestore mirror is
 * best-effort.
 */
@Singleton
class TeacherRepositoryImpl @Inject constructor(
    private val remote: TeacherRemoteDataSource,
    private val preferences: AppPreferences,
    private val session: SessionProvider,
) : TeacherRepository {

    override fun observeTeacher(): Flow<Teacher?> = flow {
        val id = session.teacherId
        if (id == null) {
            emit(null)
        } else {
            emit(runCatching { remote.fetch(id) }.getOrNull())
        }
    }

    override suspend fun ensureTeacherDocument(
        uid: String,
        fullName: String,
        email: String,
        settings: TeacherSettings,
    ): AppResult<Unit> = runCatchingRepo {
        remote.updateProfile(uid, fullName, profileImage = null)
        remote.updateSettings(uid, settings)
    }

    /**
     * Persists settings locally first (instant, offline-safe), then mirrors to
     * Firestore. A network failure leaves the local choice applied — the mirror
     * catches up on the next successful settings write or login.
     */
    override suspend fun updateSettings(settings: TeacherSettings): AppResult<Unit> {
        preferences.setSettingsSnapshot(settings)
        return runCatchingRepo { remote.updateSettings(session.requireTeacherId(), settings) }
    }

    override suspend fun updateLastLogin() {
        runCatching { remote.updateLastLogin(session.requireTeacherId()) }
    }
}
