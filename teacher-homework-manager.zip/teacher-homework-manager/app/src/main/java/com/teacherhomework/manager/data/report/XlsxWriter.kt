package com.teacherhomework.manager.data.report

import java.io.File
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Minimal, dependency-free XLSX writer.
 *
 * WHY HAND-ROLLED: Apache POI (`poi-ooxml`) is explicitly excluded by the
 * free-tier/APK policy — it adds 15-25MB+ even after shrinking and its
 * reflection-heavy paths are unreliable under R8 on Android. An `.xlsx` is just
 * a ZIP of XML parts, so `java.util.zip` plus a small XML builder covers
 * everything this app needs: a header row plus typed cells. Measured APK impact
 * of this file: effectively zero (a few KB of code, no dependency).
 *
 * SUPPORTED: multiple sheets, string/number cells, a bold header row, and column
 * widths. NOT supported (deliberately, as nothing here needs it): formulas,
 * merged cells, charts, images, cell borders.
 *
 * Strings are written inline (`t="inlineStr"`) rather than through a shared
 * string table — slightly larger files, but far simpler and immune to the index
 * corruption that a hand-built shared-string table invites.
 */
class XlsxWriter {

    /** One cell's value; the type decides how Excel stores and aligns it. */
    sealed interface Cell {
        data class Text(val value: String) : Cell
        data class Number(val value: Double) : Cell
        data object Empty : Cell
    }

    /** One worksheet: a name, an optional header row, and data rows. */
    data class Sheet(
        val name: String,
        val header: List<String> = emptyList(),
        val rows: List<List<Cell>> = emptyList(),
    )

    /** Writes [sheets] to [file] as a valid .xlsx package. */
    fun write(file: File, sheets: List<Sheet>) {
        file.parentFile?.mkdirs()
        file.outputStream().use { write(it, sheets) }
    }

    fun write(output: OutputStream, sheets: List<Sheet>) {
        require(sheets.isNotEmpty()) { "An xlsx needs at least one sheet" }
        ZipOutputStream(output).use { zip ->
            zip.putEntry("[Content_Types].xml", contentTypes(sheets.size))
            zip.putEntry("_rels/.rels", rootRels())
            zip.putEntry("xl/workbook.xml", workbook(sheets))
            zip.putEntry("xl/_rels/workbook.xml.rels", workbookRels(sheets.size))
            zip.putEntry("xl/styles.xml", styles())
            sheets.forEachIndexed { index, sheet ->
                zip.putEntry("xl/worksheets/sheet${index + 1}.xml", worksheet(sheet))
            }
        }
    }

    private fun ZipOutputStream.putEntry(name: String, content: String) {
        putNextEntry(ZipEntry(name))
        write(content.toByteArray(Charsets.UTF_8))
        closeEntry()
    }

    private fun contentTypes(sheetCount: Int): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
        append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
        append("""<Default Extension="xml" ContentType="application/xml"/>""")
        append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
        append("""<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
        repeat(sheetCount) { i ->
            append("""<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
        }
        append("</Types>")
    }

    private fun rootRels(): String =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
            """<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>""" +
            """</Relationships>"""

    private fun workbook(sheets: List<Sheet>): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" """)
        append("""xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>""")
        sheets.forEachIndexed { index, sheet ->
            append("""<sheet name="${sheet.name.sanitizeSheetName().escapeXml()}" sheetId="${index + 1}" r:id="rId${index + 1}"/>""")
        }
        append("</sheets></workbook>")
    }

    private fun workbookRels(sheetCount: Int): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
        repeat(sheetCount) { i ->
            append("""<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>""")
        }
        // The styles part is referenced after the sheets so its id can't collide.
        append("""<Relationship Id="rId${sheetCount + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""")
        append("</Relationships>")
    }

    /**
     * Two cell formats: index 0 = normal, index 1 = bold (used for header rows).
     * Anything more elaborate isn't needed by these reports.
     */
    private fun styles(): String =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""" +
            """<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>""" +
            """<font><b/><sz val="11"/><name val="Calibri"/></font></fonts>""" +
            """<fills count="1"><fill><patternFill patternType="none"/></fill></fills>""" +
            """<borders count="1"><border/></borders>""" +
            """<cellStyleXfs count="1"><xf/></cellStyleXfs>""" +
            """<cellXfs count="2"><xf xfId="0"/><xf fontId="1" applyFont="1" xfId="0"/></cellXfs>""" +
            """</styleSheet>"""

    private fun worksheet(sheet: Sheet): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")

        val columnCount = maxOf(sheet.header.size, sheet.rows.maxOfOrNull { it.size } ?: 0)
        if (columnCount > 0) {
            append("<cols>")
            // A generous fixed width beats auto-fit, which XLSX can't express
            // without the consuming app recalculating it.
            append("""<col min="1" max="$columnCount" width="22" customWidth="1"/>""")
            append("</cols>")
        }

        append("<sheetData>")
        var rowIndex = 1
        if (sheet.header.isNotEmpty()) {
            append(row(rowIndex++, sheet.header.map { Cell.Text(it) }, styleIndex = 1))
        }
        sheet.rows.forEach { cells ->
            append(row(rowIndex++, cells, styleIndex = 0))
        }
        append("</sheetData></worksheet>")
    }

    private fun row(rowNumber: Int, cells: List<Cell>, styleIndex: Int): String = buildString {
        append("""<row r="$rowNumber">""")
        cells.forEachIndexed { columnIndex, cell ->
            val ref = "${columnName(columnIndex)}$rowNumber"
            val style = if (styleIndex != 0) """ s="$styleIndex"""" else ""
            when (cell) {
                is Cell.Text ->
                    append("""<c r="$ref"$style t="inlineStr"><is><t xml:space="preserve">${cell.value.escapeXml()}</t></is></c>""")
                is Cell.Number ->
                    append("""<c r="$ref"$style><v>${cell.value}</v></c>""")
                Cell.Empty -> append("""<c r="$ref"$style/>""")
            }
        }
        append("</row>")
    }

    /** 0 → A, 25 → Z, 26 → AA … (spreadsheet column naming is base-26, 1-indexed). */
    private fun columnName(index: Int): String {
        var n = index
        val sb = StringBuilder()
        while (n >= 0) {
            sb.insert(0, ('A' + (n % 26)))
            n = n / 26 - 1
        }
        return sb.toString()
    }

    /**
     * Excel rejects sheet names containing : \ / ? * [ ] or longer than 31 chars,
     * so localized titles are sanitized rather than producing a corrupt file.
     */
    private fun String.sanitizeSheetName(): String =
        replace(Regex("""[:\\/?*\[\]]"""), " ").take(31).ifBlank { "Sheet" }
}

/** Escapes the five XML-significant characters. */
internal fun String.escapeXml(): String = buildString(length) {
    this@escapeXml.forEach { c ->
        when (c) {
            '&' -> append("&amp;")
            '<' -> append("&lt;")
            '>' -> append("&gt;")
            '"' -> append("&quot;")
            '\'' -> append("&apos;")
            else -> append(c)
        }
    }
}
