package com.teacherhomework.manager.data.repository

import com.teacherhomework.manager.data.local.dao.ResultDao
import com.teacherhomework.manager.data.mapper.toDomain
import com.teacherhomework.manager.data.mapper.toEntity
import com.teacherhomework.manager.data.remote.ResultRemoteDataSource
import com.teacherhomework.manager.domain.model.Result
import com.teacherhomework.manager.domain.model.SyncState
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.repository.StatisticsRepository
import com.teacherhomework.manager.domain.util.AppResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton

/**
 * Offline-first result (grading) repository.
 *
 * This is the hottest write path in the app — Fast Checking Mode can produce one
 * write per student in quick succession. Each [upsertResult] writes Room first so
 * the toggle responds instantly, then pushes to Firestore and recalculates
 * statistics. The recalculation is transactional and idempotent (see
 * StatisticsRepositoryImpl), so rapid consecutive saves converge correctly.
 */
@Singleton
class ResultRepositoryImpl @Inject constructor(
    private val resultDao: ResultDao,
    private val remote: ResultRemoteDataSource,
    private val session: SessionProvider,
    private val statistics: Provider<StatisticsRepository>,
) : ResultRepository {

    override fun observeResultsForHomework(homeworkId: String): Flow<List<Result>> =
        resultDao.observeForHomework(homeworkId).map { list -> list.map { it.toDomain() } }

    override fun observeResultsForStudent(studentId: String): Flow<List<Result>> =
        resultDao.observeForStudent(studentId).map { list -> list.map { it.toDomain() } }

    override fun observeAllResults(): Flow<List<Result>> =
        resultDao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun observeHasResults(homeworkId: String): Flow<Boolean> =
        resultDao.observeHasResults(homeworkId)

    override suspend fun hasResultsForHomework(homeworkId: String): Boolean =
        resultDao.countForHomework(homeworkId) > 0

    override suspend fun countResultsForHomework(homeworkId: String): Int =
        resultDao.countForHomework(homeworkId)

    override suspend fun getResultFor(homeworkId: String, studentId: String): Result? =
        resultDao.getFor(homeworkId, studentId)?.toDomain()

    /**
     * Saves one student's result. The caller must have validated the grade with
     * ValidateGradeUseCase first; the security rules re-validate server-side
     * because a UI-only check can be bypassed by a direct Firestore write.
     */
    override suspend fun upsertResult(result: Result): AppResult<Unit> {
        resultDao.upsert(result.copy(syncState = SyncState.PENDING).toEntity())
        return runCatchingRepo {
            remote.upsert(session.requireTeacherId(), result)
            resultDao.upsert(result.copy(syncState = SyncState.SYNCED).toEntity())
            statistics.get().recalculateAndCommit()
            Unit
        }
    }

    override suspend fun deleteResultsForStudent(studentId: String): AppResult<Unit> {
        resultDao.deleteForStudent(studentId)
        return runCatchingRepo {
            remote.deleteForStudent(session.requireTeacherId(), studentId)
            statistics.get().recalculateAndCommit()
            Unit
        }
    }

    override suspend fun allResults(): List<Result> = resultDao.getAll().map { it.toDomain() }

    override suspend fun refresh(): AppResult<Unit> = runCatchingRepo {
        val results = remote.fetchAll(session.requireTeacherId())
        resultDao.upsertAll(results.map { it.toEntity() })
    }
}
