package com.teacherhomework.manager.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.teacherhomework.manager.R
import com.teacherhomework.manager.data.local.dao.NotificationDao
import com.teacherhomework.manager.data.local.entity.NotificationEntity
import com.teacherhomework.manager.data.preferences.AppPreferences
import com.teacherhomework.manager.domain.model.HomeworkStatus
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.notifications.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import java.util.UUID
import javax.inject.Inject

/**
 * Alerts the teacher about assignments whose deadline has passed but which still
 * have ungraded students.
 *
 * "Ungraded" means a student in the assignment's class with NO result recorded —
 * deliberately not the same as a result explicitly marked MISSING, which is a
 * decision the teacher already made and doesn't need reminding about.
 */
@HiltWorker
class MissingHomeworkWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val homeworkRepository: HomeworkRepository,
    private val studentRepository: StudentRepository,
    private val resultRepository: ResultRepository,
    private val appPreferences: AppPreferences,
    private val notificationHelper: NotificationHelper,
    private val notificationDao: NotificationDao,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val settings = appPreferences.notificationSettings.first()
        if (!settings.localRemindersEnabled || !settings.missingHomeworkAlerts) {
            return Result.success()
        }

        val now = System.currentTimeMillis()
        val overdue = homeworkRepository
            .observeHomework(status = HomeworkStatus.ACTIVE)
            .first()
            .filter { it.deadline < now }

        if (overdue.isEmpty()) return Result.success()

        val students = studentRepository.observeStudents().first()
        val results = resultRepository.allResults()
        val resultsByHomework = results.groupBy { it.homeworkId }
        val studentsByClass = students.groupBy { it.className }

        var ungradedTotal = 0
        overdue.forEach { hw ->
            val classSize = studentsByClass[hw.className]?.size ?: 0
            val recorded = resultsByHomework[hw.id]?.size ?: 0
            ungradedTotal += (classSize - recorded).coerceAtLeast(0)
        }
        if (ungradedTotal == 0) return Result.success()

        val ctx = WorkerLocale.localizedContext(applicationContext, appPreferences)
        notificationHelper.post(
            channelId = NotificationHelper.CHANNEL_MISSING,
            notificationId = NotificationHelper.ID_MISSING,
            title = ctx.getString(R.string.notif_missing_title),
            body = ctx.resources.getQuantityString(
                R.plurals.notif_missing_body,
                ungradedTotal,
                ungradedTotal,
                overdue.size,
            ),
            deepLink = DEEP_LINK_DASHBOARD,
        )

        notificationDao.insert(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                type = TYPE_MISSING,
                paramsJson = """{"ungraded":"$ungradedTotal","assignments":"${overdue.size}"}""",
                postedAt = now,
                read = false,
                deepLink = DEEP_LINK_DASHBOARD,
            )
        )
        return Result.success()
    }

    companion object {
        const val WORK_NAME = "missing_homework_alert"
        const val TYPE_MISSING = "MISSING"
        const val DEEP_LINK_DASHBOARD = "dashboard"
    }
}
