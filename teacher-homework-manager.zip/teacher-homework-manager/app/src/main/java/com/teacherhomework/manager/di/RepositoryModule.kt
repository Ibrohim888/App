package com.teacherhomework.manager.di

import com.teacherhomework.manager.data.repository.AuthRepositoryImpl
import com.teacherhomework.manager.data.repository.HomeworkRepositoryImpl
import com.teacherhomework.manager.data.repository.NotificationSettingsRepositoryImpl
import com.teacherhomework.manager.data.repository.ResultRepositoryImpl
import com.teacherhomework.manager.data.repository.StatisticsRepositoryImpl
import com.teacherhomework.manager.data.repository.StudentRepositoryImpl
import com.teacherhomework.manager.data.repository.TeacherRepositoryImpl
import com.teacherhomework.manager.domain.repository.AuthRepository
import com.teacherhomework.manager.domain.repository.HomeworkRepository
import com.teacherhomework.manager.domain.repository.NotificationSettingsRepository
import com.teacherhomework.manager.domain.repository.ResultRepository
import com.teacherhomework.manager.domain.repository.StatisticsRepository
import com.teacherhomework.manager.domain.repository.StudentRepository
import com.teacherhomework.manager.domain.repository.TeacherRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Binds each domain-layer repository interface to its data-layer implementation.
 *
 * The presentation layer only ever sees the interfaces (Clean Architecture
 * dependency rule: domain knows nothing about Firebase or Room), which is also
 * what makes ViewModels testable with fakes.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindAuthRepository(impl: AuthRepositoryImpl): AuthRepository

    @Binds
    @Singleton
    abstract fun bindTeacherRepository(impl: TeacherRepositoryImpl): TeacherRepository

    @Binds
    @Singleton
    abstract fun bindStudentRepository(impl: StudentRepositoryImpl): StudentRepository

    @Binds
    @Singleton
    abstract fun bindHomeworkRepository(impl: HomeworkRepositoryImpl): HomeworkRepository

    @Binds
    @Singleton
    abstract fun bindResultRepository(impl: ResultRepositoryImpl): ResultRepository

    @Binds
    @Singleton
    abstract fun bindStatisticsRepository(impl: StatisticsRepositoryImpl): StatisticsRepository

    @Binds
    @Singleton
    abstract fun bindNotificationSettingsRepository(
        impl: NotificationSettingsRepositoryImpl,
    ): NotificationSettingsRepository
}
