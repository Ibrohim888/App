package com.teacherhomework.manager.domain.usecase

import com.teacherhomework.manager.domain.repository.ResultRepository
import javax.inject.Inject

/**
 * Decides how a homework deletion should proceed.
 *
 * POLICY OVERRIDE (teacher decision, supersedes the original "block deletion when
 * results exist" spec): deletion is ALWAYS permitted. The only difference is UX:
 *  - No recorded results → [Decision.DirectDelete] (a plain confirm is enough).
 *  - Has recorded results → [Decision.NeedsConfirmation] carrying the result
 *    count, so the UI shows an explicit warning dialog ("this homework has N
 *    recorded grades that will also be permanently deleted") before proceeding.
 *
 * Either way, [com.teacherhomework.manager.domain.repository.HomeworkRepository.deleteHomework]
 * cascades to the results and triggers a statistics recalculation. Archive
 * remains available as the non-destructive alternative, but is no longer forced.
 */
class CheckHomeworkDeletionUseCase @Inject constructor(
    private val resultRepository: ResultRepository,
) {
    sealed interface Decision {
        /** Nothing graded yet — deleting loses no recorded work. */
        data object DirectDelete : Decision

        /** [resultCount] recorded grades will be destroyed along with the homework. */
        data class NeedsConfirmation(val resultCount: Int) : Decision
    }

    suspend operator fun invoke(homeworkId: String): Decision {
        val count = resultRepository.countResultsForHomework(homeworkId)
        return if (count == 0) Decision.DirectDelete else Decision.NeedsConfirmation(count)
    }
}
