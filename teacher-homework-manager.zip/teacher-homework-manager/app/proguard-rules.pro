# Keep rules for the release (R8) build.

# Firebase Firestore uses reflection to (de)serialize model classes.
# Keep the no-arg constructors and fields of our data-layer models so
# toObject()/set() keep working after shrinking. Adjust the package if
# the data models move.
-keepclassmembers class com.teacherhomework.manager.data.** {
    <init>();
    <fields>;
}
-keepattributes Signature, *Annotation*, EnclosingMethod, InnerClasses

# Kotlin coroutines
-dontwarn kotlinx.coroutines.**

# Downloadable-fonts provider metadata
-keep class androidx.compose.ui.text.googlefonts.** { *; }
