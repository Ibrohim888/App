# Teacher Homework Manager — Teacher App

A production-bound Android app that replaces paper-based homework tracking for
teachers, tutors, and small learning centers. Built to run **permanently on
Firebase's free Spark plan** ($0/month), fully localized in **Uzbek / Russian /
English**, with 5 selectable color themes.

- **Package:** `com.teacherhomework.manager`
- **Stack:** Kotlin · Jetpack Compose · Material 3 · MVVM + Clean Architecture ·
  Coroutines/StateFlow · Navigation Compose · Hilt · Room · DataStore · Firebase
  (Auth/Firestore/Storage — Spark plan only) · WorkManager
- **Min SDK:** 26 · **Target/Compile SDK:** 34

> **Status: all 7 phases implemented (source complete).**
> The project has NOT been compiled on the machine that generated it — no Gradle
> distribution or Android SDK platform 34 was available there. Expect to fix a
> small number of import/API-surface issues on your first Android Studio sync.
> See **"First build"** below.

---

## Before it will build: Firebase Console setup (manual, ~10 minutes)

These steps cannot be done from code — you must do them in the Firebase Console.
`app/google-services.json` in this repo is a **placeholder with fake IDs** and
must be replaced or the `google-services` Gradle plugin will fail the build.

1. **Create the project**
   - Go to <https://console.firebase.google.com> → **Add project**.
   - Name it (e.g. `teacher-homework-manager`). Google Analytics is optional —
     you can disable it.
   - **Leave the plan on Spark (free).** Do not upgrade to Blaze; nothing in this
     app requires it, and that is a hard project constraint.

2. **Register the Android app (twice — release and debug)**
   - Project overview → **Add app** → Android.
   - Package name: `com.teacherhomework.manager` → Register → **Download
     `google-services.json`**.
   - Then **Add app** again with package name
     `com.teacherhomework.manager.debug` (the debug build applies
     `applicationIdSuffix = ".debug"`, so without this second registration the
     debug build cannot reach Firebase).
   - Download the final `google-services.json` (it will now contain both) and
     **replace `app/google-services.json`** with it.

3. **Enable Authentication**
   - Build → **Authentication** → Get started → **Sign-in method** →
     enable **Email/Password**. (Do not enable "Email link" — the app uses
     password sign-in.)

4. **Create Firestore**
   - Build → **Firestore Database** → Create database.
   - Start in **production mode** (the rules in this repo replace the default).
   - Pick the region closest to your users (e.g. `europe-west1`);
     **the region cannot be changed later.**

5. **Create Storage**
   - Build → **Storage** → Get started → production mode → same region.

6. **Deploy the rules and indexes** (from this project's root)
   ```bash
   npm install -g firebase-tools && firebase login && firebase deploy --only firestore:rules,firestore:indexes,storage
   ```
   If you'd rather not use the CLI, paste `firestore.rules` and `storage.rules`
   into the Console's Rules tabs by hand, and create the 4 composite indexes from
   `firestore.indexes.json` under Firestore → Indexes.

7. **Do NOT enable Cloud Functions or Cloud Messaging.** They require the Blaze
   plan and are permanently out of scope — all automation in this app runs
   on-device.

---

## First build

```bash
./gradlew :app:assembleDebug
```

Open the project in **Android Studio (Ladybug or newer)** and let it sync — it
will download the Gradle distribution, the Android SDK platform 34, and all
dependencies on first run.

Because the generating environment had no Gradle/SDK available, the source has
been checked by review rather than by a compiler. If the first sync reports
errors, they will almost certainly be one of:

- a missing or differently-named Compose Material icon (icon names shift between
  library versions — substitute the nearest available one),
- an import that Studio can auto-fix with `Alt+Enter`,
- a Compose API that moved between BOM versions.

None of these require redesigning anything; the architecture, data model, and
business logic are the substance of the delivery.

Run the tests:

```bash
./gradlew :app:testDebugUnitTest
```

---

## What's implemented

| Area | Detail |
|---|---|
| **Launch flow** | Splash → (first launch only) Language → Theme → Login/Register → Dashboard. Returning users with a valid session go straight to Dashboard (auto-login). |
| **Localization** | Uzbek (default) / Russian / English across UI, generated reports, and notifications. 264 strings per locale, verified at parity. Language switches take effect immediately, no restart. |
| **Theming** | 5 accent themes × light/dark = 10 ColorSchemes. Warm off-white background, gradient header with overlapping stat cards, rounded-square avatars, pill status badges. |
| **Students** | Full CRUD, search (debounced), class filter chips, archive (reversible) and permanent delete (cascades to results). |
| **Homework** | Full CRUD. Every field stays editable at any status/age. Changing a deadline on graded work shows an explicit "existing grades won't change" notice. |
| **Deletion policy** | Deleting a graded homework is **allowed** after a confirmation dialog naming how many grades will be destroyed. See `docs/POLICY_OVERRIDES.md`. |
| **Checking** | Fast Checking Mode — large 3-way COMPLETED/PARTIAL/MISSING toggle (56dp), writes instantly with no Save step, works offline. Detailed mode adds grade + comment per student. Bulk "mark the rest as…". |
| **Statistics** | Computed on-device, committed via a Firestore transaction, idempotent (derived fresh from `results`), so concurrent devices converge. Bar charts drawn on Canvas (no chart library). |
| **Calendar** | Month grid of deadlines with per-day markers and a selected-day list. |
| **Reports** | PDF via Android's built-in `PdfDocument`; Excel via a **hand-rolled XLSX writer** (`java.util.zip` + XML — Apache POI deliberately avoided). Labels render in the teacher's chosen language; teacher-authored text is never translated. |
| **Reminders** | Local only — WorkManager + NotificationCompat. **No FCM, no push, no server.** Deadline, missing-homework, and weekly-summary workers, plus an in-app Notification Center that re-renders history in the current language. |
| **Offline** | Room is the UI's source of truth; every write goes local-first and is pushed to Firestore after, with a `SyncManager` retry queue for anything left PENDING. |
| **Security** | Hardened Firestore + Storage rules — the only server-side enforcement point, since there are no Cloud Functions. |

---

## Free-tier cost estimate

Spark daily quotas: **50,000 reads / 20,000 writes / 20,000 deletes**, 1 GiB
Firestore storage, 5 GB Cloud Storage, 1 GB/day download.

Reads are dominated by the offline-first design: the UI reads Room, and Firestore
is touched only on explicit refresh/sync and on statistics recalculation.

| Active students | Est. reads/day | Est. writes/day | % of read quota |
|---|---|---|---|
| 30 | ~350 | ~120 | 0.7% |
| 60 | ~700 | ~240 | 1.4% |
| 120 | ~1,400 | ~480 | 2.8% |
| 300 (stress) | ~3,500 | ~1,200 | 7% |
| 500 (stress) | ~6,000 | ~2,000 | 12% |

Worst-case day at 120 students (every student checked against 3 assignments, full
app resync, several statistics recalcs) still lands near ~5,000 reads — **an
order of magnitude below the 50K daily limit.** Storage: 120 compressed profile
photos (~200 KB each) ≈ 24 MB, plus a season of attachments and reports — far
inside 5 GB.

**$0 at this usage level on the Spark free plan, with wide margin.** This is not
"technically possible on free" — the math has roughly 10× headroom at the target
scale.

---

## Project layout

```
app/src/main/java/com/teacherhomework/manager/
├── data/
│   ├── local/          Room database, entities, DAOs
│   ├── mapper/         Firestore ↔ domain ↔ Room mapping
│   ├── preferences/    DataStore (language, theme, reminders, storage usage)
│   ├── remote/         Firestore paths + data sources
│   ├── report/         PdfReportWriter, XlsxWriter, ReportGenerator
│   └── repository/     Repository implementations, SyncManager
├── domain/
│   ├── model/          Pure Kotlin models + enums
│   ├── repository/     Repository interfaces (the dependency boundary)
│   ├── usecase/        ValidateGrade, CheckHomeworkDeletion, StatisticsCalculator
│   └── util/           AppResult / AppError
├── notifications/      NotificationHelper (local delivery only)
├── presentation/       Compose screens + ViewModels, theme, navigation
└── workers/            WorkManager reminder workers + scheduler
```

---

## Known limitations (stated, not hidden)

- **Local reminders are best-effort.** WorkManager runs jobs in an OS-chosen
  window; a reminder can arrive hours late or not at all while the device dozes.
  This is disclosed to the teacher in Settings and mitigated by the Dashboard's
  always-live "needs attention" list — the teacher never has to depend on a
  notification firing.
- **Firestore rules cannot do cross-document validation.** Statistics rules
  enforce range sanity only; correctness comes from the idempotent client-side
  recalculation inside a transaction.
- **Performance numbers are not measured.** No device or emulator was available
  in the generating environment, so no cold-start or jank figures are claimed. A
  performance number without a stated device isn't a verifiable claim, so none is
  made here.
- **APK size impact of the Excel export is not measured** for the same reason.
  The hand-rolled XLSX writer is a single ~200-line source file with **zero added
  dependencies**, versus the 15–25 MB Apache POI would have added.
- **Attachment upload UI is not wired.** The Storage rules, size/type
  constraints, and the quota-warning plumbing are in place, but there is no file
  picker screen — this is the one deliverable area left incomplete.
