# Policy overrides (teacher decisions that supersede the original spec)

These are deliberate changes to rules stated in the original Mega Prompt / the
source `CLAUDE.md`. They are the authoritative behavior for this project.

## 1. Homework deletion — graded homework may be fully deleted (2026-07-30)

**Original spec:** a homework could be deleted **only if it had zero recorded
results**. Once any result existed, Delete was disabled and the teacher had to
use **Archive** instead. This was also to be enforced server-side by a security
rule rejecting deletion of a homework that still had results.

**New behavior (teacher's decision):**
- Deletion is **never blocked**.
- If the homework has **no results**, it is deleted after a normal confirm.
- If the homework **has recorded results (is graded)**, tapping Delete opens a
  **confirmation dialog** that explicitly warns the recorded grades will also be
  permanently deleted. On confirm, the homework is deleted.
- Deletion **cascades**: the homework's `results` documents are deleted too, and
  a **statistics recalculation** runs afterward so aggregates reflect the removal.
- Consequence, disclosed in the dialog: grade history for that homework is lost.
  Archive still exists as the non-destructive option, but is no longer the *only*
  way to remove a graded homework.

**Code touch points (all implemented):**
- `domain/usecase/CheckHomeworkDeletionUseCase.kt` — returns `DirectDelete` or
  `NeedsConfirmation(resultCount)` (replaces the old "can/can't delete" gate).
- `data/repository/HomeworkRepositoryImpl.deleteHomework` — deletes the local
  results and homework first (so the UI updates immediately), then cascades the
  remote delete via `ResultRemoteDataSource.deleteForHomework` (batched at 400
  ops, under Firestore's 500-op batch cap) and triggers a stats recalc.
- `presentation/homework/HomeworkDetailViewModel.kt` — `DeletePrompt` sealed
  type: `None` / `Simple` / `WithResults(count)`. There is deliberately **no**
  "refused" case.
- `presentation/homework/HomeworkDetailScreen.kt` — the overflow Delete item is
  always enabled (never greyed out) and opens the matching dialog.
- `firestore.rules` — `allow delete: if isOwner(teacherId);` on
  `homework/{homeworkId}`, with a comment stating the blocking rule must not be
  re-added.
- Strings `dialog_delete_graded_homework_title` / `_message` and
  `action_delete_anyway` in all three languages; the message interpolates the
  exact grade count.
- `app/src/test/.../CheckHomeworkDeletionUseCaseTest.kt` — locks the behavior in:
  the tests fail if a "cannot delete" outcome is ever reintroduced.

**Retained but no longer blocking:** `AppError.HOMEWORK_HAS_RESULTS` still
exists in the error enum and has translations, because the vocabulary is still
meaningful — but nothing raises it to prevent a deletion any more.
