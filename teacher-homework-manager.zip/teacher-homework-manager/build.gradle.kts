// Top-level build file. Common configuration goes here; module-specific
// configuration lives in app/build.gradle.kts. Plugins are declared with
// `apply false` so their versions are resolved once for the whole build
// but only applied in the modules that need them.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.hilt) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.google.services) apply false
}
